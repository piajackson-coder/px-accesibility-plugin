#!/usr/bin/env node
// End-to-end: la ui.html real hablando con el code.js real, con un canvas
// de Figma simulado. Es la única forma de ver lo que ve la usuaria.

var fs = require('fs');
var { JSDOM } = require('jsdom');

// ── Canvas simulado ──────────────────────────────────────────────────────────
var idc = 0, canvasCreated = [], REGISTRO = {};
function N(p, children){
  var n = Object.assign({ type:'FRAME', name:'capa', visible:true, opacity:1,
    x:0, y:0, width:120, height:40, id:'n'+(++idc), removed:false }, p);
  REGISTRO[n.id] = n;
  n.absoluteBoundingBox = { x:n.x, y:n.y, width:n.width, height:n.height };
  if (children){ n.children = children; children.forEach(function(c){ c.parent = n; }); }
  return n;
}
function F(hex, op){
  var f = { type:'SOLID', visible:true, color:{
    r:parseInt(hex.slice(1,3),16)/255, g:parseInt(hex.slice(3,5),16)/255, b:parseInt(hex.slice(5,7),16)/255 }};
  if (op !== undefined) f.opacity = op;
  return f;
}
function T(chars, hex, size, p){
  return N(Object.assign({ type:'TEXT', characters:chars, fontSize:size||14, name:chars,
    fills:[F(hex||'#000000')], fontName:{family:'Inter',style:'Regular'} }, p||{}));
}

// Una pantalla realista: frame con header, card, dos botones y capas ocultas
function pantalla(){
  return N({ name:'Checkout / Paso 2', x:1200, y:400, width:390, height:640, fills:[F('#F7F8FA')] }, [
    T('Finalizar compra', '#11161C', 24, { y:24, width:280, height:30 }),
    T('Revisá los datos antes de pagar', '#9AA5B1', 14, { y:60, width:300, height:20 }),
    N({ name:'Card', y:100, width:350, height:180, fills:[F('#FFFFFF')] }, [
      T('Tarjeta terminada en 4242', '#11161C', 16, { y:120, width:250, height:20 }),
      T('Vence 09/28', '#B8C0C9', 12, { y:148, width:120, height:16 })
    ]),
    N({ name:'Frame 128', y:320, width:350, height:48, fills:[F('#1B4F9C')],
        reactions:[{ trigger:{ type:'ON_CLICK' } }] }, [
      T('Pagar $4.200', '#FFFFFF', 16, { y:334, width:120, height:20 })
    ]),
    N({ name:'Button / icon / help', x:340, y:24, width:32, height:32, fills:[F('#DCE9F9')] }),
    N({ name:'Modal / error', visible:false, y:400 }, [
      T('Algo falló', '#FF0000', 14),
      N({ name:'Frame 77', width:100, height:40, fills:[F('#EEEEEE')] })
    ])
  ]);
}

var selection = [];
function mkFrame(){
  var f = { type:'FRAME', name:'', children:[], fills:[], strokes:[], x:0, y:0,
    _pAuto:false, _cAuto:false,
    set layoutMode(v){ this._lm = v;
      // Figma real: al activar auto-layout los sizing modes pasan a AUTO
      if (v && v !== 'NONE'){ this._pAuto = true; this._cAuto = true; } },
    get layoutMode(){ return this._lm; },
    set primaryAxisSizingMode(v){ this._pAuto = (v === 'AUTO'); },
    get primaryAxisSizingMode(){ return this._pAuto ? 'AUTO' : 'FIXED'; },
    set counterAxisSizingMode(v){ this._cAuto = (v === 'AUTO'); },
    get counterAxisSizingMode(){ return this._cAuto ? 'AUTO' : 'FIXED'; },
    // Figma real: layoutAlign solo tiene efecto si el nodo YA es hijo de un
    // auto-layout. Setearlo antes del appendChild no hace nada.
    set layoutAlign(v){ this._align = this.parent ? v : 'INHERIT_IGNORED'; },
    get layoutAlign(){ return this._align || 'INHERIT'; },
    resize:function(w,h){ this.width=w; this.height=h; },
    appendChild:function(c){ this.children.push(c); c.parent=this; },
    // Sin insertChild, el try/catch del código lo tragaba en silencio y el test
    // no probaba nada: todos los fondos quedaban arriba del texto igual.
    insertChild:function(i,c){
      var k = this.children.indexOf(c);
      if (k > -1) this.children.splice(k,1);
      this.children.splice(i,0,c); c.parent=this;
    },
    remove:function(){ this.removed = true; },
    setPluginData:function(k,v){ this._pd=(this._pd||{}); this._pd[k]=v; },
    getPluginData:function(k){ return (this._pd||{})[k] || ''; } };
  canvasCreated.push(f); return f;
}
global.figma = {
  apiVersion:'1.0.0', showUI:function(){}, on:function(t,f){ this['_'+t]=f; },
  ui:{ postMessage:function(m){ toUI(m); }, onmessage:null },
  currentPage:{ selection:selection, children:[], appendChild:function(c){ this.children.push(c); } },
  root:{ children:[] },
  viewport:{ scrollAndZoomIntoView:function(){} },
  getNodeById:function(id){ return REGISTRO[id] || null; },
  getStyleById:function(){ return null; },
  getLocalPaintStyles:function(){ return []; },
  loadFontAsync:function(){ return Promise.resolve(); },
  createFrame:mkFrame,
  createText:function(){
    var t = { type:'TEXT', characters:'', fills:[], x:0, y:0, width:100, height:16,
      _autoResize:'WIDTH_AND_HEIGHT',
      // Figma recalcula la altura cuando el texto tiene ancho fijo. Sin simular
      // esto, un test no puede detectar que dos bloques se superponen.
      // El peor caso real: Figma reporta el alto de UNA línea aunque el texto
      // ocupe varias, porque todavía no reflowó. Si el código confía en
      // t.height, los bloques se pisan. El stub fuerza ese escenario para que
      // el código no pueda depender de que la API mida por él.
      resize:function(w,h){ this.width = w; this.height = Math.round((this.fontSize||14) * 1.2); },
      set textAutoResize(v){ this._autoResize = v; },
      get textAutoResize(){ return this._autoResize; },
      // Figma real: un texto que abraza su contenido a lo ancho NO acepta
      // STRETCH. Hay que fijarle el ancho (HEIGHT) antes de estirarlo.
      set layoutAlign(v){
        if (!this.parent) { this._align = 'SIN_PADRE'; return; }
        if (v === 'STRETCH' && this._autoResize === 'WIDTH_AND_HEIGHT') {
          this._align = 'STRETCH_RECHAZADO'; return;
        }
        this._align = v;
      },
      get layoutAlign(){ return this._align || 'INHERIT'; },
      set layoutGrow(v){ this._grow = v; }, get layoutGrow(){ return this._grow || 0; } };
    canvasCreated.push(t); return t; },
  createLine:function(){ var l={type:'LINE',strokes:[],x:0,y:0,resize:function(){}}; canvasCreated.push(l); return l; },
  // El resize vacío dejaba los rectángulos sin medidas: cualquier comparación
  // geométrica daba NaN y los tests pasaban sin probar nada.
  // Sin createPolygon la cola de la etiqueta se creaba en el vacío y ningún
  // test podía verificar que quedara apoyada sobre la imagen.
  createPolygon:function(){
    var p = { type:'POLYGON', fills:[], strokes:[], x:0, y:0, width:0, height:0,
      pointCount:3, rotation:0,
      resize:function(w,h){ this.width=w; this.height=h; } };
    canvasCreated.push(p); return p; },
  createRectangle:function(){
    var r = { type:'RECTANGLE', fills:[], strokes:[], x:0, y:0, width:0, height:0,
      resize:function(w,h){ this.width=w; this.height=h; } };
    canvasCreated.push(r); return r; },
  clientStorage:{ getAsync:function(){ return Promise.resolve(null); }, setAsync:function(){ return Promise.resolve(); } },
  closePlugin:function(){}
};
global.__html__ = '';

// ── UI real ──────────────────────────────────────────────────────────────────
var html = fs.readFileSync(__dirname + '/ui.html', 'utf8');
var dom = new JSDOM(html, { runScripts:'dangerously', pretendToBeVisual:true });
var w = dom.window;
var toCode = [];
w.parent = { postMessage:function(m){ if(m && m.pluginMessage){ toCode.push(m.pluginMessage);
  try { figma.ui.onmessage(m.pluginMessage); } catch(e){ console.log('THROW:', e.message); } } } };
function toUI(msg){
  var ev = new w.MessageEvent('message', { data:{ pluginMessage: msg } });
  if (typeof w.onmessage === 'function') w.onmessage(ev);
}

require(__dirname + '/code.js');

var passed=0, failed=0;
function test(l,f){ try{ f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'falló'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }
function sel(nodes){
  // El plugin REASIGNA figma.currentPage.selection (por ejemplo al insertar una
  // pieza de handoff). Mutar el array original dejaba las dos referencias
  // desincronizadas y los tests operaban sobre una selección vieja.
  selection.length=0; nodes.forEach(function(n){ selection.push(n); });
  figma.currentPage.selection = selection;
  if (figma._selectionchange) figma._selectionchange(); }
function click(s){ var e=w.document.querySelector(s); if(!e) throw new Error('no existe '+s);
  if(e.disabled) throw new Error('deshabilitado: '+s); e.click(); return e; }
function txt(s){ var e=w.document.querySelector(s); return e?e.textContent.replace(/\s+/g,' ').trim():null; }
function body(){ var s=w.document.querySelector('.screen.on'); return s?s.textContent.replace(/\s+/g,' ').trim():''; }
function screen(){ var s=w.document.querySelector('.screen.on'); return s?s.id:null; }
// Entra a una de las tres herramientas de Color desde "¿Qué querés revisar?"
function herramientaColor(id){
  if (w.document.querySelector('#s-color .op-nav') === null) back();   // volver a elegir
  click('#s-color .op-nav [data-ct="'+id+'"]');
}
function goTo(id){
  click('[data-go="'+id+'"]');
  // Color arranca en "¿Qué querés revisar?": para los tests se entra a revisar la selección
  if (id === 'color') { var o = w.document.querySelector('#s-color .op-nav [data-ct="sel"]'); if (o) o.click(); }
}
function back(){ w.document.getElementById('back').click(); }


// Los badges viven dentro del sub-frame "Badges" del overlay, para que el
// overlay sea UNA sola capa en el panel de capas.
function badgesDe(overlay){
  var cont = (overlay.children||[]).filter(function(c){ return c.name === 'Badges'; })[0];
  return cont ? cont.children.filter(function(c){ return String(c.name||'').indexOf('focus ') === 0; }) : [];
}
function overlayDe(tipo){
  return canvasCreated.filter(function(c){
    return c.name && String(c.name).indexOf(tipo) > -1; }).pop();
}


// El documento es un auto-layout de secciones, y cada sección posiciona su
// contenido de forma absoluta. Los helpers recorren en profundidad.
function frameDe(nombre){
  return canvasCreated.filter(function(c){
    return c.name && String(c.name).indexOf(nombre) > -1; }).pop();
}
function textosDe(f){
  var out = [];
  (function walk(n){ (n.children||[]).forEach(function(c){
    if (c.type === 'TEXT') out.push(c);
    walk(c); }); })(f);
  return out;
}
function seccionesDe(f){ return (f.children||[]).filter(function(c){ return c.type === 'FRAME'; }); }

// El primer init del panel sale antes de que exista el puente con code.js, y
// el reintento llega a los 250ms: se arranca cuando el catálogo ya llegó.
(function esperarCatalogo(n){
  var listo = false;
  try { listo = w.eval('S.criteria.length') > 0; } catch (e) {}
  if (listo || n > 40) run(); else setTimeout(function(){ esperarCatalogo(n + 1); }, 100);
})(0);

function run(){
console.log('\n\x1b[1mArranque\x1b[0m');

test('la UI arranca en el menú', function(){ eq(screen(), 's-menu'); });

test('code.js contestó el init con el catálogo', function(){
  assert(body().length > 0, 'el menú está vacío');
  goTo('criteria');
  assert(body().indexOf('1.4.3') > -1, 'no llegaron los criterios');
  back();
});

console.log('\n\x1b[1mSeleccionar un FRAME entero\x1b[0m');

test('el header muestra el frame seleccionado', function(){
  sel([ pantalla() ]);
  assert(txt('#ctxName').indexOf('Checkout') > -1, 'header dice: ' + txt('#ctxName'));
});

test('color analiza el frame y encuentra los textos', function(){
  goTo('color');
  var b = body();
  assert(b.indexOf('Finalizar compra') > -1, 'no listó el título. Cuerpo: ' + b.slice(0,200));
  assert(b.indexOf('Vence 09/28') > -1, 'no listó el texto gris claro');
});

test('marca el texto de bajo contraste como que FALLA', function(){
  assert(body().indexOf('FALLA') > -1, 'no marcó ningún fallo');
});

test('no toma los textos de la capa oculta', function(){
  assert(body().indexOf('Algo falló') === -1, 'tomó texto de una capa oculta');
});

test('tipografía revisa TODOS los textos del frame', function(){
  back(); goTo('type');
  var b = body();
  assert(b.indexOf('12px') > -1, 'no listó el tamaño de 12px');
  assert(b.indexOf('24px') > -1, 'no listó el título de 24px');
});

test('entrar a color analiza solo, sin apretar nada', function(){
  back();
  var p = pantalla();
  sel([ p ]);
  goTo('color');
  var b = body();
  assert(b.indexOf('Finalizar compra') > -1,
    'debería analizar al entrar. Cuerpo: ' + b.slice(0,200));
});

test('cambiar la selección re-analiza sola estando en color', function(){
  var p = pantalla();
  var card = p.children.filter(function(c){ return c.name === 'Card'; })[0];
  sel([ card ]);
  var b = body();
  assert(b.indexOf('Tarjeta terminada') > -1,
    'debería re-analizar al cambiar selección. Cuerpo: ' + b.slice(0,200));
  assert(b.indexOf('Finalizar compra') === -1, 'quedó contenido viejo');
});

test('un frame entero llena color Y tipografía de una sola pasada', function(){
  back(); sel([ pantalla() ]);
  goTo('color');
  assert(body().indexOf('Finalizar compra') > -1, 'color vacío');
  back(); goTo('type');
  var b = body();
  assert(b.indexOf('24px') > -1, 'tipografía vacía sin apretar nada. Cuerpo: ' + b.slice(0,200));
});

test('seleccionar una forma sin texto igual reporta contraste', function(){
  back();
  var icono = N({ name:'Icono', x:1300, y:420, width:24, height:24, fills:[F('#DCE9F9')] });
  N({ name:'Fondo', x:1200, y:400, width:390, height:640, fills:[F('#FFFFFF')] }, [ icono ]);
  sel([ icono ]);
  goTo('color');
  var b = body();
  assert(b.indexOf('Sin texto') > -1,
    'debería evaluar el relleno del ícono. Cuerpo: ' + b.slice(0,220));
  assert(b.indexOf('1.4.11') > -1, 'debería citar el criterio de contraste no textual');
});

console.log('\n\x1b[1mSeleccionar un BOTÓN\x1b[0m');

test('el botón se detecta como interactivo aunque se llame "Frame 128"', function(){
  back();
  var p = pantalla();
  var boton = p.children.filter(function(c){ return c.name === 'Frame 128'; })[0];
  sel([ boton ]);
  goTo('color');
  var b = body();
  assert(b.indexOf('interactivo') > -1, 'no lo marcó como interactivo. Cuerpo: ' + b.slice(0,250));
});

test('analiza el texto del botón contra el fondo del botón', function(){
  var b = body();
  assert(b.indexOf('Pagar') > -1, 'no encontró el texto del botón');
  assert(b.indexOf('#1B4F9C') > -1, 'no identificó el fondo del botón');
});

console.log('\n\x1b[1mOrden de foco\x1b[0m');

test('encuentra los controles del frame', function(){
  back(); sel([ pantalla() ]);
  goTo('focus'); click('#ctaFocus');
  var b = body();
  assert(b.indexOf('Frame 128') > -1, 'no encontró el botón de pagar. Cuerpo: ' + b.slice(0,250));
});

test('explica por qué detectó cada uno', function(){
  assert(body().indexOf('Detectado porque') > -1, 'no explica la detección');
});

test('el botón Dibujar manda render-focus-order y NADA más', function(){
  toCode.length = 0;
  click('#aDrawFocus');
  var tipos = toCode.map(function(m){ return m.type; });
  eq(tipos.join(','), 'render-focus-order', 'mandó: ' + tipos.join(','));
});

console.log('\n\x1b[1mSeparación de artefactos en el canvas\x1b[0m');
// El dibujado carga fuentes primero, así que hay que esperar al microtask

console.log('\n\x1b[1mMatriz de color\x1b[0m');

test('la matriz solo se dibuja desde su propio botón', function(){
  back(); goTo('color');
  herramientaColor('mx');
  toCode.length = 0;
  click('#s-color #btnFromSel');
  var tipos = toCode.map(function(m){ return m.type; });
  eq(tipos.join(','), 'extract-colors', 'mandó: ' + tipos.join(','));
});

test('la matriz NO se dibuja al calcular el orden de foco', function(){
  var antes = canvasCreated.filter(function(c){
    return c.name && String(c.name).indexOf('Matriz') > -1; }).length;
  back(); sel([ pantalla() ]);
  goTo('focus'); click('#ctaFocus');
  var despues = canvasCreated.filter(function(c){
    return c.name && String(c.name).indexOf('Matriz') > -1; }).length;
  eq(despues, antes, 'calcular el foco creó frames de matriz');
});

console.log('\n\x1b[1mARIA\x1b[0m');

test('sugiere etiquetas para los controles', function(){
  back(); sel([ pantalla() ]);
  goTo('aria'); click('#ctaAria');
  // Con el criterio nuevo solo se listan los controles que NECESITAN anotación.
  // Un botón con texto visible y sin estado no aparece: con <button> alcanza.
  assert(body().indexOf('sin nombre accesible') > -1 || body().indexOf('resueltos') > -1,
    'debería resumir el estado del handoff. Cuerpo: ' + body().slice(0,220));
});

test('el botón de ícono sale sin nombre accesible', function(){
  assert(body().indexOf('sin nombre') > -1, 'no marcó el control sin nombre');
});

console.log('\n\x1b[1mAuditoría completa\x1b[0m');

test('corre sobre el frame sin explotar', function(){
  back(); sel([ pantalla() ]);
  goTo('audit'); click('#ctaAudit');
  assert(true);
});

// Los dibujados son asíncronos (cargan fuentes): se verifican al final
setTimeout(function(){
  console.log('\n\x1b[1mArtefactos dibujados en el canvas\x1b[0m');

  test('el overlay de foco se creó', function(){
    var o = canvasCreated.filter(function(c){
      return c.name && String(c.name).indexOf('Focus order') > -1; });
    assert(o.length > 0, 'no se creó ningún overlay de orden de foco');
  });

  test('el overlay de foco NO queda en el origen 0,0', function(){
    var o = canvasCreated.filter(function(c){
      return c.name && String(c.name).indexOf('Focus order') > -1; }).pop();
    assert(o.x === 1200 && o.y === 400,
      'debería alinearse con el frame (1200,400), quedó en '+o.x+','+o.y);
  });

  test('los badges van en coordenadas relativas al overlay', function(){
    var badges = badgesDe(overlayDe('Focus order'));
    assert(badges.length > 0, 'no hay badges');
    badges.forEach(function(b){
      assert(b.x < 2000 && b.y < 2000,
        'badge en '+b.x+','+b.y+' — parece coordenada absoluta sin rebasar');
    });
  });

  test('los badges NO se encogen sobre el número', function(){
    var badges = badgesDe(overlayDe('Focus order'));
    badges.forEach(function(b){
      eq(b.primaryAxisSizingMode, 'FIXED', 'sizing del badge: ');
      assert(b.width >= 24, 'el badge quedó de '+b.width+'px — se encogió sobre el texto');
    });
  });

  test('el badge usa AZUL para orden de foco', function(){
    var b = badgesDe(overlayDe('Focus order'))[0];
    var c = b.fills[0].color;
    assert(Math.abs(c.b - 0.906) < 0.02 && c.r < 0.3, 'debería ser azul, es rgb('+
      Math.round(c.r*255)+','+Math.round(c.g*255)+','+Math.round(c.b*255)+')');
  });

  console.log('\n\x1b[1mOrden de lectura: color distinto\x1b[0m');

  var pendingReading = false;
  test('se dispara el dibujado del orden de lectura', function(){
    back(); sel([ pantalla() ]);
    goTo('focus');
    click('#s-focus [data-om="reading"]');
    click('#ctaReading');
    click('#aDrawReading');
    // se verifica en el bloque diferido de abajo
    pendingReading = true;
    assert(pendingReading);
  });

  console.log('\n\x1b[1mMatriz: celdas que no colapsan\x1b[0m');

  test('las celdas de la matriz mantienen su tamaño', function(){
    var cells = canvasCreated.filter(function(c){
      return c.name && (String(c.name).indexOf('✓ ') === 0 || String(c.name).indexOf('✕ ') === 0); });
    if (!cells.length) return;   // la matriz no se dibujó en este recorrido
    cells.forEach(function(c){
      eq(c.primaryAxisSizingMode, 'FIXED', 'sizing de celda: ');
      assert(c.width >= 60, 'celda de '+c.width+'px — colapsó');
    });
  });

  console.log('\n\x1b[1mMatriz: tres estados, sin superposición\x1b[0m');

  test('los encabezados de columna no hacen wrap', function(){
    var mx = overlayDe('Matriz de contraste');
    if (!mx) return;
    var textos = canvasCreated.filter(function(c){ return c.type === 'TEXT'; });
    textos.forEach(function(t){
      if (t.textAutoResize === 'HEIGHT' && t.width && t.width < 90) {
        throw new Error('texto de columna con autoresize HEIGHT: puede desbordar');
      }
    });
  });

  test('las celdas distinguen los tres estados', function(){
    var celdas = canvasCreated.filter(function(c){
      return c.name && /:1 · (cualquier texto|solo texto grande|no usar)$/.test(String(c.name)); });
    if (!celdas.length) return;
    var estados = {};
    celdas.forEach(function(c){ estados[String(c.name).split(' · ').pop()] = true; });
    assert(Object.keys(estados).length >= 2,
      'debería haber al menos dos estados distintos, hay: ' + Object.keys(estados).join(', '));
  });

  console.log('\n\x1b[1mARIA: tag en canvas, detalle al costado\x1b[0m');

  test('en el canvas cada control lleva SOLO un tag numerado', function(){
    var ov = overlayDe('[ARIA]');
    if (!ov) return;
    ov.children.forEach(function(tag){
      // Un tag es un frame chico con un único hijo: el número
      assert(tag.children.length <= 1,
        'el tag "'+tag.name+'" tiene '+tag.children.length+' hijos — el detalle va en la hoja');
    });
  });

  test('la hoja de spec se pega al costado derecho del frame', function(){
    var sheet = overlayDe('ARIA spec');
    if (!sheet) return;
    assert(sheet.x > 1200, 'debería alinearse a la derecha del frame en x=1200, está en ' + sheet.x);
  });

  test('la hoja incluye un bloque de código por control', function(){
    var sheet = overlayDe('ARIA spec');
    if (!sheet) return;
    var textos = [];
    (function walk(n){ (n.children||[]).forEach(function(c){
      if (c.type === 'TEXT') textos.push(c.characters || '');
      walk(c); }); })(sheet);
    var conCodigo = textos.filter(function(t){ return t.indexOf('<button') > -1 || t.indexOf('role=') > -1; });
    assert(conCodigo.length > 0, 'no hay ningún snippet de código en la hoja');
  });

  test('propone una acción concreta en vez de marcar en rojo "falta"', function(){
    var sheet = overlayDe('ARIA spec');
    if (!sheet) return;
    var textos = [];
    (function walk(n){ (n.children||[]).forEach(function(c){
      if (c.type === 'TEXT') textos.push(c.characters || '');
      walk(c); }); })(sheet);
    var propuestas = textos.filter(function(t){ return t.indexOf('propuesto') > -1; });
    assert(propuestas.length > 0, 'debería proponer un nombre para el control sin texto');
  });

  console.log('\n\x1b[1mLas anotaciones no bloquean el diseño\x1b[0m');

  test('el overlay de foco queda BLOQUEADO', function(){
    var o = overlayDe('Focus order');
    eq(o.locked, true, 'un overlay sin bloquear se come los clics del diseño: ');
  });

  test('el overlay se colapsa en el panel de capas', function(){
    eq(overlayDe('Focus order').expanded, false);
  });

  test('los badges quedan agrupados en UNA capa', function(){
    var o = overlayDe('Focus order');
    var hijos = (o.children||[]).map(function(c){ return c.name; });
    assert(hijos.indexOf('Badges') > -1, 'falta el grupo Badges. Hijos: ' + hijos.join(', '));
    assert(badgesDe(o).length > 0, 'el grupo Badges está vacío');
  });

  test('el overlay de ARIA también queda bloqueado', function(){
    var o = overlayDe('[ARIA]');
    if (!o) return;
    eq(o.locked, true);
  });

  test('la hoja de spec ARIA queda LIBRE: no tapa nada', function(){
    var sheet = overlayDe('ARIA spec');
    if (!sheet) return;
    eq(sheet.locked, false, 'un documento al costado tiene que poder moverse: ');
  });

  test('la matriz queda LIBRE: es un documento aparte', function(){
    var mx = overlayDe('Matriz de contraste');
    if (!mx) return;
    eq(mx.locked, false);
  });

  setTimeout(function(){
    test('el badge de lectura usa TURQUESA, distinto del de foco', function(){
      var o = overlayDe('Reading order');
      assert(o, 'no se creó el overlay de lectura');
      var b = badgesDe(o)[0];
      var c = b.fills[0].color;
      assert(c.g > 0.7 && c.b > 0.6 && c.r < 0.4, 'debería ser turquesa, es rgb('+
        Math.round(c.r*255)+','+Math.round(c.g*255)+','+Math.round(c.b*255)+')');
    });

    matricesMultiples(auditoriaAcumulativa);
  }, 300);
}, 400);
}

// La auditoría responde por promesa, así que cada paso espera al anterior.
function auditoriaAcumulativa(){
  function n(){ var m = w.document.getElementById('counts').textContent.match(/(\d+) frame/); return m ? Number(m[1]) : 0; }

  console.log('\n\x1b[1mAuditoría acumulativa\x1b[0m');
  back(); sel([ pantalla() ]); goTo('audit');
  var v = w.document.querySelector('#s-audit [data-clear]');
  if (v) v.click();
  click('#ctaAudit');

  setTimeout(function(){
    var primero = n();
    test('auditar deja el frame en el lote', function(){
      eq(primero, 1, 'frames tras la primera auditoría: ');
    });

    var otro = N({ name:'Otra pantalla', x:2600, y:400, width:390, height:400, fills:[F('#FFFFFF')] },
      [ T('Texto flojo', '#CCCCCC', 14, { y:410, width:200, height:20 }) ]);
    sel([ otro ]);
    click('#aAdd');

    setTimeout(function(){
      test('sumar selección agrega otro frame al lote', function(){
        eq(n(), 2, 'frames tras sumar: ');
      });

      click('#aAdd');   // mismo frame otra vez
      setTimeout(function(){
        test('re-auditar el mismo frame lo actualiza, no lo duplica', function(){
          eq(n(), 2, 'no debería crecer: ');
        });

        test('cambiar de selección NO borra el lote', function(){
          sel([ pantalla() ]);
          eq(n(), 2, 'el lote sobrevive al cambio de selección: ');
        });

        test('el botón de descargar HTML aparece con el lote armado', function(){
          assert(w.document.getElementById('aHtml'), 'falta el botón de descarga');
        });

        test('el lote dice qué frames incluye', function(){
          var b = w.document.getElementById('s-audit').textContent;
          assert(b.indexOf('en la auditoría') > -1, 'debería listar los frames del lote');
        });

        test('seleccionar un frame nuevo ofrece auditarlo solo', function(){
          // El bug: después de auditar, seleccionar otro frame dejaba el panel
          // mostrando el anterior, y el único botón era "Sumar selección".
          // La salida para "quiero auditar solo este" era un link chiquito.
          var otro = N({ name:'Pantalla nueva', x:3000, y:400, width:390, height:400,
                         fills:[F('#FFFFFF')] },
            [ T('Texto flojo', '#CCCCCC', 14, { y:410, width:200, height:20 }) ]);
          sel([ otro ]);
          var b = w.document.getElementById('s-audit').textContent;
          assert(b.indexOf('no está en esta auditoría') > -1,
            'debería avisar que lo seleccionado no está en el lote');
          assert(w.document.querySelector('#s-audit [data-solo]'),
            'falta el botón de auditar solo este');
          assert(w.document.querySelector('#s-audit [data-add]'),
            'falta el botón de sumarlo');
        });

        test('el footer también ofrece auditar solo el nuevo', function(){
          assert(w.document.getElementById('aSolo'), 'falta aSolo en el footer');
        });

        test('si el frame ya está en el lote, lo dice', function(){
          sel([ pantalla() ]);
          var b = w.document.getElementById('s-audit').textContent;
          // pantalla() crea un nodo nuevo cada vez, así que no está en el lote
          assert(b.indexOf('no está en esta auditoría') > -1 ||
                 b.indexOf('ya está incluido') > -1,
            'tiene que decir en cuál de los dos casos estamos');
        });

        test('el panel agrupa por impacto', function(){
          var b = w.document.getElementById('s-audit').textContent;
          assert(/Bloquea la tarea|Serio|Moderado|Menor/.test(b),
            'debería agrupar por impacto real, no por nivel WCAG');
        });

        test('el checklist manual va ANTES de los hallazgos', function(){
          // Al final del documento nadie llega: es lo que hay que verificar a
          // mano y es lo que más se saltea.
          var b = w.document.getElementById('s-audit').textContent;
          var iChk = b.indexOf('Revisión manual');
          var iHall = b.indexOf('Bloquea la tarea');
          if (iChk === -1 || iHall === -1) return;
          assert(iChk < iHall, 'el checklist tiene que ir primero');
        });

        test('el panel muestra la cobertura', function(){
          var b = w.document.getElementById('s-audit').textContent;
          assert(b.indexOf('Qué se miró') > -1, 'falta el bloque de cobertura');
          assert(b.indexOf('capas visibles') > -1);
        });

        test('el panel trae el checklist de revisión manual', function(){
          var b = w.document.getElementById('s-audit').textContent;
          assert(b.indexOf('Revisión manual') > -1, 'falta el checklist');
        });

        test('las tareas del checklist se pueden marcar', function(){
          var ck = w.document.querySelector('#s-audit [data-check]');
          assert(ck, 'falta el desplegable del checklist');
          ck.click();
          var chk = w.document.querySelector('#s-audit [data-chk]');
          assert(chk, 'falta alguna tarea');
          chk.checked = true;
          chk.onchange();
          assert(w.document.getElementById('s-audit').textContent.indexOf('1 de') > -1,
            'debería contar las verificadas');
        });

        test('hay filtros por categoría cuando hay varios hallazgos', function(){
          var b = w.document.getElementById('s-audit');
          var f = b.querySelectorAll('[data-fcat]');
          if (f.length === 0) return;   // pocos hallazgos, no hace falta filtrar
          assert(f.length >= 2, 'debería haber al menos "Todo" y una categoría');
        });

        test('filtrar por categoría reduce lo que se ve', function(){
          var b = w.document.getElementById('s-audit');
          var botones = b.querySelectorAll('[data-fcat]');
          if (botones.length < 2) return;
          var antes = b.querySelectorAll('.issue').length;
          var especifico = null;
          botones.forEach(function(x){ if (x.dataset.fcat !== 'all' && !especifico) especifico = x; });
          especifico.click();
          var despues = w.document.getElementById('s-audit').querySelectorAll('.issue').length;
          assert(despues <= antes, 'filtrar no puede mostrar más: ' + despues + ' vs ' + antes);
          assert(despues > 0, 'el filtro no puede vaciar la lista');
          // Volver a todo
          w.document.querySelector('#s-audit [data-fcat="all"]').click();
        });

        test('los hallazgos muestran el número del marcador del canvas', function(){
          var b = w.document.getElementById('s-audit').innerHTML;
          assert(b.indexOf('class="mk') > -1,
            'sin número, no hay forma de conectar el panel con lo pegado en el canvas');
        });

        test('cada hallazgo tiene botón de localizar', function(){
          assert(w.document.querySelector('#s-audit .loc'), 'falta el botón de localizar');
        });

        test('localizar manda select-node con el id correcto', function(){
          var b = w.document.querySelector('#s-audit .loc');
          toCode.length = 0;
          b.click();
          var m = toCode.filter(function(x){ return x.type === 'select-node'; })[0];
          assert(m, 'no mandó select-node');
          eq(m.nodeId, b.dataset.node);
        });

        test('los números del panel no superan los marcadores del canvas', function(){
          // El canvas dibuja un círculo por NODO. Si el panel numera por
          // hallazgo, los números dejan de corresponder.
          var nums = [];
          var re = /class="mk [^"]*">(\d+)</g, m;
          var html = w.document.getElementById('s-audit').innerHTML;
          while ((m = re.exec(html))) nums.push(Number(m[1]));
          if (!nums.length) return;
          var max = Math.max.apply(null, nums);
          var unicos = {};
          nums.forEach(function(n){ unicos[n] = true; });
          assert(max <= 25, 'ningún marcador puede pasar de 25, hay ' + max);
          assert(max >= Object.keys(unicos).length,
            'los números tienen que ser correlativos y repetirse por nodo');
        });

        test('auditar pega los DOS frames automáticamente', function(){
          var resumen  = frameDe('[1] Resumen');
          var analisis = frameDe('[2] Análisis completo');
          assert(resumen,  'falta el frame de resumen');
          assert(analisis, 'falta el frame de análisis');
        });

        test('los frames quedan uno al lado del otro, sin superponerse', function(){
          var r = frameDe('[1] Resumen');
          var a = frameDe('[2] Análisis completo');
          assert(a.x >= r.x + r.width, 'el análisis se pisa con el resumen: resumen termina en ' +
            (r.x + r.width) + ', análisis empieza en ' + a.x);
          eq(r.y, a.y, 'tienen que estar alineados arriba: ');
        });

        test('el documento está armado con secciones en auto-layout', function(){
          // Las secciones las apila un auto-layout: se pueden reordenar y editar
          // en Figma sin que nada se pise. Adentro, cada una es absoluta.
          [ '[1] Resumen', '[2] Análisis completo' ].forEach(function(nombre){
            var f = frameDe(nombre);
            assert(f, 'falta ' + nombre);
            eq(f.layoutMode, 'VERTICAL', nombre + ' tiene que apilar con auto-layout: ');
            eq(f.counterAxisSizingMode, 'FIXED', nombre + ': el ancho no puede crecer con el texto: ');
            var secs = seccionesDe(f);
            assert(secs.length >= 3, nombre + ' tiene ' + secs.length + ' secciones, esperaba varias');
            secs.forEach(function(sec){
              eq(sec.layoutAlign, 'STRETCH', 'la sección "' + sec.name + '" no se estira al ancho');
            });
          });
        });

        // El alto que el texto REALMENTE necesita, calculado acá y no leído del
        // nodo. Si el test usa la misma medida que el código, los dos se
        // equivocan juntos y la superposición pasa desapercibida.
        function altoReal(t){
          var size = t.fontSize || 14;
          var ancho = t.width || 100;
          // Si el nodo declara interlineado, ese manda sobre la estimación
          var lh = t._lineHeightPx ||
            (t.lineHeight && t.lineHeight.unit === 'PIXELS' ? t.lineHeight.value : null) ||
            Math.round(size * 1.35);
          var porLinea = Math.max(1, Math.floor(ancho / (size * 0.52)));
          var lineas = 0;
          String(t.characters || '').split('\n').forEach(function(p){
            lineas += Math.max(1, Math.ceil(p.length / porLinea));
          });
          return Math.ceil(Math.max(1, lineas) * lh);
        }

        test('ningún texto se superpone dentro de su sección', function(){
          [ '[1] Resumen', '[2] Análisis completo' ].forEach(function(nombre){
            var f = frameDe(nombre);
            if (!f) return;
            seccionesDe(f).forEach(function(sec){
              var textos = textosDe(sec)
                .map(function(t){ return { y:t.y, h:altoReal(t), x:t.x,
                                            t:(t.characters||'').slice(0,26) }; })
                .sort(function(p,q){ return p.y - q.y; });
              for (var i = 1; i < textos.length; i++) {
                var ant = textos[i-1], act = textos[i];
                if (Math.abs(ant.x - act.x) >= 5) continue;   // otra columna
                assert(act.y >= ant.y + ant.h - 2,
                  nombre + ' / ' + sec.name + ': "' + act.t + '" (y=' + act.y +
                  ') se pisa con "' + ant.t + '" (y=' + ant.y + ' necesita ' + ant.h + 'px)');
              }
            });
          });
        });

        test('ningún fondo queda dibujado encima del texto', function(){
          // Este fue el bug real: el fondo de las tarjetas se dibujaba dos veces
          // y la segunda copia quedaba ARRIBA de los números, tapándolos. Un
          // test de texto contra texto no lo ve: hay que mirar el z-order.
          [ '[1] Resumen', '[2] Análisis completo' ].forEach(function(nombre){
            var f = frameDe(nombre);
            if (!f) return;
            seccionesDe(f).forEach(function(sec){
              var hijos = sec.children || [];
              hijos.forEach(function(rect, iRect){
                if (rect.type !== 'RECTANGLE') return;
                if (!rect.fills || !rect.fills.length) return;   // transparente, no tapa
                hijos.forEach(function(t, iTxt){
                  if (t.type !== 'TEXT') return;
                  if (iTxt >= iRect) return;                     // el texto va después: queda arriba
                  var solapaX = Math.min(rect.x + rect.width,  t.x + (t.width||0)) - Math.max(rect.x, t.x);
                  var solapaY = Math.min(rect.y + rect.height, t.y + (t.height||0)) - Math.max(rect.y, t.y);
                  assert(!(solapaX > 3 && solapaY > 3),
                    nombre + ' / ' + sec.name + ': un fondo tapa el texto "' +
                    (t.characters||'').slice(0,24) + '"');
                });
              });
            });
          });
        });

        test('cada sección crece con su contenido, nada queda cortado', function(){
          [ '[1] Resumen', '[2] Análisis completo' ].forEach(function(nombre){
            var f = frameDe(nombre);
            if (!f) return;
            seccionesDe(f).forEach(function(sec){
              var maxY = 0;
              (sec.children||[]).forEach(function(c){
                var h = (c.type === 'TEXT') ? altoReal(c) : (c.height||0);
                maxY = Math.max(maxY, (c.y||0) + h); });
              assert(sec.height >= maxY - 2,
                nombre + ' / ' + sec.name + ': mide ' + sec.height +
                ' pero el contenido llega a ' + maxY);
            });
          });
        });

        test('el resumen trae tablero, categorías y cobertura', function(){
          var todo = textosDe(frameDe('[1] Resumen'))
            .map(function(t){ return t.characters||''; }).join(' | ');
          assert(todo.indexOf('Auditoría de') > -1, 'falta el título');
          assert(todo.indexOf('Bloquea la tarea') > -1, 'falta el tablero de impacto');
          assert(todo.indexOf('Qué se auditó') > -1, 'falta la grilla de categorías');
          assert(todo.indexOf('Qué se miró') > -1, 'falta la cobertura');
        });

        test('el análisis trae lo mismo que el HTML', function(){
          var todo = textosDe(frameDe('[2] Análisis completo'))
            .map(function(t){ return t.characters||''; }).join(' | ');
          assert(/\(\d+\)/.test(todo), 'faltan los números de marcador');
          assert(todo.indexOf('ASÍ ESTÁ') > -1, 'falta el ejemplo antes/después');
          assert(todo.indexOf('Qué cambiar') > -1, 'falta la acción concreta');
          assert(todo.indexOf('Revisión manual') > -1, 'falta el checklist');
          assert(todo.indexOf('detectado como') > -1, 'falta el contexto');
        });

        test('al auditar se pegan DOS documentos, no tres', function(){
          // La tarjeta oscura de resumen duplicaba el frame [1] y era la tercera
          // cosa que aparecía. Ahora quedan los marcadores y los dos documentos.
          var docs = canvasCreated.filter(function(c){
            return c.name && /WCAG ▸ \[\d\]/.test(String(c.name)); });
          var nombres = {};
          docs.forEach(function(c){ nombres[c.name] = true; });
          eq(Object.keys(nombres).length, 2, 'documentos distintos: ' + Object.keys(nombres).join(', '));
        });

        test('los dos frames quedan libres, no bloqueados', function(){
          // Son documentos al costado: no tapan nada y tienen que poder moverse
          [ '[1] Resumen', '[2] Análisis completo' ].forEach(function(nombre){
            var f = frameDe(nombre);
            if (f) eq(f.locked, false, nombre + ' debería quedar movible: ');
          });
        });

        test('la salida del reporte es el archivo HTML', function(){
          // "Pegar en Figma" se quitó: nunca se pudo verificar en Figma real y
          // salía mal una y otra vez. El HTML sí se puede verificar acá.
          assert(w.document.getElementById('aHtml'), 'falta el botón de descargar');
          assert(w.document.getElementById('aPaste'), 'falta el botón de volver a pegar');
        });

        test('ya no existe el botón de marcas en canvas', function(){
          assert(!w.document.getElementById('aAnnot'), 'el botón de marcas debería estar eliminado');
        });

        test('la matriz muestra la Aa grande cuando solo sirve para texto grande', function(){
          // Regresión: antes la celda "solo grande" mostraba la muestra chica,
          // que es justo el tamaño que NO se puede usar en ese par.
          var celdas = canvasCreated.filter(function(c){
            return c.name && /solo texto grande$/.test(String(c.name)); });
          celdas.forEach(function(c){
            var tam = (c.children||[]).filter(function(t){ return t.type==='TEXT' && t.characters==='Aa'; })
                       .map(function(t){ return t.fontSize; });
            assert(tam.indexOf(20) > -1, 'debería tener la muestra grande, tiene: '+tam.join(','));
            assert(tam.indexOf(12) === -1, 'no debería mostrar la chica: '+tam.join(','));
          });
        });



        console.log('\n' + (failed===0
          ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
          : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));
        process.exit(failed===0?0:1);
      }, 250);
    }, 250);
  }, 250);
}

// El dibujado de la matriz carga fuentes, así que cada paso espera al anterior.
function matricesMultiples(next){
  console.log('\n\x1b[1mElegir qué auditar\x1b[0m');

  test('los grupos de auditoría llegan al panel', function(){
    back(); goTo('audit');
    // Un test anterior puede haber dejado un lote cargado: el selector de
    // grupos vive en el estado inicial.
    var v = w.document.querySelector('#s-audit [data-clear]');
    if (v) v.click();
    var b = w.document.getElementById('s-audit').textContent;
    assert(b.indexOf('Handoff') > -1, 'debería listar los grupos: ' + b.slice(0,120));
    assert(w.document.querySelectorAll('#s-audit [data-grupo-aud]').length >= 4,
      'faltan checks de grupo');
  });

  test('por defecto están todos seleccionados', function(){
    var checks = w.document.querySelectorAll('#s-audit [data-grupo-aud]');
    var marcados = 0;
    checks.forEach(function(c){ if (c.checked) marcados++; });
    eq(marcados, checks.length, 'todos los grupos activos por defecto: ');
  });

  test('destildar grupos deja solo el que queda marcado', function(){
    // "Solo lo visual" se sacó: se destilda a mano lo que no se quiere revisar
    w.document.querySelectorAll('#s-audit [data-grupo-aud]').forEach(function(c){
      if (c.dataset.grupoAud !== 'visual' && c.checked){
        var x = w.document.querySelector('#s-audit [data-grupo-aud="'+c.dataset.grupoAud+'"]');
        x.checked = false; x.onchange();
      }
    });
    var checks = w.document.querySelectorAll('#s-audit [data-grupo-aud]');
    var marcados = 0;
    checks.forEach(function(c){ if (c.checked) marcados++; });
    eq(marcados, 1, 'solo el grupo visual: ');
  });

  test('la selección de grupos viaja en el mensaje', function(){
    toCode.length = 0;
    click('#ctaAudit');
    var m = toCode.filter(function(x){ return x.type === 'run-audit'; })[0];
    assert(m, 'no mandó run-audit');
    assert(Array.isArray(m.grupos) && m.grupos.length === 1,
      'grupos: ' + JSON.stringify(m.grupos));
    // Volver a dejar todo activo para el resto de los tests
    w.document.querySelector('#s-audit [data-preset="todo"]');
  });

  console.log('\n\x1b[1mTextos alternativos\x1b[0m');

  test('busca las imágenes de la selección', function(){
    back(); goTo('alt');
    // Un test anterior puede haber dejado imágenes cargadas
    // Un test anterior puede haber dejado imágenes cargadas: se vuelve a buscar
    var reload = w.document.querySelector('#s-alt #ctaAlt');
    assert(reload, 'falta el botón de buscar imágenes');
    var foto = N({ name:'Foto de portada', x:0, y:0, width:300, height:200,
                   fills:[{ type:'IMAGE', visible:true }] });
    var p = N({ name:'Card', x:0, y:0, width:340, height:260, fills:[F('#FFFFFF')] }, [ foto ]);
    sel([ p ]);
    click('#ctaAlt');
    var b = w.document.getElementById('s-alt').textContent;
    assert(b.indexOf('Foto de portada') > -1, 'debería listar la imagen: ' + b.slice(0,140));
    assert(b.indexOf('sin confirmar') > -1, 'y marcar que falta confirmarla');
  });

  test('la sugerencia viene ESCRITA en el campo, no como placeholder', function(){
    // Un placeholder obliga a redactar desde cero. La sugerencia escrita se
    // edita o se acepta, que es lo que hace que la sección sirva.
    var t = w.document.querySelector('#s-alt [data-alt]');
    assert(t, 'falta el campo');
    assert(t.value && t.value.length > 3,
      'el campo tiene que venir con la sugerencia: "' + t.value + '"');
  });

  test('cada imagen tiene su campo de alt y su localizar', function(){
    assert(w.document.querySelector('#s-alt [data-alt]'), 'falta el campo de texto');
    assert(w.document.querySelector('#s-alt .loc'), 'falta el botón de localizar');
  });

  test('guardar el alt lo manda al archivo', function(){
    var t = w.document.querySelector('#s-alt [data-alt]');
    t.value = 'Personas mayores haciendo yoga en una sala luminosa';
    t.oninput();
    toCode.length = 0;
    w.document.querySelector('#s-alt [data-save]').click();
    var m = toCode.filter(function(x){ return x.type === 'save-alt'; })[0];
    assert(m, 'no mandó save-alt');
    assert(m.alt.indexOf('yoga') > -1, 'alt: ' + m.alt);
  });

  test('se puede marcar una imagen como decorativa', function(){
    toCode.length = 0;
    w.document.querySelector('#s-alt [data-deco]').click();
    var m = toCode.filter(function(x){ return x.type === 'save-alt'; })[0];
    eq(m.alt, '[decorativa]');
  });

  test('explica de dónde salió la sugerencia', function(){
    var b = w.document.getElementById('s-alt').textContent;
    assert(b.indexOf('nombre de la capa') > -1 || b.indexOf('texto al lado') > -1 ||
           b.indexOf('contexto') > -1,
      'tiene que decir de dónde la sacó');
  });

  test('detecta ilustraciones vectoriales, no solo rellenos de imagen', function(){
    back(); goTo('alt');
    var v = w.document.querySelector('#s-alt #ctaAlt');
    if (v) v.click();
    var ilu = N({ name:'Estado vacío', x:0, y:0, width:200, height:200 }, [
      N({ name:'Vector 1', type:'VECTOR', width:100, height:100, fills:[F('#DDD')] }),
      N({ name:'Vector 2', type:'VECTOR', width:80,  height:80,  fills:[F('#CCC')] })
    ]);
    var p2 = N({ name:'Pantalla vacía', width:400, height:400, fills:[F('#FFFFFF')] }, [ ilu ]);
    sel([ p2 ]);
    click('#ctaAlt');
    var b = w.document.getElementById('s-alt').textContent;
    assert(b.indexOf('Estado vacío') > -1,
      'una ilustración vectorial también es una imagen para WCAG: ' + b.slice(0,140));
  });

  test('marcar decorativa cambia el estado y lo explica', function(){
    var d = w.document.querySelector('#s-alt [data-deco]');
    assert(d, 'falta el botón');
    d.click();
    var b = w.document.getElementById('s-alt').textContent;
    assert(b.indexOf('alt=""') > -1, 'tiene que explicar qué implica ser decorativa');
  });

  test('el borrador con IA y el prompt para copiar están junto al campo', function(){
    // v1.1: el plugin no ve la imagen, pero Claude sí. El resultado entra como
    // borrador; nunca se guarda solo.
    var d = w.document.querySelector('#s-alt [data-deco]');
    if (d && !w.document.querySelector('#s-alt [data-alt]')) d.click();   // volver a editable
    assert(w.document.querySelector('#s-alt [data-ia]'), 'falta el botón de generar con IA');
    assert(w.document.querySelector('#s-alt [data-prompt]'), 'falta el botón de copiar prompt');
  });

  test('lo escrito en un alt sobrevive a volver al menú', function(){
    var t = w.document.querySelector('#s-alt [data-alt]');
    t.value = 'Borrador que no se guardó'; t.oninput();
    back(); goTo('alt');
    eq(w.document.querySelector('#s-alt [data-alt]').value, 'Borrador que no se guardó');
    assert(w.document.getElementById('s-alt').textContent.indexOf('sin guardar') > -1,
      'tiene que avisar que hay cambios sin guardar');
  });

  test('sin key, generar con IA no manda nada y lleva a Ajustes', function(){
    toCode.length = 0;
    w.document.querySelector('#s-alt [data-ia]').click();
    assert(!toCode.some(function(x){ return x.type === 'export-png'; }), 'no debería exportar sin key');
    assert(w.document.getElementById('settings').classList.contains('on'), 'debería abrir Ajustes');
    w.document.getElementById('settings').classList.remove('on');
  });

  test('los alt se pueden pegar en Figma', function(){
    toCode.length = 0;
    var p = w.document.querySelector('#s-alt #pegarAlts');
    assert(p, 'falta el botón de pegar');
    p.click();
    var m = toCode.filter(function(x){ return x.type === 'paste-alts'; })[0];
    assert(m, 'no mandó paste-alts');
    assert(m.images && m.images.length, 'sin imágenes en el mensaje');
  });

  test('el menú muestra la versión y dónde chequear si hay una nueva', function(){
    // Los plugins importados a mano no se actualizan solos: sin esto nadie sabe
    // qué versión está corriendo.
    back();
    // El menú lleva una sola línea con la versión; la advertencia vive en Ayuda
    var m = w.document.getElementById('counts').textContent;
    assert(m.indexOf('v1') > -1, 'falta la versión en el footer de la home: ' + m);
    goTo('help');
    click('#s-help [data-ht="version"]');
    var h = w.document.getElementById('s-help').textContent;
    assert(h.indexOf('no se actualizan solos') > -1, 'falta la advertencia en Ayuda');
    back();
  });

  console.log('\n\x1b[1mCuentagotas\x1b[0m');

  test('activar el cuentagotas avisa al canvas', function(){
    back(); sel([ pantalla() ]);
    goTo('color');
    // El cuentagotas vive en su propia solapa: "Comparar colores"
    herramientaColor('manual');
    var b = w.document.querySelector('#s-color [data-ed="fg"]');
    assert(b, 'falta el botón de cuentagotas');
    toCode.length = 0;
    b.click();
    var m = toCode.filter(function(x){ return x.type === 'set-picker'; })[0];
    assert(m, 'no avisó al canvas');
    eq(m.destino, 'fg');
  });

  test('con el modo activo, el panel explica qué hacer', function(){
    var t = w.document.getElementById('s-color').textContent;
    assert(t.indexOf('Tocá una capa en el canvas') > -1,
      'tiene que decir cómo se usa: ' + t.slice(0,160));
  });

  test('tocar una capa carga su color', function(){
    // Lo que llega del canvas cuando el modo está activo
    toUI({ type:'picked-color', destino:'fg', hex:'#1B4F9C',
           desde:'Título', tipo:'relleno', esTexto:true });
    var inp = w.document.querySelector('#s-color #inFg');
    assert(inp, 'falta el campo');
    eq(inp.value, '#1B4F9C');
  });

  test('una capa sin color sólido lo dice, no falla en silencio', function(){
    toUI({ type:'picker-miss', nombre:'Grupo 4' });
    assert(true);
  });

  test('se pueden ver los colores del frame y elegir uno', function(){
    var vc = w.document.querySelector('#s-color #verColores');
    if (vc) {
      toCode.length = 0;
      vc.click();
      assert(toCode.some(function(x){ return x.type === 'frame-colors'; }),
        'debería pedir los colores del frame');
    }
    toUI({ type:'frame-colors', frameName:'Checkout', colores:[
      { hex:'#1B4F9C', usos:12, ejemplo:'Título' },
      { hex:'#FFFFFF', usos:30, ejemplo:'Fondo' }
    ]});
    var swatches = w.document.querySelectorAll('#s-color [data-color]');
    eq(swatches.length, 2, 'debería mostrar la grilla: ');
    swatches[0].click();
    eq(w.document.querySelector('#s-color #inFg').value, '#1B4F9C');
  });

  console.log('\n\x1b[1mColor: saber de qué habla y dónde está\x1b[0m');

  test('cada par de color tiene su botón de localizar', function(){
    back(); sel([ pantalla() ]);
    goTo('color');
    var b = w.document.getElementById('s-color');
    if (!b.querySelector('.pair')) return;   // sin pares, nada que verificar
    assert(b.querySelector('.pair-loc'),
      'sin localizar, en una pantalla con treinta textos la lista no se recorre');
  });

  test('localizar manda el nodo correcto y no se dispara dos veces', function(){
    var b = w.document.querySelector('#s-color .pair-loc');
    if (!b) return;
    toCode.length = 0;
    b.click();
    var msgs = toCode.filter(function(x){ return x.type === 'select-node'; });
    eq(msgs.length, 1, 'el botón vive dentro de una tarjeta que también localiza: ');
    eq(msgs[0].nodeId, b.dataset.node);
  });

  console.log('\n\x1b[1mMatriz: se pueden tener varias\x1b[0m');

  // Con paleta cargada el botón es "Volver a tomar colores", que la vacía y
  // muestra el de tomar de la selección. Se encadena igual que en el plugin.
  function tomarColores(){
    // La matriz vive en su propia sub-pestaña: un test anterior pudo dejar
    // abierta la de selección.
    if (!w.document.querySelector('#btnReload') && !w.document.querySelector('#btnFromSel')) herramientaColor('mx');
    var reload = w.document.querySelector('#btnReload');
    if (reload) reload.click();
    var desde = w.document.querySelector('#btnFromSel');
    assert(desde, 'no aparece el botón de tomar colores de la selección');
    desde.click();
  }

  function matricesEnCanvas(){
    return canvasCreated.filter(function(c){
      return c.name && String(c.name).indexOf('WCAG ▸ [Matriz]') === 0 && !c.removed; });
  }

  canvasCreated.length = 0;
  back(); goTo('color');

  var pal1 = N({ name:'Paleta marca', x:5000, y:0, width:400, height:100 }, [
    N({ name:'azul',  x:5000, width:80, height:80, fills:[F('#1B4F9C')] }),
    N({ name:'blanco',x:5100, width:80, height:80, fills:[F('#FFFFFF')] })
  ]);
  sel([ pal1 ]);
  tomarColores();
  click('#aMatrix');

  setTimeout(function(){
    var tras1 = matricesEnCanvas().length;
    test('se crea la primera matriz', function(){
      assert(tras1 >= 1, 'no se creó ninguna matriz');
    });

    var pal2 = N({ name:'Paleta alertas', x:6000, y:0, width:400, height:100 }, [
      N({ name:'rojo',  x:6000, width:80, height:80, fills:[F('#B3261E')] }),
      N({ name:'crema', x:6100, width:80, height:80, fills:[F('#FFF7F5')] })
    ]);
    sel([ pal2 ]);
    tomarColores();
    click('#aMatrix');

    setTimeout(function(){
      test('generar una segunda paleta NO borra la primera', function(){
        // El bug: el nombre del frame era fijo, así que cada matriz nueva
        // reemplazaba a la anterior y no se podían comparar dos paletas.
        eq(matricesEnCanvas().length, tras1 + 1,
          'la segunda paleta tiene que sumarse, no reemplazar: ');
      });

      test('las matrices no se pisan entre sí', function(){
        var ms = matricesEnCanvas().slice().sort(function(a,b){ return a.x - b.x; });
        for (var i = 1; i < ms.length; i++) {
          var a = ms[i-1], b = ms[i];
          assert(b.x >= a.x + a.width,
            'la matriz "' + b.name + '" se superpone con "' + a.name + '"');
        }
      });

      test('cada matriz lleva el nombre de su paleta', function(){
        var nombres = matricesEnCanvas().map(function(c){ return c.name; });
        assert(nombres.some(function(n){ return n.indexOf('Paleta marca') > -1; }),
          'nombres: ' + nombres.join(' | '));
        assert(nombres.some(function(n){ return n.indexOf('Paleta alertas') > -1; }),
          'nombres: ' + nombres.join(' | '));
      });

      var antes = matricesEnCanvas();
      var xPrevia = (antes.filter(function(c){
        return c.name.indexOf('Paleta alertas') > -1; })[0] || {}).x;
      click('#aMatrix');   // misma selección, misma paleta

      setTimeout(function(){
        test('regenerar la MISMA paleta la actualiza en su lugar', function(){
          var despues = matricesEnCanvas();
          eq(despues.length, antes.length, 'no debería duplicarse: ');
          var nueva = despues.filter(function(c){
            return c.name.indexOf('Paleta alertas') > -1; })[0];
          assert(nueva, 'desapareció la matriz');
          eq(nueva.x, xPrevia, 'tiene que quedar donde estaba: ');
        });
        next();
      }, 250);
    }, 250);
  }, 250);
}
