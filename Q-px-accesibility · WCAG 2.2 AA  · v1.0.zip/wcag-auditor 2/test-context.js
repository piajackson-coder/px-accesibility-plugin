#!/usr/bin/env node
// Auditoría consciente del contexto: exenciones de la norma, detección de qué
// se está auditando, y los criterios que solo aplican a nivel sistema o pantalla.

var fs = require('fs');
// Se expone el módulo desde code.js con un stub de Figma, igual que las otras suites
var M = require('./_ctx_boot.js');

var passed=0, failed=0;
function test(l,f){ try{ f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'falló'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }

var idc = 0;
function node(p, children){
  var n = Object.assign({ type:'FRAME', name:'capa', visible:true, opacity:1,
    x:0, y:0, width:120, height:40, id:'n'+(++idc) }, p);
  n.absoluteBoundingBox = { x:n.x, y:n.y, width:n.width, height:n.height };
  if (children){ n.children = children; children.forEach(function(c){ c.parent = n; }); }
  return n;
}
function fill(hex){
  return { type:'SOLID', visible:true, color:{
    r:parseInt(hex.slice(1,3),16)/255, g:parseInt(hex.slice(3,5),16)/255, b:parseInt(hex.slice(5,7),16)/255 } };
}
function txt(chars, hex, size, p){
  return node(Object.assign({ type:'TEXT', characters:chars, fontSize:size||14, name:chars,
    fills:[fill(hex||'#000000')], fontName:{family:'Inter',style:'Regular'} }, p||{}));
}

console.log('\n\x1b[1mExenciones que define la propia norma\x1b[0m');

test('un estado disabled no se reporta por contraste', function(){
  // Un disabled gris SIEMPRE va a fallar 4.5:1 — es gris a propósito. WCAG 1.4.3
  // exceptúa los componentes inactivos.
  var t = txt('Enviar', '#B0B0B0', 14, { name:'Label' });
  node({ name:'Button / Disabled', fills:[fill('#F0F0F0')] }, [ t ]);
  assert(M.exencionDe(t), 'debería estar exento');
  eq(M.exencionDe(t).motivo, 'estado inactivo');
});

test('la exención se detecta por variante de instancia, no solo por nombre', function(){
  var t = txt('Enviar', '#B0B0B0', 14, { name:'Label' });
  var inst = node({ type:'INSTANCE', name:'Frame 12', fills:[fill('#F0F0F0')],
    componentProperties:{ 'State':{ value:'Disabled', type:'VARIANT' } } }, [ t ]);
  assert(M.exencionDe(t), 'debería leer la variante de la instancia');
});

test('un logotipo no se reporta por contraste', function(){
  var t = txt('ACME', '#CCCCCC', 20, { name:'Logo / wordmark' });
  node({ name:'Header', fills:[fill('#FFFFFF')] }, [ t ]);
  eq(M.exencionDe(t).motivo, 'logotipo');
});

test('un texto normal NO está exento', function(){
  var t = txt('Descripción', '#B0B0B0', 14, { name:'Body' });
  node({ name:'Card', fills:[fill('#FFFFFF')] }, [ t ]);
  eq(M.exencionDe(t), null);
});

test('la exención se propaga desde el ancestro', function(){
  var t = txt('Campo', '#BBBBBB', 14, { name:'Placeholder' });
  var g = node({ name:'inner' }, [ t ]);
  node({ name:'Input / disabled', fills:[fill('#EEEEEE')] }, [ g ]);
  assert(M.exencionDe(t), 'el estado del padre alcanza');
});

test('el contraste real ya no reporta los exentos', function(){
  var root = node({ name:'Pantalla', fills:[fill('#FFFFFF')] }, [
    txt('Normal flojo', '#BBBBBB', 14, { name:'Body' }),
    node({ name:'Button / Disabled', fills:[fill('#FFFFFF')] }, [
      txt('Enviar', '#BBBBBB', 14, { name:'Label' }) ])
  ]);
  var r = M.auditContrast(root);
  eq(r.issues.length, 1, 'solo el texto normal: ');
  eq(r.issues[0].nodeName, 'Body', 'el único hallazgo tiene que ser el texto normal: ');
  // auditContrast reporta por nombre de capa; el contenido lo trae analyzeContrast
  assert(r.issues[0].message.indexOf('#BBBBBB') > -1);
});

test('la auditoría cuenta cada capa oculta una sola vez', function(){
  // Cada categoría recorre el árbol; antes todas sumaban al mismo contador y
  // un tooltip oculto de 3 capas salía como decenas de capas omitidas.
  var root = node({ name:'Pantalla', width:390, height:600, fills:[fill('#FFFFFF')] }, [
    txt('Visible', '#000000', 16, { name:'Título' }),
    node({ name:'Tooltip', visible:false }, [ txt('a','#000',12), txt('b','#000',12) ])
  ]);
  var a = M.runAudit(root, {});
  eq(a.visibility.hiddenLayersSkipped, 3, 'el tooltip y sus dos textos: ');
});

console.log('\n\x1b[1mTexto sobre imagen: revisión manual, no un número inventado\x1b[0m');

test('detecta un fondo de imagen', function(){
  var t = txt('Título sobre foto', '#FFFFFF', 24, { name:'Hero' });
  node({ name:'Hero bg', fills:[{ type:'IMAGE', visible:true }] }, [ t ]);
  eq(M.requiereRevisionManual(t), 'imagen de fondo');
});

test('detecta un degradado', function(){
  var t = txt('Título', '#FFFFFF', 24, { name:'Hero' });
  node({ name:'bg', fills:[{ type:'GRADIENT_LINEAR', visible:true }] }, [ t ]);
  eq(M.requiereRevisionManual(t), 'degradado de fondo');
});

test('un fondo sólido no pide revisión manual', function(){
  var t = txt('Título', '#000000', 24, { name:'H1' });
  node({ name:'Card', type:'FRAME', fills:[fill('#FFFFFF')] }, [ t ]);
  eq(M.requiereRevisionManual(t), null);
});

test('el hallazgo sale como aviso de revisión manual, no como fallo', function(){
  var t = txt('Sobre la foto', '#FFFFFF', 16, { name:'Hero title' });
  var root = node({ name:'Hero', fills:[{ type:'IMAGE', visible:true }] }, [ t ]);
  var r = M.auditContrast(root);
  eq(r.issues.length, 1);
  eq(r.issues[0].severity, 'warning');
  eq(r.issues[0].detail.manual, true);
});

console.log('\n\x1b[1mDetección de contexto\x1b[0m');

function componentSet(nombre, variantes){
  var hijos = variantes.map(function(v){
    return node({ type:'COMPONENT', name:'State='+v, width:120, height:44, fills:[fill('#1B4F9C')] },
      [ txt('Acción', '#FFFFFF', 15) ]);
  });
  return node({ type:'COMPONENT_SET', name:nombre }, hijos);
}

test('reconoce una librería de componentes', function(){
  var lib = node({ name:'Librería' }, [
    componentSet('Button', ['Default','Hover','Focus','Disabled']),
    componentSet('Input',  ['Default','Focus','Error']),
    componentSet('Chip',   ['Default','Selected'])
  ]);
  eq(M.detectarContexto(lib).tipo, 'design-system');
});

test('reconoce una pantalla', function(){
  var p = node({ name:'Checkout', width:390, height:700, fills:[fill('#FFFFFF')] }, [
    txt('Título', '#000', 24), txt('Cuerpo largo de la pantalla', '#333', 14),
    txt('Otro párrafo más', '#333', 14)
  ]);
  eq(M.detectarContexto(p).tipo, 'pantalla');
});

test('reconoce una página de paleta', function(){
  var muestras = [];
  for (var i = 0; i < 12; i++) muestras.push(node({ name:'c'+i, width:80, height:80, fills:[fill('#3366AA')] }));
  eq(M.detectarContexto(node({ name:'Colores' }, muestras)).tipo, 'paleta');
});

test('reconoce un componente suelto', function(){
  eq(M.detectarContexto(componentSet('Button', ['Default','Hover'])).tipo, 'componente');
});

test('varios frames se reportan como flujo', function(){
  var a = node({ name:'P1', fills:[fill('#FFF')] }, [ txt('uno','#000',14) ]);
  var b = node({ name:'P2', fills:[fill('#FFF')] }, [ txt('dos','#000',14) ]);
  var ctx = M.detectarContexto([a, b]);
  eq(ctx.tipo, 'pantalla');
  assert(ctx.label.indexOf('flujo') > -1, 'label: ' + ctx.label);
});

console.log('\n\x1b[1mCriterios de nivel librería\x1b[0m');

test('marca un control sin variante de foco', function(){
  var lib = node({ name:'Lib' }, [ componentSet('Button / primary', ['Default','Hover','Disabled']) ]);
  var r = M.auditDesignSystem(lib);
  assert(r.issues.some(function(i){ return i.wcag === '2.4.7'; }),
    'debería pedir la variante de foco');
});

test('un control con foco no se marca', function(){
  var lib = node({ name:'Lib' }, [ componentSet('Button / primary', ['Default','Focus','Disabled']) ]);
  var r = M.auditDesignSystem(lib);
  eq(r.issues.filter(function(i){ return i.wcag === '2.4.7'; }).length, 0);
});

test('avisa cuando falta el estado inactivo', function(){
  var lib = node({ name:'Lib' }, [ componentSet('Button / primary', ['Default','Focus']) ]);
  var r = M.auditDesignSystem(lib);
  assert(r.issues.some(function(i){ return i.severity === 'warning'; }));
});

test('no audita componentes que no son controles', function(){
  var deco = node({ type:'COMPONENT_SET', name:'Ilustración' }, [
    node({ type:'COMPONENT', name:'Variant=A', width:200, height:200 })
  ]);
  var r = M.auditDesignSystem(node({ name:'Lib' }, [ deco ]));
  eq(r.issues.length, 0);
});

test('la escala marca un escalón por debajo de 12px', function(){
  var lib = node({ name:'Escala' }, [
    txt('Display','#000',32), txt('Body','#000',16), txt('Micro','#000',10)
  ]);
  var r = M.auditEscalaTipografica(lib);
  assert(r.issues.some(function(i){ return i.detail.size === 10; }),
    'debería marcar el escalón de 10px del sistema');
});

console.log('\n\x1b[1mCriterios de nivel pantalla\x1b[0m');

test('detecta un salto de nivel en los encabezados', function(){
  var p = node({ name:'Pantalla' }, [
    txt('Título','#000',30,{ name:'H1 / Título', y:0 }),
    txt('Sub','#000',18,{ name:'H4 / Sub', y:60 })
  ]);
  var r = M.auditHeadingOrder(p);
  assert(r.issues.some(function(i){ return i.message.indexOf('salta') > -1; }),
    'debería detectar el salto H1 → H4');
});

test('una jerarquía correcta no genera hallazgos de salto', function(){
  var p = node({ name:'Pantalla' }, [
    txt('Título','#000',30,{ name:'H1 / Título', y:0 }),
    txt('Sección','#000',22,{ name:'H2 / Sección', y:60 }),
    txt('Sub','#000',18,{ name:'H3 / Sub', y:120 })
  ]);
  var r = M.auditHeadingOrder(p);
  eq(r.issues.filter(function(i){ return i.message.indexOf('salta') > -1; }).length, 0);
});

test('avisa cuando hay dos H1', function(){
  var p = node({ name:'Pantalla' }, [
    txt('Uno','#000',30,{ name:'H1 / a', y:0 }),
    txt('Dos','#000',30,{ name:'H1 / b', y:60 })
  ]);
  assert(M.auditHeadingOrder(p).issues.some(function(i){ return i.message.indexOf('2 encabezados') > -1; }));
});

test('marca un link con texto vago', function(){
  var p = node({ name:'Pantalla' }, [
    node({ name:'Link / mas' }, [ txt('Ver más','#2547E7',14) ])
  ]);
  var r = M.auditLinkText(p);
  eq(r.issues.length, 1);
  eq(r.issues[0].wcag, '2.4.4');
});

test('un link descriptivo pasa', function(){
  var p = node({ name:'Pantalla' }, [
    node({ name:'Link / garantia' }, [ txt('Cómo funciona la garantía','#2547E7',14) ])
  ]);
  eq(M.auditLinkText(p).issues.length, 0);
});

console.log('\n\x1b[1mCoherencia entre pantallas (3.2.4)\x1b[0m');

test('marca el mismo componente con etiquetas distintas', function(){
  var maestro = { id:'comp-1', name:'Button' };
  var a = node({ name:'P1' }, [
    node({ type:'INSTANCE', name:'Button', mainComponent:maestro }, [ txt('Continuar','#FFF',15) ]) ]);
  var b = node({ name:'P2' }, [
    node({ type:'INSTANCE', name:'Button', mainComponent:maestro }, [ txt('Siguiente','#FFF',15) ]) ]);
  var r = M.auditConsistencia([a, b]);
  eq(r.issues.length, 1);
  eq(r.issues[0].wcag, '3.2.4');
});

test('la misma etiqueta en las dos pantallas pasa', function(){
  var maestro = { id:'comp-2', name:'Button' };
  var a = node({ name:'P1' }, [
    node({ type:'INSTANCE', name:'Button', mainComponent:maestro }, [ txt('Continuar','#FFF',15) ]) ]);
  var b = node({ name:'P2' }, [
    node({ type:'INSTANCE', name:'Button', mainComponent:maestro }, [ txt('Continuar','#FFF',15) ]) ]);
  eq(M.auditConsistencia([a, b]).issues.length, 0);
});

test('con un solo frame no se evalúa coherencia', function(){
  var maestro = { id:'comp-3', name:'Button' };
  var a = node({ name:'P1' }, [
    node({ type:'INSTANCE', name:'Button', mainComponent:maestro }, [ txt('Uno','#FFF',15) ]),
    node({ type:'INSTANCE', name:'Button', mainComponent:maestro }, [ txt('Dos','#FFF',15) ]) ]);
  eq(M.auditConsistencia([a]).issues.length, 0, 'una sola pantalla no dice nada sobre coherencia: ');
});

console.log('\n\x1b[1mCruce de color y tamaño\x1b[0m');

test('18px cuenta como grande y pide 3:1', function(){
  var t = txt('Título','#777777',18);
  eq(M.textMetrics(t).isLarge, true);
  eq(M.textMetrics(t).required, 3);
});

test('14px en negrita cuenta como grande', function(){
  var t = txt('Título','#777777',14);
  t.fontName = { family:'Inter', style:'Bold' };
  eq(M.textMetrics(t).isLarge, true);
});

test('14px normal NO es grande', function(){
  eq(M.textMetrics(txt('Cuerpo','#777777',14)).isLarge, false);
});

test('lee la negrita por fontWeight cuando está', function(){
  var t = txt('Título','#000',14);
  t.fontWeight = 700;
  eq(M.textMetrics(t).bold, true);
});

test('con tamaños mixtos manda el más chico', function(){
  // Un título con una palabra más chica: el requisito lo fija la parte más
  // exigente. Antes caía al default de 16px y se evaluaba mal.
  var t = txt('Mixto','#000',16);
  t.fontSize = Symbol('mixed');
  t.characters = 'abcd';
  t.getRangeFontSize = function(i){ return [24,24,12,24][i]; };
  var m = M.textMetrics(t);
  eq(m.fontSize, 12, 'tiene que tomar el más chico: ');
  eq(m.isLarge, false);
  eq(m.mixto, true);
});

test('negrita mixta solo cuenta si es de punta a punta', function(){
  var t = txt('Mixto','#000',15);
  t.fontName = Symbol('mixed');
  t.characters = 'abc';
  t.getRangeFontName = function(i){ return [{style:'Bold'},{style:'Regular'},{style:'Bold'}][i]; };
  eq(M.textMetrics(t).bold, false, 'una parte sin negrita descalifica al nodo: ');
});

test('los dos motores de contraste dan el mismo veredicto', function(){
  // Antes uno miraba fontWeight y el otro fontName.style, y podían discrepar.
  var t = txt('Encabezado','#AEAEAD',18);
  t.fontName = { family:'Inter', style:'Bold' };
  var root = node({ name:'Card', fills:[fill('#FFFFFF')] }, [ t ]);
  var viejo = M.auditContrast(root).issues[0];
  var nuevo = M.analyzeContrast(root).pairs[0];
  eq(viejo.detail.required, nuevo.requiredAA, 'mismo umbral: ');
  eq(viejo.detail.isLargeText, nuevo.isLarge, 'misma clasificación: ');
});

console.log('\n\x1b[1mARIA: no inventar lo que no corresponde\x1b[0m');

// Reconstruye el caso de la captura: un "Tabs container" con dos tabs adentro.
function tabsContainer(){
  var tab1 = node({ name:'Tab button', width:200, height:60, fills:[fill('#FFFFFF')] }, [
    txt('Upload a new version', '#1B4F9C', 15),
    txt('From your computer', '#666666', 12) ]);
  var tab2 = node({ name:'Tab button', x:210, width:200, height:60, fills:[fill('#FFFFFF')] }, [
    txt('Link from EZshare', '#AEAEAD', 15),
    txt('Connect from the cloud', '#AEAEAD', 12) ]);
  return node({ name:'Tabs container', width:420, height:60, fills:[fill('#FFFFFF')] }, [ tab1, tab2 ]);
}

test('un contenedor de tabs se reconoce como tablist, no como botón', function(){
  // APG: un contenedor de pestañas ES un patrón, role="tablist". Lo que no
  // puede pasar es que salga como <button> con el texto de todas las pestañas.
  var cont = tabsContainer();
  var a = M.suggestAria(cont);
  eq(a.role, 'tablist');
  assert(!a.accessibleName || a.accessibleName.indexOf('EZshare') === -1,
    'el nombre no puede ser el pegoteo de las pestañas: ' + a.accessibleName);
});

test('un contenedor genérico con varios controles sí se descarta', function(){
  var cont = node({ name:'Frame 42', width:420, height:60 }, [
    node({ name:'Button / a', width:100, height:40 }, [ txt('Uno','#000',14) ]),
    node({ name:'Button / b', x:110, width:100, height:40 }, [ txt('Dos','#000',14) ])
  ]);
  var a = M.suggestAria(cont);
  eq(a.skip, true);
  eq(a.skipMotivo, 'agrupación');
});

test('los tabs de adentro SÍ reciben ARIA', function(){
  var cont = tabsContainer();
  var t1 = cont.children[0];
  var a = M.suggestAria(t1);
  assert(!a.skip, 'el tab en sí es un control');
});

test('el nombre accesible NO concatena todo el bloque', function(){
  // Era el bug: el label salía "Upload a new version From your computer Link
  // from EZshare Connect from the cloud", cuatro frases pegoteadas.
  var cont = tabsContainer();
  var t1 = cont.children[0];
  var a = M.suggestAria(t1);
  if (a.accessibleName) {
    assert(a.accessibleName.indexOf('EZshare') === -1,
      'se coló texto de otro control: ' + a.accessibleName);
    assert(a.accessibleName.split(' ').length <= 8,
      'demasiado largo para ser una etiqueta: ' + a.accessibleName);
  }
});

test('tres o más textos se avisan en vez de pegotearse', function(){
  // Un contenedor genérico, NO una card: ahí sí el pegoteo es un error
  var bloque = node({ name:'Frame 12', width:300, height:120, fills:[fill('#FFFFFF')],
                      reactions:[{ trigger:{type:'ON_CLICK'} }] }, [
    txt('Primera frase','#000',16), txt('Segunda frase','#000',14), txt('Tercera frase','#000',12) ]);
  var a = M.suggestAria(bloque);
  eq(a.accessibleName, null, 'no debería inventar un nombre pegoteado');
  assert(a.notes.some(function(n){ return n.text.indexOf('UNA etiqueta') > -1; }));
});

test('un ícono dentro de un botón con texto se marca decorativo', function(){
  var icono = node({ name:'icon / arrow', type:'VECTOR', width:16, height:16, fills:[fill('#FFFFFF')] });
  node({ name:'Button / primary', width:160, height:44, fills:[fill('#1B4F9C')],
         reactions:[{ trigger:{type:'ON_CLICK'} }] }, [ txt('Continuar','#FFFFFF',15), icono ]);
  var a = M.suggestAria(icono);
  eq(a.skip, true);
  eq(a.skipMotivo, 'decorativo');
  assert(a.notes[0].text.indexOf('aria-hidden') > -1, 'debería recomendar aria-hidden');
});

test('una figura sin interacción ni estados no recibe rol inventado', function(){
  var forma = node({ name:'Frame 88', width:40, height:40, fills:[fill('#DDDDDD')] });
  node({ name:'Pantalla', fills:[fill('#FFFFFF')] }, [ forma ]);
  var a = M.suggestAria(forma);
  if (!a.skip) return;   // si no lo detectó como control, mejor todavía
  eq(a.skipMotivo, 'sin interacción');
});

test('una reacción de prototipo manda sobre la heurística de contenedor', function(){
  var cont = tabsContainer();
  cont.reactions = [{ trigger:{ type:'ON_CLICK' } }];
  var a = M.suggestAria(cont);
  assert(!a.skip, 'con reacción explícita sí es un control');
});

test('un botón de ícono suelto sigue pidiendo su aria-label', function(){
  var b = node({ name:'button / icon / close', width:32, height:32, fills:[fill('#EEEEEE')],
                 reactions:[{ trigger:{type:'ON_CLICK'} }] });
  node({ name:'Modal', fills:[fill('#FFFFFF')] }, [ b ]);
  var a = M.suggestAria(b);
  assert(!a.skip, 'este sí necesita ARIA');
  eq(a.needsLabel, true);
});

console.log('\n\x1b[1mEl modal de la captura\x1b[0m');

// Reconstruye la estructura real: un modal con íconos decorativos, dos tabs
// con título y subtítulo, y botones reales.
function modalCard(){
  var iconoDoc = node({ name:'Icon', type:'VECTOR', width:20, height:20, fills:[fill('#1B6FA8')] });
  var iconCont = node({ name:'Icon container', width:38, height:38, fills:[fill('#D6E7F3')] }, [ iconoDoc ]);

  var iconCerrar = node({ name:'Icon / close', type:'VECTOR', x:360, width:14, height:14, fills:[fill('#666666')] });
  var btnCerrar  = node({ name:'Close button', x:356, y:14, width:32, height:32,
                          reactions:[{ trigger:{type:'ON_CLICK'} }] }, [ iconCerrar ]);

  var tab1 = node({ name:'Tab button', y:80, width:200, height:60 }, [
    txt('Upload a new version', '#1B4F9C', 15, { name:'Tab title' }),
    txt('From your computer', '#666666', 12, { name:'Tab subtitle' }) ]);
  var tab2 = node({ name:'Tab button', x:210, y:80, width:200, height:60 }, [
    txt('Link from EZshare', '#AEAEAD', 15, { name:'Tab title' }),
    txt('Connect from the cloud', '#AEAEAD', 12, { name:'Tab subtitle' }) ]);
  var tabs = node({ name:'Tabs container', y:80, width:420, height:60 }, [ tab1, tab2 ]);

  var iconDrop = node({ name:'Dropzone icon', type:'VECTOR', y:220, width:24, height:24, fills:[fill('#999999')] });
  var dropIcon = node({ name:'Dropzone icon container', y:216, width:32, height:32 }, [ iconDrop ]);

  var btnCancel = node({ name:'Cancel button', y:320, width:90, height:40,
                         fills:[fill('#FFFFFF')], reactions:[{ trigger:{type:'ON_CLICK'} }] },
                       [ txt('Cancel', '#111111', 14, { name:'Label' }) ]);
  var btnUpload = node({ name:'Upload button', x:250, y:320, width:150, height:40,
                         fills:[fill('#7BC4E0')], reactions:[{ trigger:{type:'ON_CLICK'} }] },
                       [ txt('Upload Document', '#FFFFFF', 14, { name:'Label' }) ]);

  return node({ name:'Modal card', width:420, height:400, fills:[fill('#FFFFFF')] },
    [ iconCont, btnCerrar, tabs, dropIcon, btnCancel, btnUpload ]);
}

function ariaDe(nombre, modal){
  var found = null;
  (function walk(n){
    if (found) return;
    if (n.name === nombre) { found = n; return; }
    (n.children||[]).forEach(walk);
  })(modal);
  assert(found, 'no existe la capa "' + nombre + '" en el modal');
  return M.suggestAria(found);
}

test('un contenedor de ícono NO es un botón', function(){
  var m = modalCard();
  var a = ariaDe('Icon container', m);
  assert(a.skip || !a.role, 'no debería proponer control: ' + JSON.stringify(a.role));
});

test('un vector de ícono NO es un botón', function(){
  var m = modalCard();
  var a = ariaDe('Icon', m);
  assert(a.skip, 'un vector suelto llamado "Icon" no es un control');
});

test('el ícono de dropzone tampoco', function(){
  var m = modalCard();
  assert(ariaDe('Dropzone icon', m).skip);
  assert(ariaDe('Dropzone icon container', m).skip);
});

test('el ícono DENTRO del botón de cerrar es decorativo, no un control', function(){
  var m = modalCard();
  var a = ariaDe('Icon / close', m);
  eq(a.skip, true);
  eq(a.skipMotivo, 'decorativo');
});

test('el botón de cerrar SÍ pide su aria-label', function(){
  var m = modalCard();
  var a = ariaDe('Close button', m);
  assert(!a.skip, 'es un botón real con prototipo');
  eq(a.needsLabel, true, 'no tiene texto visible: necesita label');
});

test('los tabs SÍ reciben ARIA', function(){
  // Antes se caían: los íconos falsos de adentro hacían que su contenedor
  // pareciera una agrupación de controles.
  var m = modalCard();
  var a = ariaDe('Tab button', m);
  assert(!a.skip, 'un tab es un control y necesita ARIA: ' + JSON.stringify(a.skipMotivo));
});

test('el nombre del tab es solo su título, no título + subtítulo + el otro tab', function(){
  var m = modalCard();
  var a = ariaDe('Tab button', m);
  eq(a.accessibleName, 'Upload a new version');
});

test('el contenedor de tabs sale como tablist con sus restricciones', function(){
  var m = modalCard();
  var a = ariaDe('Tabs container', m);
  eq(a.role, 'tablist');
  assert(a.snippet.indexOf('tablist') > -1, 'el snippet tiene que llevar el rol');
  // Con tabs adentro, la estructura valida: no debería haber aviso estructural
  assert(!a.notes.some(function(n){ return n.text.indexOf('espera hijos') > -1; }),
    'con tabs adentro no debería avisar de estructura');
});

test('un tablist SIN tabs adentro sí avisa de la restricción estructural', function(){
  // ARIA define padres e hijos obligatorios. Un tablist vacío es un rol inválido.
  var vacio = node({ name:'Tabs container', width:400, height:50 }, [
    txt('Solo texto','#000',14) ]);
  var a = M.suggestAria(vacio);
  assert(a.notes.some(function(n){ return n.text.indexOf('espera hijos') > -1; }),
    'debería avisar que falta el role="tab"');
});

test('un tab fuera de un tablist avisa que le falta el padre', function(){
  var suelto = node({ name:'Tab button', width:150, height:44 }, [ txt('Solo','#000',14) ]);
  node({ name:'Frame cualquiera' }, [ suelto ]);
  var a = M.suggestAria(suelto);
  assert(a.notes.some(function(n){ return n.text.indexOf('tiene que estar dentro') > -1; }),
    'debería avisar que role="tab" necesita un tablist');
});

test('los botones con texto no piden aria-label', function(){
  var m = modalCard();
  var a = ariaDe('Upload button', m);
  assert(!a.skip);
  eq(a.needsLabel, false);
  eq(a.accessibleName, 'Upload Document');
});

test('en total, solo los controles reales reciben ARIA', function(){
  var m = modalCard();
  var conAria = [];
  (function walk(n){
    if (M.isFocusable && M.isFocusable(n)) {
      var a = M.suggestAria(n);
      if (!a.skip) conAria.push(n.name);
    }
    (n.children||[]).forEach(walk);
  })(m);
  // Esperados: los dos tabs, cerrar, cancelar y subir. Ningún ícono.
  conAria.forEach(function(nm){
    var l = nm.toLowerCase();
    // Un ícono nunca puede salir como control, salvo que la capa diga "button"
    assert(l.indexOf('icon') === -1 || l.indexOf('button') > -1,
      'se coló un ícono como control: ' + nm);
  });
  assert(conAria.length >= 4, 'faltan controles reales, salieron: ' + conAria.join(', '));
});

console.log('\n\x1b[1mCatálogo de patrones ARIA\x1b[0m');

test('el catálogo cubre los patrones que aparecen en un producto real', function(){
  var esperados = ['button','link','checkbox','radio','switch','tablist','tab',
                   'tabpanel','disclosure','combobox','listbox','option','menu',
                   'menuitem','slider','dialog','alertdialog','navigation','banner',
                   'contentinfo','main','search','alert','status','progressbar',
                   'tooltip','image','icon','heading'];
  var faltan = esperados.filter(function(p){ return !M.ARIA_PATTERNS[p]; });
  assert(faltan.length === 0, 'faltan patrones: ' + faltan.join(', '));
});

test('todo patrón declara nombre accesible y errores típicos', function(){
  Object.keys(M.ARIA_PATTERNS).forEach(function(id){
    var p = M.ARIA_PATTERNS[id];
    assert(p.label, id + ' sin label');
    assert(Array.isArray(p.match) && p.match.length, id + ' sin palabras de match');
    assert(p.errores !== undefined, id + ' sin lista de errores comunes');
  });
});

test('todo patrón focusable declara su interacción de teclado', function(){
  Object.keys(M.ARIA_PATTERNS).forEach(function(id){
    var p = M.ARIA_PATTERNS[id];
    if (!p.focusable) return;
    assert(p.teclado, id + ' es focusable pero no dice qué teclas responde');
  });
});

test('las cinco reglas de ARIA están documentadas', function(){
  [1,2,3,4,5].forEach(function(n){
    assert(M.ARIA_RULES[n] && M.ARIA_RULES[n].titulo && M.ARIA_RULES[n].texto,
      'falta la regla ' + n);
  });
});

test('el reconocimiento prefiere la frase más específica', function(){
  // "tab button" tiene que ganarle a "tab", y "tabs container" también.
  eq(M.reconocerPatron(node({ name:'Tab button' })).id, 'tab');
  eq(M.reconocerPatron(node({ name:'Tabs container' })).id, 'tablist');
  eq(M.reconocerPatron(node({ name:'Button / primary' })).id, 'button');
});

console.log('\n\x1b[1mLas cinco reglas en acción\x1b[0m');

test('regla 1: el nativo se dice en la instrucción, no como nota aparte', function(){
  // Las notas informativas se sacaron del panel: repetían lo que ya dice la
  // instrucción y el snippet, y enterraban lo accionable.
  var b = node({ name:'Button / enviar', width:120, height:44, fills:[fill('#1B4F9C')],
                 reactions:[{trigger:{type:'ON_CLICK'}}] }, [ txt('Enviar','#FFF',15) ]);
  var a = M.suggestAria(b);
  eq(a.nativo, '<button>');
  assert(a.instruccion.indexOf('<button>') > -1, 'la instrucción tiene que decirlo: ' + a.instruccion);
  assert(!a.notes.some(function(n){ return n.severity === 'info'; }),
    'las notas informativas no van al panel');
});

test('regla 3: un rol custom obliga a teclado', function(){
  var t = node({ name:'Tab button', width:150, height:44 }, [ txt('Uno','#000',14) ]);
  node({ name:'Tabs container' }, [ t ]);
  var a = M.suggestAria(t);
  assert(a.notes.some(function(n){ return n.regla === 3; }), 'role=tab tiene que pedir teclado');
  assert(a.snippet.indexOf('tabindex="0"') > -1, 'el snippet tiene que llevar tabindex');
});

test('regla 5: sin nombre, es un fallo', function(){
  var b = node({ name:'Button / icon / close', width:32, height:32,
                 reactions:[{trigger:{type:'ON_CLICK'}}] });
  var a = M.suggestAria(b);
  var r5 = a.notes.filter(function(n){ return n.regla === 5; })[0];
  assert(r5, 'debería citar la regla 5');
  eq(r5.severity, 'fail');
});

test('el snippet de un control sin texto propone la acción', function(){
  var b = node({ name:'Button / icon / close', width:32, height:32,
                 reactions:[{trigger:{type:'ON_CLICK'}}] });
  var a = M.suggestAria(b);
  assert(a.snippet.indexOf('aria-label="Cerrar"') > -1, 'snippet: ' + a.snippet);
  assert(a.snippet.indexOf('aria-hidden="true"') > -1, 'el ícono interno va oculto');
});

console.log('\n\x1b[1mPatrones que la gente suele equivocar\x1b[0m');

test('un modal trae aria-modal y el foco atrapado', function(){
  var m = node({ name:'Modal / confirmar', width:400, height:300, fills:[fill('#FFFFFF')] },
    [ txt('¿Seguro?','#000',18), node({ name:'Button / si', width:80, height:40 }, [ txt('Sí','#000',14) ]),
      node({ name:'Button / no', x:90, width:80, height:40 }, [ txt('No','#000',14) ]) ]);
  var a = M.suggestAria(m);
  eq(a.role, 'dialog');
  assert(a.props.indexOf('aria-modal') > -1);
  assert(a.instruccion.indexOf('Escape') > -1 || a.teclado.indexOf('Escape') > -1,
    'tiene que mencionar Escape y el foco atrapado');
});

test('un alert avisa que interrumpe', function(){
  var al = node({ name:'Toast / error', width:300, height:60 }, [ txt('Falló','#B00',14) ]);
  var a = M.suggestAria(al);
  eq(a.role, 'alert');
  assert(a.errores.some(function(e){ return e.indexOf('status') > -1; }),
    'debería sugerir role=status para lo no urgente');
});

test('una navegación usa <nav> nativo, no role', function(){
  var n = node({ name:'Nav bar / principal', width:400, height:60 }, [
    node({ name:'Link / inicio' }, [ txt('Inicio','#000',14) ]),
    node({ name:'Link / cuenta', x:80 }, [ txt('Cuenta','#000',14) ]) ]);
  var a = M.suggestAria(n);
  eq(a.role, null);
  eq(a.nativo, '<nav>');
});

test('un slider pide min y max, no solo el valor', function(){
  var sl = node({ name:'Slider / precio', width:300, height:30 });
  var a = M.suggestAria(sl);
  assert(a.props.indexOf('aria-valuemin') > -1 && a.props.indexOf('aria-valuemax') > -1,
    'props: ' + a.props.join(','));
});

test('un tooltip recuerda que tiene que aparecer con foco', function(){
  var tt = node({ name:'Tooltip / ayuda', width:150, height:40 }, [ txt('Ayuda','#000',12) ]);
  var a = M.suggestAria(tt);
  eq(a.role, 'tooltip');
  assert(a.errores.some(function(e){ return e.indexOf('foco') > -1; }));
});

console.log('\n\x1b[1mCaso real: catálogo de clases con favoritos\x1b[0m');

function claseCard(titulo, x, maestro){
  var c = node({ name:'Class card', type: maestro ? 'INSTANCE' : 'FRAME',
                 x:x, y:0, width:300, height:260, fills:[fill('#FFFFFF')],
                 reactions:[{ trigger:{type:'ON_CLICK'} }] }, [
    node({ name:'Image', y:0, width:300, height:170, fills:[{type:'IMAGE',visible:true}] }),
    txt(titulo, '#111111', 20, { y:180, name:'Class title' }),
    node({ name:'Chip / duration', y:215, width:80, height:28 }, [ txt('45 Min','#444',13) ]),
    node({ name:'Chip / level', x:90, y:215, width:90, height:28 }, [ txt('Beginner','#444',13) ])
  ]);
  if (maestro) c.mainComponent = maestro;
  return c;
}

test('una card entera es UN control con nombre compuesto', function(){
  // El motor rechazaba 3+ textos por considerarlo un pegoteo. Para una card de
  // contenido eso es justamente el nombre correcto.
  var c = claseCard('Chair Yoga for Seniors', 0);
  node({ name:'Lista', fills:[fill('#FFF')] }, [ c ]);
  var a = M.suggestAria(c);
  assert(!a.skip, 'no debería descartarse: ' + a.skipMotivo);
  assert(a.accessibleName && a.accessibleName.indexOf('Chair Yoga') > -1,
    'nombre: ' + a.accessibleName);
  assert(a.accessibleName.indexOf('45 Min') > -1, 'tiene que incluir los metadatos');
  assert(a.snippet.indexOf('<a href') > -1, 'una card que navega es un enlace: ' + a.snippet);
});

test('si la card es instancia repetida, el nombre va como plantilla', function(){
  var maestro = { id:'comp-card', name:'Class card' };
  var c = claseCard('Chair Yoga for Seniors', 0, maestro);
  node({ name:'Lista', fills:[fill('#FFF')] }, [ c ]);
  var a = M.suggestAria(c);
  assert(/\[.+\]/.test(a.accessibleName),
    'debería ser una plantilla con placeholders, es: ' + a.accessibleName);
  assert(a.accessibleName.indexOf('Chair Yoga') === -1,
    'no puede llevar el texto literal de una instancia');
});

test('varias instancias del mismo componente se agrupan en una sola spec', function(){
  var maestro = { id:'comp-card-2', name:'Class card' };
  var items = ['Chair Yoga','Gentle Stretch','Senior Strength'].map(function(t, i){
    var c = claseCard(t, i*320, maestro);
    node({ name:'Lista', fills:[fill('#FFF')] }, [ c ]);
    return { nodeId:c.id, name:c.name, aria:M.suggestAria(c) };
  });
  var grupos = M.agruparRepetidos(items);
  eq(grupos.length, 1, 'las tres cards son un solo grupo: ');
  eq(grupos[0].marcadores.length, 3);
  assert(grupos[0].esPlantilla, 'el grupo tiene que traer la plantilla');
});

test('el botón de favorito lleva aria-pressed, no un nombre que cambia', function(){
  var b = node({ name:'Favorite button', width:36, height:36,
                 reactions:[{trigger:{type:'ON_CLICK'}}] },
    [ node({ name:'Icon / heart', type:'VECTOR', width:20, height:20, fills:[fill('#B4477F')] }) ]);
  node({ name:'Card', fills:[fill('#FFF')] }, [ b ]);
  var a = M.suggestAria(b);
  assert(a.estados.indexOf('aria-pressed') > -1, 'estados: ' + a.estados.join(','));
  assert(a.snippet.indexOf('aria-pressed') > -1);
  assert(a.notes.some(function(n){ return n.text.indexOf('nombre NO cambia') > -1; }),
    'tiene que aclarar que el nombre es fijo');
});

test('el ítem activo de la navegación pide aria-current', function(){
  var home = node({ name:'Nav item / home', y:0, width:80, height:56 }, [ txt('Home','#0F6C63',12) ]);
  var fav  = node({ name:'Nav item / favorites', y:60, width:80, height:56,
                    fills:[fill('#DFF3F1')] }, [ txt('Favorites','#0F6C63',12) ]);
  node({ name:'Sidebar nav', width:100, height:300 }, [ home, fav ]);
  var a = M.suggestAria(fav);
  assert(a.props.indexOf('aria-current') > -1, 'props: ' + a.props.join(','));
  assert(a.snippet.indexOf('aria-current="page"') > -1, 'snippet: ' + a.snippet);
});

test('un ítem de nav que se llama "favorites" NO es un botón de favorito', function(){
  // La palabra estaba en las dos listas: la precedencia la decide el patrón.
  var home = node({ name:'Nav item / home', y:0, width:80, height:56 }, [ txt('Home','#000',12) ]);
  var fav  = node({ name:'Nav item / favorites', y:60, width:80, height:56,
                    fills:[fill('#DFF3F1')] }, [ txt('Favorites','#000',12) ]);
  node({ name:'Sidebar nav', width:100, height:300 }, [ home, fav ]);
  var a = M.suggestAria(fav);
  eq(a.estados.indexOf('aria-pressed'), -1, 'no debería llevar aria-pressed');
});

test('la snackbar es una región viva, no una agrupación', function(){
  var sb = node({ name:'Snackbar', width:600, height:64, fills:[fill('#FFFFFF')] }, [
    txt('Name was removed from Favorites','#111',14),
    node({ name:'Undo button', x:430, width:70, height:36,
           reactions:[{trigger:{type:'ON_CLICK'}}] }, [ txt('UNDO','#0F6C63',13) ]),
    node({ name:'Close button', x:520, width:36, height:36,
           reactions:[{trigger:{type:'ON_CLICK'}}] },
      [ node({ name:'Icon / close', type:'VECTOR', width:14, height:14 }) ])
  ]);
  node({ name:'Pantalla', fills:[fill('#FFF')] }, [ sb ]);
  var a = M.suggestAria(sb);
  assert(!a.skip, 'no puede descartarse por tener botones adentro: ' + a.skipMotivo);
  eq(a.role, 'alert');
  eq(a.accessibleName, null, 'el nombre es su contenido, no un aria-label');
  assert(a.snippet.indexOf('aria-live') > -1, 'falta la región viva: ' + a.snippet);
  assert(a.notes.some(function(n){ return n.text.indexOf('ANTES de llenarse') > -1; }),
    'tiene que avisar que el contenedor debe existir antes');
});

test('un botón que dice solo "UNDO" se marca como vago', function(){
  var b = node({ name:'Undo button', width:70, height:36,
                 reactions:[{trigger:{type:'ON_CLICK'}}] }, [ txt('UNDO','#0F6C63',13) ]);
  node({ name:'Snackbar', fills:[fill('#FFF')] }, [ b ]);
  var a = M.suggestAria(b);
  assert(a.etiquetaVaga, 'debería marcarse como vago');
  assert(a.notes.some(function(n){ return n.text.indexOf('no dice sobre qué actúa') > -1; }));
});

test('un botón con etiqueta descriptiva no se marca', function(){
  var b = node({ name:'Button / guardar', width:160, height:44,
                 reactions:[{trigger:{type:'ON_CLICK'}}] },
    [ txt('Guardar cambios','#FFF',15) ]);
  node({ name:'Form', fills:[fill('#FFF')] }, [ b ]);
  assert(!M.suggestAria(b).etiquetaVaga);
});

console.log('\n\x1b[1mCriterio: qué ARIA vale la pena anotar\x1b[0m');

test('un botón con texto visible NO necesita anotación', function(){
  // Listar todos los controles producía un choclo donde la mitad decía "con
  // <button> alcanza". Correcto e inútil: no hay nada que implementar distinto.
  var b = node({ name:'Button / guardar', width:160, height:44,
                 reactions:[{trigger:{type:'ON_CLICK'}}] }, [ txt('Guardar','#FFF',15) ]);
  node({ name:'Form', fills:[fill('#FFF')] }, [ b ]);
  eq(M.ariaVale(M.suggestAria(b)), null);
});

test('un botón de solo ícono SÍ la necesita', function(){
  var b = node({ name:'Button / icon / close', width:32, height:32,
                 reactions:[{trigger:{type:'ON_CLICK'}}] },
    [ node({ name:'Icon / close', type:'VECTOR', width:14, height:14 }) ]);
  node({ name:'Modal', fills:[fill('#FFF')] }, [ b ]);
  var v = M.ariaVale(M.suggestAria(b));
  assert(v, 'sin nombre accesible el lector dice "botón" y nada más');
  eq(v.motivo, 'sin nombre');
  eq(v.prioridad, 0, 'es lo más grave: ');
});

test('un control con estado la necesita aunque tenga texto', function(){
  var t = node({ name:'Tab button / uno', width:160, height:44 }, [ txt('Overview','#111',14) ]);
  node({ name:'Tabs container' }, [ t ]);
  var v = M.ariaVale(M.suggestAria(t));
  assert(v, 'el estado lo actualiza el código, no el diseño');
  eq(v.motivo, 'estado');
});

test('una región viva la necesita', function(){
  var sb = node({ name:'Snackbar', width:600, height:64, fills:[fill('#FFF')] },
    [ txt('Guardado','#111',14) ]);
  node({ name:'Pantalla', fills:[fill('#FFF')] }, [ sb ]);
  var v = M.ariaVale(M.suggestAria(sb));
  assert(v, 'lo que cambia solo tiene que anunciarse');
});

test('lo descartado nunca cuenta como que vale', function(){
  var icono = node({ name:'Icon / deco', type:'VECTOR', width:16, height:16 });
  node({ name:'Card', fills:[fill('#FFF')] }, [ icono ]);
  eq(M.ariaVale(M.suggestAria(icono)), null);
});

test('sobre una pantalla real la lista se reduce mucho', function(){
  var hijos = [];
  for (var i = 0; i < 12; i++) {
    hijos.push(node({ name:'Button / accion'+i, y:i*50, width:160, height:44,
      reactions:[{trigger:{type:'ON_CLICK'}}] }, [ txt('Acción '+i,'#FFF',15) ]));
  }
  hijos.push(node({ name:'Button / icon / close', x:300, width:32, height:32,
    reactions:[{trigger:{type:'ON_CLICK'}}] },
    [ node({ name:'Icon / close', type:'VECTOR', width:14, height:14 }) ]));
  var p = node({ name:'Pantalla', width:600, height:800, fills:[fill('#FFF')] }, hijos);

  var stops = M.collectFocusStops(p, [], 0);
  var valen = 0;
  stops.forEach(function(n){
    var a = M.suggestAria(n);
    if (!a.skip && M.ariaVale(a)) valen++;
  });
  assert(stops.length >= 12, 'controles detectados: ' + stops.length);
  assert(valen <= 3, 'de ' + stops.length + ' controles solo ' + valen +
    ' deberían necesitar anotación, dio ' + valen);
});

console.log('\n' + (failed===0
  ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
  : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));
process.exit(failed===0?0:1);
