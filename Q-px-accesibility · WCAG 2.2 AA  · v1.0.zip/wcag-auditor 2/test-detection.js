#!/usr/bin/env node
// Tests de lo nuevo: detección estructural de interactivos, análisis de
// contraste con todos los pares, inventario tipográfico y orden de lectura.

var fs = require('fs');
var src = fs.readFileSync(__dirname + '/code.js', 'utf8');

global.figma = {
  showUI:function(){}, on:function(){}, ui:{postMessage:function(){}, onmessage:null},
  currentPage:{selection:[],children:[]}, root:{children:[]},
  viewport:{scrollAndZoomIntoView:function(){}},
  getNodeById:function(){return null;}, getStyleById:function(){return null;},
  getLocalPaintStyles:function(){return [];}, loadFontAsync:function(){return Promise.resolve();},
  createFrame:function(){return {children:[],fills:[],resize:function(){},appendChild:function(){},
    setPluginData:function(){},getPluginData:function(){return '';}};},
  createText:function(){return {fills:[]};}, createLine:function(){return {strokes:[],resize:function(){}};},
  createRectangle:function(){return {fills:[],strokes:[],resize:function(){}};},
  clientStorage:{getAsync:function(){return Promise.resolve(null);},setAsync:function(){return Promise.resolve();}}
};
global.__html__ = '';

fs.writeFileSync(__dirname + '/_t3.js', src +
  ';module.exports={detectInteractive,isInteractive,analyzeContrast,analyzeTypography,auditNonTextContrast,auditContrast,getAllNodes,esCampoDeFormulario,pareceCampoPorForma,inferirJerarquiaTexto,auditHeadingStructure,esBarraFlotantePorForma,' +
  'buildReadingOrder,buildFocusOrder,describeContainer};');
var M = require(__dirname + '/_t3.js');

var passed=0, failed=0;
function test(l,f){ try{ f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'assertion failed'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }

var idc = 0;
function node(p, children){
  var n = Object.assign({ type:'FRAME', name:'capa', visible:true, opacity:1,
    x:0, y:0, width:120, height:40, id:'n'+(++idc) }, p);
  n.absoluteBoundingBox = { x:n.x, y:n.y, width:n.width, height:n.height };
  if (children){ n.children = children; children.forEach(function(c){ c.parent = n; }); }
  return n;
}
function fill(hex, op){
  var f = { type:'SOLID', visible:true, color:{
    r:parseInt(hex.slice(1,3),16)/255, g:parseInt(hex.slice(3,5),16)/255, b:parseInt(hex.slice(5,7),16)/255 } };
  if (op !== undefined) f.opacity = op;
  return f;
}
function txt(chars, hex, size, p){
  return node(Object.assign({ type:'TEXT', characters:chars, fontSize:size||14,
    name:chars, fills:[fill(hex||'#000000')], fontName:{family:'Inter',style:'Regular'} }, p||{}));
}

console.log('\n\x1b[1mDetección estructural de elementos interactivos\x1b[0m');
console.log('  \x1b[2m(antes solo miraba el nombre de la capa, por eso no encontraba nada)\x1b[0m');

test('detecta por interacción de prototipo, sin importar el nombre', function(){
  var n = node({ name:'Rectangle 47', reactions:[{ trigger:{type:'ON_CLICK'} }] });
  var d = M.detectInteractive(n);
  eq(d.is, true);
  assert(d.why.indexOf('prototipo') > -1, 'debería explicar que es por el prototipo');
  eq(d.confidence, 1);
});

test('detecta por variantes de estado del componente', function(){
  var set = { type:'COMPONENT_SET', children:[] };
  var comp = node({ type:'COMPONENT', name:'Group 12' });
  set.children = [ { name:'State=Default' }, { name:'State=Hover' }, { name:'State=Pressed' } ];
  comp.parent = set;
  var d = M.detectInteractive(comp);
  eq(d.is, true);
  assert(d.why.indexOf('variantes de estado') > -1);
});

test('detecta por propiedades de instancia', function(){
  var n = node({ type:'INSTANCE', name:'Frame 3',
    componentProperties:{ 'State':{ value:'Hover', type:'VARIANT' } } });
  eq(M.detectInteractive(n).is, true);
});

test('sigue detectando por nombre de capa', function(){
  eq(M.detectInteractive(node({ name:'Button / Primary' })).is, true);
});

test('detecta un contenedor con forma de botón sin nombre útil', function(){
  var n = node({ name:'Frame 128', width:140, height:44, fills:[fill('#1B4F9C')] },
    [ txt('Continuar', '#FFFFFF', 16) ]);
  var d = M.detectInteractive(n);
  eq(d.is, true);
  assert(d.why.indexOf('proporciones de control') > -1);
});

test('detecta un cuadrado chico con relleno como botón de ícono', function(){
  var n = node({ name:'Frame 9', width:32, height:32, fills:[fill('#DCE9F9')] });
  eq(M.detectInteractive(n).is, true);
});

test('NO marca un párrafo largo dentro de una card', function(){
  var n = node({ name:'Frame 4', width:300, height:70, fills:[fill('#FFFFFF')] },
    [ txt('Este es un párrafo largo de varias palabras que describe algo', '#111111', 14) ]);
  eq(M.detectInteractive(n).is, false);
});

test('NO marca un texto suelto', function(){
  eq(M.detectInteractive(txt('Título', '#000000', 24)).is, false);
});

test('NO marca un frame gigante de página', function(){
  eq(M.detectInteractive(node({ name:'Frame 1', width:1440, height:900, fills:[fill('#FFFFFF')] })).is, false);
});

console.log('\n\x1b[1mAnálisis de contraste estructurado\x1b[0m');

function botón(){
  return node({ name:'Frame 88', width:140, height:44, fills:[fill('#1B4F9C')] },
    [ txt('Pagar', '#FFFFFF', 16) ]);
}

test('devuelve TODOS los pares, no solo los que fallan', function(){
  var card = node({ name:'Card', width:320, height:200, fills:[fill('#FFFFFF')] }, [
    txt('Título', '#11161C', 20),
    txt('Descripción', '#7BA7E0', 14),
    txt('Nota', '#9AA5B1', 12)
  ]);
  var r = M.analyzeContrast(card);
  eq(r.pairs.length, 3, 'los tres textos: ');
  assert(r.pairs.some(function(p){ return p.passAA; }), 'debería haber alguno que pasa');
  assert(r.pairs.some(function(p){ return !p.passAA; }), 'debería haber alguno que falla');
});

test('ordena los pares de peor a mejor', function(){
  var card = node({ name:'Card', fills:[fill('#FFFFFF')] }, [
    txt('bueno', '#000000', 14), txt('malo', '#EEEEEE', 14)
  ]);
  var r = M.analyzeContrast(card);
  eq(r.pairs[0].text, 'malo', 'el peor va primero: ');
});

test('identifica el fondo propio del botón', function(){
  var r = M.analyzeContrast(botón());
  eq(r.container.hex, '#1B4F9C');
  eq(r.container.transparent, false);
});

test('marca cuando el contenedor no tiene relleno propio', function(){
  var inner = node({ name:'Group', width:100, height:40 }, [ txt('Hola', '#000000', 14) ]);
  node({ name:'Página', fills:[fill('#F7F8FA')] }, [ inner ]);
  var r = M.analyzeContrast(inner);
  eq(r.container.transparent, true);
  assert(r.container.note.indexOf('no tiene relleno propio') > -1);
});

test('dice de qué capa salió el fondo de cada texto', function(){
  var r = M.analyzeContrast(botón());
  eq(r.pairs[0].bgSource, 'Frame 88');
});

test('el botón se reporta como interactivo', function(){
  eq(M.analyzeContrast(botón()).interactive.is, true);
});

test('calcula bien texto blanco sobre azul oscuro', function(){
  var p = M.analyzeContrast(botón()).pairs[0];
  eq(p.fg, '#FFFFFF');
  eq(p.bg, '#1B4F9C');
  // 7.94 verificado a mano con la fórmula de luminancia relativa de WCAG
  assert(Math.abs(p.ratio - 7.94) < 0.02, 'ratio esperado 7.94, dio '+p.ratio);
  eq(p.passAA, true);
});

test('16px normal cuenta como texto normal, no grande', function(){
  var p = M.analyzeContrast(botón()).pairs[0];
  eq(p.isLarge, false);
  eq(p.requiredAA, 4.5);
});

test('18px cuenta como texto grande', function(){
  var n = node({ name:'c', fills:[fill('#FFFFFF')] }, [ txt('Grande', '#777777', 18) ]);
  var p = M.analyzeContrast(n).pairs[0];
  eq(p.isLarge, true);
  eq(p.requiredAA, 3);
});

test('ignora los textos de capas ocultas', function(){
  var card = node({ name:'Card', fills:[fill('#FFFFFF')] }, [
    txt('visible', '#000000', 14),
    node({ name:'oculto', visible:false }, [ txt('escondido', '#EEEEEE', 14) ])
  ]);
  var r = M.analyzeContrast(card);
  eq(r.pairs.length, 1);
  assert(r.hiddenSkipped >= 1, 'debería contar lo omitido');
});

test('trae sugerencia solo cuando falla', function(){
  var card = node({ name:'Card', fills:[fill('#FFFFFF')] }, [
    txt('malo', '#BBBBBB', 14), txt('bueno', '#000000', 14)
  ]);
  var r = M.analyzeContrast(card);
  var malo = r.pairs.filter(function(p){ return p.text==='malo'; })[0];
  var bueno = r.pairs.filter(function(p){ return p.text==='bueno'; })[0];
  assert(malo.suggestionAA, 'el que falla debería traer sugerencia');
  eq(bueno.suggestionAA, null, 'el que pasa no: ');
});

console.log('\n\x1b[1mInventario tipográfico\x1b[0m');

test('lista todos los textos, no solo los problemáticos', function(){
  var f = node({ name:'F' }, [ txt('a','#000',24), txt('b','#000',16), txt('c','#000',10) ]);
  var t = M.analyzeTypography(f);
  eq(t.total, 3);
  eq(t.conRecomendaciones, 1, 'solo el de 10px lleva recomendación: ');
  eq(t.withProblems, 0, 'y ninguno es un riesgo de WCAG: ');
});

test('arma la escala tipográfica agrupando por tamaño y estilo', function(){
  var f = node({ name:'F' }, [ txt('a','#000',16), txt('b','#000',16), txt('c','#000',24) ]);
  var t = M.analyzeTypography(f);
  eq(t.scale.length, 2, 'dos tamaños distintos: ');
  eq(t.scale[0].size, 24, 'ordenado de mayor a menor: ');
  var s16 = t.scale.filter(function(x){ return x.size===16; })[0];
  eq(s16.count, 2);
});

test('un texto de 10px es una recomendación, no una falla de WCAG', function(){
  // WCAG no fija un tamaño mínimo: 1.4.4 habla de poder ampliar al 200%
  var t = M.analyzeTypography(node({ name:'F' }, [ txt('chico','#000',10) ]));
  eq(t.items[0].problems[0].tipo, 'recomendacion');
  eq(t.items[0].problems[0].severity, 'info');
});

test('el interlineado corto se recomienda solo en párrafos', function(){
  var parrafo = txt('Este es un párrafo largo que se lee de corrido y ocupa varias líneas', '#000', 16);
  parrafo.lineHeight = { unit:'PIXELS', value:18 };
  var titulo = txt('Finalizar compra', '#000', 24);
  titulo.lineHeight = { unit:'PIXELS', value:28 };
  var t = M.analyzeTypography(node({ name:'F', width:390 }, [ parrafo, titulo ]));
  var p = t.items.filter(function(i){ return i.text.indexOf('párrafo') > -1; })[0];
  var h = t.items.filter(function(i){ return i.text === 'Finalizar compra'; })[0];
  assert(p.problems.some(function(x){ return x.wcag === '1.4.8' && x.tipo === 'recomendacion'; }),
    'el párrafo lleva la recomendación de 1.4.8');
  eq(h.problems.length, 0, 'a un título no se le pide interlineado de párrafo: ');
});

test('el truncado sí es un riesgo de WCAG', function(){
  var n = txt('Texto cortado','#000',14); n.textTruncation = 'ENDING';
  var t = M.analyzeTypography(node({ name:'F' }, [ n ]));
  eq(t.items[0].problems[0].tipo, 'riesgo');
  eq(t.withProblems, 1);
});

test('detecta mobile o desktop por el ancho del frame', function(){
  eq(M.analyzeTypography(node({ name:'App', width:390 }, [ txt('a','#000',14) ])).dispositivo.tipo, 'mobile');
  eq(M.analyzeTypography(node({ name:'Web', width:1440 }, [ txt('a','#000',14) ])).dispositivo.tipo, 'desktop');
});

test('lista las familias tipográficas en uso', function(){
  var a = txt('a','#000',16); a.fontName = { family:'Inter', style:'Regular' };
  var b = txt('b','#000',16); b.fontName = { family:'Roboto', style:'Bold' };
  var t = M.analyzeTypography(node({ name:'F' }, [ a, b ]));
  eq(t.families.length, 2);
});

console.log('\n\x1b[1mOrden de lectura\x1b[0m');

test('incluye textos además de controles', function(){
  var f = node({ name:'F' }, [
    txt('Título','#000',24,{ y:0 }),
    node({ name:'Button / ok', y:60 })
  ]);
  var r = M.buildReadingOrder(f);
  eq(r.stops.length, 2);
  eq(r.stops[0].kind, 'text');
  eq(r.stops[1].kind, 'control');
});

test('el orden de foco NO incluye texto plano', function(){
  var f = node({ name:'F' }, [
    txt('Solo un párrafo','#000',14,{ y:0 }),
    node({ name:'Button / ok', y:60 })
  ]);
  eq(M.buildFocusOrder(f).stops.length, 1, 'solo el botón: ');
});

test('omite lo oculto', function(){
  var f = node({ name:'F' }, [
    txt('visible','#000',14,{ y:0 }),
    node({ name:'oculto', visible:false, y:50 }, [ txt('no','#000',14) ])
  ]);
  eq(M.buildReadingOrder(f).stops.length, 1);
});

test('numera desde 1', function(){
  var f = node({ name:'F' }, [ txt('a','#000',14,{y:0}), txt('b','#000',14,{y:50}) ]);
  var r = M.buildReadingOrder(f);
  eq(r.stops[0].index, 1); eq(r.stops[1].index, 2);
});

console.log('\n\x1b[1mTextos que antes se perdían\x1b[0m');

test('una card con forma de botón NO se traga sus textos', function(){
  // La heurística de forma marca esta card como interactiva. Antes eso hacía
  // que el orden de lectura la tomara como hoja y perdiera los 3 textos.
  var card = node({ name:'Frame 44', width:300, height:80, fills:[fill('#FFFFFF')],
                    reactions:[{ trigger:{type:'ON_CLICK'} }] }, [
    txt('Título de la card', '#000', 16, { y:0 }),
    txt('Una descripción', '#000', 14, { y:24 }),
    txt('Ver más', '#000', 12, { y:48 })
  ]);
  var r = M.buildReadingOrder(node({ name:'root' }, [ card ]));
  var textos = r.stops.filter(function(s2){ return s2.kind === 'text'; });
  eq(textos.length, 3, 'los tres textos tienen que aparecer: ');
});

test('un botón real con una sola etiqueta SÍ es una hoja', function(){
  var b = node({ name:'Button / primary', width:140, height:44, fills:[fill('#1B4F9C')] },
    [ txt('Pagar', '#FFF', 16) ]);
  var r = M.buildReadingOrder(node({ name:'root' }, [ b ]));
  eq(r.stops.length, 1, 'una sola parada: ');
  eq(r.stops[0].kind, 'control');
});

test('el orden de foco tampoco se traga controles anidados', function(){
  var card = node({ name:'Frame 44', width:300, height:80, fills:[fill('#FFFFFF')],
                    reactions:[{ trigger:{type:'ON_CLICK'} }] }, [
    txt('Título', '#000', 16, { y:0 }),
    txt('Texto', '#000', 14, { y:24 }),
    node({ name:'Button / accion', y:48, width:80, height:28, fills:[fill('#000000')] })
  ]);
  var f = M.buildFocusOrder(node({ name:'root' }, [ card ]));
  assert(f.stops.some(function(s2){ return s2.name === 'Button / accion'; }),
    'el botón de adentro tiene que aparecer. Paradas: ' + f.stops.map(function(x){return x.name;}).join(', '));
});

test('acepta selección múltiple', function(){
  var a = node({ name:'Frame A', x:0, y:0 }, [ txt('uno', '#000', 14) ]);
  var b = node({ name:'Frame B', x:0, y:200 }, [ txt('dos', '#000', 14) ]);
  var r = M.buildReadingOrder([ a, b ]);
  eq(r.stops.length, 2, 'los dos frames: ');
  eq(r.stops[0].text, 'uno', 'ordenados por posición: ');
});

test('la selección múltiple respeta el orden visual, no el de clic', function(){
  var abajo  = node({ name:'B', x:0, y:400 }, [ txt('abajo', '#000', 14, { y:400 }) ]);
  var arriba = node({ name:'A', x:0, y:0 },   [ txt('arriba', '#000', 14, { y:0 }) ]);
  var r = M.buildReadingOrder([ abajo, arriba ]);   // clickeados al revés
  eq(r.stops[0].text, 'arriba');
});

console.log('\n\x1b[1mContraste no textual: superficie vs glifo\x1b[0m');

// Reconstruye el caso de la captura: un contenedor celeste con un ícono azul
// adentro, sobre fondo blanco.
function iconContainer(fondoHex, glifoHex){
  var glifo = node({ name:'Vector', type:'VECTOR', width:20, height:20,
                     fills:[fill(glifoHex)] });
  var cont = node({ name:'Icon container', width:38, height:38,
                    fills:[fill(fondoHex)] }, [ glifo ]);
  node({ name:'Pantalla', width:400, height:400, fills:[fill('#FFFFFF')] }, [ cont ]);
  return cont;
}

test('NO reporta el fondo del contenedor de ícono contra el blanco', function(){
  // Era el falso positivo: #D6E7F3 sobre #FFFFFF da 1.27:1, pero ese celeste
  // es la superficie donde vive el ícono, no un elemento que deba identificarse.
  var c = iconContainer('#D6E7F3', '#1B6FA8');
  var r = M.auditNonTextContrast(c);
  var falso = r.issues.filter(function(i){ return i.nodeName === 'Icon container'; });
  eq(falso.length, 0, 'el contenedor no debería reportarse: ' +
     falso.map(function(i){ return i.message; }).join(' | '));
});

test('SÍ mide el glifo contra el fondo del contenedor', function(){
  // Azul flojo sobre celeste: ahí sí hay un problema real
  var c = iconContainer('#D6E7F3', '#B9D4E8');
  var r = M.auditNonTextContrast(c);
  assert(r.issues.length > 0, 'debería detectar el glifo de bajo contraste');
  eq(r.issues[0].detail.bg, '#D6E7F3', 'tiene que medir contra el fondo del contenedor: ');
});

test('un glifo con buen contraste sobre su contenedor pasa', function(){
  var c = iconContainer('#D6E7F3', '#0B3A5C');
  var r = M.auditNonTextContrast(c);
  eq(r.issues.length, 0);
  assert(r.passed > 0, 'debería contarlo como que pasa');
});

test('un ícono suelto sin contenedor sí se mide contra su fondo', function(){
  var glifo = node({ name:'icon / alerta', type:'VECTOR', width:20, height:20,
                     fills:[fill('#EFEFEF')] });
  node({ name:'Pantalla', fills:[fill('#FFFFFF')] }, [ glifo ]);
  var r = M.auditNonTextContrast(glifo);
  eq(r.issues.length, 1, 'sin contenedor, el glifo es lo que se mide: ');
});

test('el borde de un input sigue auditándose', function(){
  var input = node({ name:'Input / email', width:300, height:44,
                     fills:[fill('#FFFFFF')],
                     strokes:[{ type:'SOLID', visible:true,
                                color:{ r:0.93, g:0.93, b:0.94 } }] });
  node({ name:'Pantalla', fills:[fill('#FFFFFF')] }, [ input ]);
  var r = M.auditNonTextContrast(input);
  assert(r.issues.some(function(i){ return i.detail.kind === 'border'; }),
    'el borde flojo tiene que reportarse');
});

test('el hallazgo queda marcado como no textual', function(){
  var c = iconContainer('#D6E7F3', '#B9D4E8');
  var r = M.auditNonTextContrast(c);
  eq(r.issues[0].detail.nonText, true);
});

console.log('\n\x1b[1mDetección estructural: no depender del nombre\x1b[0m');

test('un campo se reconoce por su forma aunque se llame "Frame 214"', function(){
  // En un archivo real la mitad de las capas se llama así, y la categoría
  // entera dejaba de dispararse.
  var campo = node({ name:'Frame 214', width:320, height:44, fills:[fill('#FFFFFF')],
    strokes:[{ type:'SOLID', visible:true, color:fill('#E8E8EC').color }] },
    [ txt('nombre@dominio.com', '#B0B0B0', 14, { name:'Frame 215', x:12 }) ]);
  node({ name:'Frame 1', fills:[fill('#FFFFFF')] }, [ campo ]);
  assert(M.esCampoDeFormulario(campo), 'debería reconocerse por su silueta');
});

test('un botón NO se confunde con un campo', function(){
  // Mismo alto, pero etiqueta centrada y sin borde: es un botón
  var t = txt('Enviar', '#FFFFFF', 15, { x:60 });
  t.textAlignHorizontal = 'CENTER';
  var boton = node({ name:'Frame 220', width:180, height:44, fills:[fill('#1B4F9C')],
    reactions:[{ trigger:{type:'ON_CLICK'} }] }, [ t ]);
  node({ name:'Frame 1', fills:[fill('#FFFFFF')] }, [ boton ]);
  assert(!M.pareceCampoPorForma(boton), 'un botón no es un campo');
});

test('una card grande tampoco es un campo', function(){
  var card = node({ name:'Frame 300', width:320, height:280, fills:[fill('#FFFFFF')],
    strokes:[{ type:'SOLID', visible:true, color:fill('#E8E8EC').color }] },
    [ txt('Título', '#111', 18, { x:12 }) ]);
  node({ name:'Frame 1', fills:[fill('#FFFFFF')] }, [ card ]);
  assert(!M.pareceCampoPorForma(card), 'la proporción no es de campo');
});

test('los encabezados se deducen de la escala tipográfica', function(){
  // Sin capas llamadas H1/H2, la jerarquía se infiere del tamaño
  var p = node({ name:'Frame 1', width:800, height:900, fills:[fill('#FFFFFF')] }, [
    txt('Título principal de la página', '#111', 32, { y:0,   name:'Frame 10' }),
    txt('Una sección del contenido',     '#111', 22, { y:80,  name:'Frame 11' }),
    txt('Este es un párrafo largo del cuerpo de la página que ocupa varias líneas y define el tamaño base',
        '#333', 16, { y:140, name:'Frame 12' }),
    txt('Otro párrafo del cuerpo, también largo, para que el tamaño base quede claro y sin dudas',
        '#333', 16, { y:200, name:'Frame 13' })
  ]);
  var inf = M.inferirJerarquiaTexto(p);
  eq(inf.cuerpo, 16, 'el cuerpo es el tamaño más frecuente entre textos largos: ');
  eq(inf.niveles.length, 2, 'dos encabezados deducidos: ');
  eq(inf.niveles[0].nivel, 1);
  eq(inf.niveles[1].nivel, 2);
});

test('avisa que los encabezados no están declarados', function(){
  var p = node({ name:'Frame 1', width:800, height:900, fills:[fill('#FFFFFF')] }, [
    txt('Título principal', '#111', 32, { y:0, name:'Frame 10' }),
    txt('Una sección', '#111', 22, { y:80, name:'Frame 11' }),
    txt('Un párrafo largo del cuerpo que define el tamaño base de la tipografía en esta pantalla',
        '#333', 16, { y:140, name:'Frame 12' })
  ]);
  var r = M.auditHeadingStructure(p);
  var i = r.issues.filter(function(x){ return x.detail.porEscala; })[0];
  assert(i, 'debería avisar que no están declarados');
  eq(i.wcag, '1.3.1');
});

test('si el archivo SÍ nombra los niveles, se respeta lo que dice', function(){
  var p = node({ name:'Pantalla', width:800, height:900, fills:[fill('#FFFFFF')] }, [
    txt('Título', '#111', 32, { y:0,  name:'H1 / Título' }),
    txt('Sub',    '#111', 22, { y:80, name:'H4 / Sub' })
  ]);
  var r = M.auditHeadingStructure(p);
  assert(r.issues.some(function(x){ return x.detail.fuente === 'nombre'; }),
    'con nombres explícitos no hace falta deducir');
  assert(r.issues.some(function(x){ return x.message.indexOf('salta') > -1; }),
    'y el salto H1 → H4 se sigue detectando');
});

test('una barra fija se detecta por geometría, no por nombre', function(){
  var barra = node({ name:'Frame 199', x:0, y:0, width:390, height:56,
                     fills:[fill('#FFFFFF')] });
  var raiz = { x:0, y:0, width:390, height:700 };
  eq(M.esBarraFlotantePorForma(barra, raiz), 'arriba');
});

test('un bloque de contenido en el medio no es una barra', function(){
  var bloque = node({ name:'Frame 250', x:0, y:200, width:390, height:300 });
  var raiz = { x:0, y:0, width:390, height:700 };
  eq(M.esBarraFlotantePorForma(bloque, raiz), null);
});

test('un botón flotante en la esquina inferior sí cuenta', function(){
  var fab = node({ name:'Frame 260', x:320, y:620, width:56, height:56 });
  var raiz = { x:0, y:0, width:390, height:700 };
  eq(M.esBarraFlotantePorForma(fab, raiz), 'esquina');
});

console.log('\n\x1b[1mInstancias: se audita lo visible, no el componente maestro\x1b[0m');

function conOverride(){
  var maestro = node({ type:'COMPONENT', name:'Card', width:300, height:120,
                       fills:[fill('#FFFFFF')] }, [
    txt('Texto original', '#111111', 14),
    txt('Capa visible en el maestro', '#111111', 12)
  ]);
  // La instancia sobrescribe color y visibilidad
  var inst = node({ type:'INSTANCE', name:'Card', width:300, height:120,
                    fills:[fill('#FFFFFF')], mainComponent:maestro }, [
    txt('Texto editado', '#CCCCCC', 14),
    txt('Capa visible en el maestro', '#111111', 12, { visible:false })
  ]);
  node({ name:'Pantalla', width:400, height:300, fills:[fill('#FFFFFF')] }, [ inst ]);
  return inst;
}

test('se mide el color sobrescrito, no el del maestro', function(){
  var inst = conOverride();
  var r = M.auditContrast(inst);
  var i = r.issues[0];
  assert(i, 'debería encontrar el texto flojo de la instancia');
  eq(i.detail.fg, '#CCCCCC', 'el override es lo que se ve: ');
  assert(i.nodeName.indexOf('editado') > -1, 'nodo: ' + i.nodeName);
});

test('una capa oculta EN LA INSTANCIA no se audita', function(){
  var inst = conOverride();
  var nombres = M.getAllNodes(inst).map(function(n){ return n.name; });
  assert(nombres.indexOf('Capa visible en el maestro') === -1,
    'la capa oculta en la instancia no debería recorrerse: ' + nombres.join(' | '));
});

test('el recorrido no entra al componente maestro', function(){
  var inst = conOverride();
  var textos = [];
  M.getAllNodes(inst).forEach(function(n){
    if (n.type === 'TEXT') { try { textos.push(n.characters); } catch(e){} }
  });
  assert(textos.indexOf('Texto original') === -1,
    'no puede aparecer el contenido del maestro: ' + textos.join(' | '));
});

console.log('\n' + (failed===0
  ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
  : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));

fs.unlinkSync(__dirname + '/_t3.js');
process.exit(failed===0?0:1);
