// Stub mínimo de Figma para poder cargar code.js fuera del sandbox del plugin
// y exponer las funciones internas que la suite de contexto necesita probar.
var fs = require('fs');
var path = __dirname;

global.figma = {
  showUI(){}, on(){}, ui:{ postMessage(){} },
  currentPage:{ selection:[], children:[], appendChild:function(c){ this.children.push(c); } },
  root:{ children:[] },
  viewport:{ scrollAndZoomIntoView(){} },
  getNodeById:()=>null, getStyleById:()=>null, getLocalPaintStyles:()=>[],
  loadFontAsync:()=>Promise.resolve(),
  createFrame:()=>({ children:[], fills:[], resize(){}, appendChild(){},
                     setPluginData(){}, getPluginData:()=>'' }),
  createText:()=>({ fills:[] }),
  createLine:()=>({ strokes:[], resize(){} }),
  createRectangle:()=>({ fills:[], strokes:[], resize(){} }),
  clientStorage:{ getAsync:()=>Promise.resolve(null), setAsync:()=>Promise.resolve() }
};
global.__html__ = '';

var tmp = path + '/_ctx_tmp.js';
fs.writeFileSync(tmp, fs.readFileSync(path + '/code.js', 'utf8') +
  ';module.exports={detectarContexto,exencionDe,requiereRevisionManual,' +
  'auditDesignSystem,auditHeadingOrder,auditLinkText,auditConsistencia,' +
  'auditEscalaTipografica,auditContrast,suggestAria,descartarAria,textMetrics,analyzeContrast,isFocusable,detectInteractive,ARIA_PATTERNS,ARIA_RULES,reconocerPatron,ariaSpec,auditTextSpacing,auditReflow,auditLegibilidad,auditPlaceholder,auditFormularios,auditTargetSpacing,auditFocusAppearance,impactoDe,anotarImpacto,IMPACTO,calcularCobertura,checklistManual,auditTargetSize,Doc,runAudit,colorDeCapa,coloresDelFrame,setDesignSystemPalette,suggestAccessibleColor,familiaDeToken,etiquetasSobreImagenes,inventarioImagenes,ariaVale,inventarioElementos,agruparHallazgos,getAllNodes,collectFocusStops,isFocusable,auditFocusObscured,auditDragging,auditAuth,auditAyudaCoherente,auditFocusAppearance,wcagCatalogue,wcagInfo,agruparRepetidos,pareceItemDeNavegacion,pareceActivo,esCard,nombreDeCard,esBotonDeDosEstados,etiquetaEsVaga};');
var M = require(tmp);
try { fs.unlinkSync(tmp); } catch(e) {}
module.exports = M;
