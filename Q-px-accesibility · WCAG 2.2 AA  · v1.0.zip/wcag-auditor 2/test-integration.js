#!/usr/bin/env node
// Test de integración: simula el sandbox de Figma y verifica que cada mensaje
// que manda ui.html tenga respuesta en code.js, y que la matriz salga bien.
// Ejecutar: node test-integration.js

var fs = require('fs');
var out = [];   // mensajes que code.js le manda a la UI
var selection = [];
var created = [];

function fakeNode(p, children){
  var n = Object.assign({
    type:'FRAME', name:'node', visible:true, opacity:1, x:0, y:0, width:100, height:40,
    id:'n'+Math.random().toString(36).slice(2,8), removed:false
  }, p);
  n.absoluteBoundingBox = { x:n.x, y:n.y, width:n.width, height:n.height };
  if (children){ n.children = children; children.forEach(function(c){ c.parent = n; }); }
  return n;
}
function fill(hex){
  return { type:'SOLID', visible:true, color:{
    r:parseInt(hex.slice(1,3),16)/255, g:parseInt(hex.slice(3,5),16)/255, b:parseInt(hex.slice(5,7),16)/255 } };
}
function textNode(chars, hex, size, p){
  return fakeNode(Object.assign({
    type:'TEXT', characters:chars, fontSize:size||14, name:chars,
    fills:[fill(hex||'#000000')], fontName:{family:'Inter',style:'Regular'}
  }, p||{}));
}

function mkStub(){
  created = [];
  function mkFrame(){
    var f = { type:'FRAME', name:'', children:[], fills:[], strokes:[],
      resize:function(w,h){ this.width=w; this.height=h; },
      appendChild:function(c){ this.children.push(c); c.parent=this; },
      remove:function(){}, setPluginData:function(){}, getPluginData:function(){ return ''; } };
    created.push(f); return f;
  }
  return {
    showUI: function(){},
    on: function(){},
    ui: { postMessage: function(m){ out.push(m); }, onmessage: null },
    currentPage: { selection: selection, children: [],
      appendChild:function(c){ this.children.push(c); } },
    root: { children: [] },
    viewport: { scrollAndZoomIntoView: function(){} },
    getStyleById: function(){ return null; },
    getNodeById: function(id){
      var found = null;
      (function walk(n){
        if (!n || found) return;
        if (n.id === id) { found = n; return; }
        (n.children||[]).forEach(walk);
      })(selection[0]);
      return found;
    },
    getLocalPaintStyles: function(){ return []; },
    loadFontAsync: function(){ return Promise.resolve(); },
    createFrame: mkFrame,
    createRectangle: function(){ var r={ type:'RECTANGLE', fills:[], strokes:[],
      resize:function(w,h){this.width=w;this.height=h;} }; created.push(r); return r; },
    createText: function(){ var t={ type:'TEXT', characters:'', fills:[],
      fontName:{family:'Inter',style:'Regular'} }; created.push(t); return t; },
    createLine: function(){ var l={ type:'LINE', strokes:[],
      resize:function(w,h){this.width=w;this.height=h;} }; created.push(l); return l; },
    clientStorage: { getAsync:function(){ return Promise.resolve(null); },
                     setAsync:function(){ return Promise.resolve(); } },
    closePlugin: function(){}
  };
}

global.figma = mkStub();
global.__html__ = '';
require(process.cwd() + '/code.js');
var handler = global.figma.ui.onmessage;

var passed=0, failed=0;
function test(l,f){ try{ out=[]; f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'assertion failed'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }
function got(t){ return out.filter(function(m){ return m.type===t; })[0]; }
function send(m){ handler(m); }
function setSel(nodes){ selection.length=0; nodes.forEach(function(n){ selection.push(n); }); }

// ── Escena: una card con contraste que falla y un botón de ícono sin nombre
function scene(){
  return fakeNode({ name:'Card / Checkout', width:340, height:220, fills:[fill('#FFFFFF')] }, [
    textNode('Título', '#11161C', 20, { y:10 }),
    textNode('Descripción muy clara', '#7BA7E0', 14, { y:50 }),
    fakeNode({ name:'button / icon / close', x:300, y:8, width:16, height:16, fills:[fill('#DCE9F9')] }),
    fakeNode({ name:'button / Pagar', x:10, y:150, width:300, height:48, fills:[fill('#1B4F9C')] },
      [ textNode('Pagar', '#FFFFFF', 16) ]),
    fakeNode({ name:'Tooltip / hover', visible:false, y:90 },
      [ textNode('oculto', '#CCCCCC', 10), fakeNode({ name:'button / reintentar', width:12, height:12 }) ])
  ]);
}

console.log('\n\x1b[1mProtocolo de mensajes\x1b[0m');

test('init devuelve el catálogo y la selección', function(){
  setSel([]);
  send({ type:'init' });
  var cat = got('wcag-catalogue');
  assert(cat, 'falta wcag-catalogue');
  eq(cat.criteria.length, 56, '50 de WCAG 2.1 + 6 nuevos de 2.2: ');
  assert(got('selection'), 'falta selection');
});

test('selection sin nada devuelve count 0', function(){
  setSel([]); send({ type:'get-selection' });
  eq(got('selection').count, 0);
});

test('selection con un frame informa nombre y tipo', function(){
  setSel([ scene() ]); send({ type:'get-selection' });
  var s = got('selection');
  eq(s.count, 1);
  eq(s.name, 'Card / Checkout');
  eq(s.visible, true);
});

test('selection múltiple se reporta como MULTIPLE', function(){
  setSel([ scene(), scene() ]); send({ type:'get-selection' });
  eq(got('selection').nodeType, 'MULTIPLE');
  eq(got('selection').count, 2);
});

console.log('\n\x1b[1mCategorías sueltas\x1b[0m');

test('run-category contrast encuentra el par que falla', function(){
  setSel([ scene() ]);
  send({ type:'run-category', category:'contrast' });
  var r = got('category-results');
  assert(r, 'sin respuesta');
  eq(r.category, 'contrast');
  assert(r.issues.length >= 1, 'debería encontrar al menos un fallo');
  assert(r.issues.some(function(i){ return i.wcag === '1.4.3'; }), 'debería citar 1.4.3');
});

test('run-category target marca el botón de 16px', function(){
  setSel([ scene() ]);
  send({ type:'run-category', category:'target' });
  var r = got('category-results');
  assert(r.issues.some(function(i){
    return i.nodeName.indexOf('close') > -1 && i.severity === 'fail'; }), 'debería marcar el close de 16px');
});

test('run-category aria marca el botón sin nombre', function(){
  setSel([ scene() ]);
  send({ type:'run-category', category:'aria' });
  var r = got('category-results');
  assert(r.issues.some(function(i){ return i.wcag === '4.1.2'; }), 'debería citar 4.1.2');
});

test('run-category cuenta las capas ocultas omitidas', function(){
  setSel([ scene() ]);
  send({ type:'run-category', category:'contrast' });
  assert(got('category-results').hiddenSkipped >= 2, 'debería omitir el tooltip oculto y sus hijos');
});

test('run-category sin selección devuelve error', function(){
  setSel([]);
  send({ type:'run-category', category:'contrast' });
  assert(got('error'), 'debería avisar que falta seleccionar');
});

test('categoría desconocida devuelve error', function(){
  setSel([ scene() ]);
  send({ type:'run-category', category:'inventada' });
  assert(got('error'));
});

console.log('\n\x1b[1mOrden de foco\x1b[0m');

test('build-focus-order devuelve paradas numeradas', function(){
  setSel([ scene() ]);
  send({ type:'build-focus-order' });
  var f = got('focus-order');
  assert(f, 'sin respuesta');
  eq(f.stops.length, 2, 'close + Pagar, sin el botón oculto: ');
  eq(f.stops[0].index, 1);
});

test('el botón dentro del frame oculto no recibe foco', function(){
  setSel([ scene() ]);
  send({ type:'build-focus-order' });
  var names = got('focus-order').stops.map(function(s){ return s.name; });
  assert(names.indexOf('button / reintentar') === -1, 'no debería estar el oculto');
});

test('cada parada trae su sugerencia ARIA', function(){
  setSel([ scene() ]);
  send({ type:'build-focus-order' });
  var s = got('focus-order').stops[0];
  assert(s.aria, 'falta aria en la parada');
  assert(typeof s.aria.needsLabel === 'boolean');
});

test('build-focus-order sin selección devuelve error', function(){
  setSel([]); send({ type:'build-focus-order' });
  assert(got('error'));
});

console.log('\n\x1b[1mARIA\x1b[0m');

test('build-aria lista solo los controles que necesitan anotación', function(){
  // Un botón con texto visible y sin estado no se lista: con <button> nativo
  // alcanza y no hay nada que anotar. Se cuenta aparte, en "resueltos".
  setSel([ scene() ]);
  send({ type:'build-aria' });
  var a = got('aria-suggestions');
  assert(a, 'sin respuesta');
  eq(a.items.length, 1, 'solo el botón de ícono necesita algo: ');
  eq(a.totalControles, 2, 'pero se detectaron los dos: ');
  eq(a.resueltos.length, 1, 'el otro queda como resuelto: ');
});

test('el botón de ícono sale sin nombre accesible', function(){
  setSel([ scene() ]);
  send({ type:'build-aria' });
  var close = got('aria-suggestions').items.filter(function(i){ return i.name.indexOf('close')>-1; })[0];
  assert(close, 'falta el botón close');
  eq(close.aria.needsLabel, true);
});

test('el botón con texto queda como resuelto, con su nombre', function(){
  setSel([ scene() ]);
  send({ type:'build-aria' });
  var a = got('aria-suggestions');
  var pagar = a.resueltos.filter(function(i){ return i.name.indexOf('Pagar')>-1; })[0];
  assert(pagar, 'debería estar entre los resueltos');
  eq(pagar.nombre, 'Pagar', 'el texto visible ya es su nombre accesible: ');
  eq(pagar.nativo, '<button>');
});

test('avisa cuando varios controles quedarían con el mismo nombre', function(){
  // De la revisión: un lápiz en cada sección propone "Editar" para todos, y el
  // lector anuncia cinco botones idénticos.
  var pantalla = fakeNode({ name:'Ajustes', width:400, height:600, fills:[fill('#FFFFFF')] }, [
    fakeNode({ name:'Button / icon / edit', x:340, y:20,  width:32, height:32,
               reactions:[{ trigger:{type:'ON_CLICK'} }] },
      [ fakeNode({ name:'Icon / edit', type:'VECTOR', width:16, height:16 }) ]),
    fakeNode({ name:'Button / icon / edit', x:340, y:100, width:32, height:32,
               reactions:[{ trigger:{type:'ON_CLICK'} }] },
      [ fakeNode({ name:'Icon / edit', type:'VECTOR', width:16, height:16 }) ]),
    fakeNode({ name:'Button / icon / edit', x:340, y:180, width:32, height:32,
               reactions:[{ trigger:{type:'ON_CLICK'} }] },
      [ fakeNode({ name:'Icon / edit', type:'VECTOR', width:16, height:16 }) ])
  ]);
  setSel([ pantalla ]);
  send({ type:'build-aria' });
  var a = got('aria-suggestions');
  assert(a && a.items.length >= 2, 'items: ' + (a ? a.items.length : 0));
  var conAviso = a.items.filter(function(i){ return i.aria.repetida; });
  assert(conAviso.length >= 2, 'debería marcar los repetidos: ' + conAviso.length);
  assert(conAviso[0].aria.notes.some(function(n){
    return n.text.indexOf('mismo nombre') > -1; }), 'falta la explicación');
});

console.log('\n\x1b[1mMatriz de color\x1b[0m');

function palette(){
  return fakeNode({ name:'Paleta' }, [
    fakeNode({ name:'white',     fills:[fill('#FFFFFF')] }),
    fakeNode({ name:'black',     fills:[fill('#000000')] }),
    fakeNode({ name:'bright',    fills:[fill('#00CFFF')] }),
    fakeNode({ name:'dark',      fills:[fill('#1C304A')] })
  ]);
}

test('extract-colors saca los colores de la selección', function(){
  setSel([ palette() ]);
  send({ type:'extract-colors' });
  var c = got('colors-extracted');
  assert(c, 'sin respuesta');
  assert(c.palette.length >= 4, 'debería sacar 4 colores, sacó '+c.palette.length);
});

test('no duplica colores repetidos', function(){
  setSel([ fakeNode({ name:'p' }, [
    fakeNode({ name:'a', fills:[fill('#FFFFFF')] }),
    fakeNode({ name:'b', fills:[fill('#FFFFFF')] })
  ]) ]);
  send({ type:'extract-colors' });
  eq(got('colors-extracted').palette.length, 1);
});

test('ignora los colores de capas ocultas', function(){
  setSel([ fakeNode({ name:'p' }, [
    fakeNode({ name:'visible', fills:[fill('#FFFFFF')] }),
    fakeNode({ name:'oculto', visible:false, fills:[fill('#FF0000')] })
  ]) ]);
  send({ type:'extract-colors' });
  var hexes = got('colors-extracted').palette.map(function(c){ return c.hex; });
  assert(hexes.indexOf('#FF0000') === -1, 'no debería incluir el color oculto');
});

test('build-palette-matrix arma la tabla completa', function(){
  setSel([ palette() ]);
  send({ type:'extract-colors' });
  out = [];
  send({ type:'build-palette-matrix' });
  var m = got('palette-matrix');
  assert(m, 'sin respuesta');
  eq(m.matrix.length, 4, 'una fila por color de fondo: ');
  eq(m.matrix[0].cells.length, 4, 'una columna por color de texto: ');
});

test('los ratios de la matriz son correctos', function(){
  setSel([ palette() ]);
  send({ type:'extract-colors' });
  out = [];
  send({ type:'build-palette-matrix' });
  var m = got('palette-matrix');
  // blanco sobre negro = 21:1, el máximo posible
  var white = m.matrix.filter(function(r){ return r.bg.hex === '#000000'; })[0];
  var cell = white.cells.filter(function(c){ return c.fg.hex === '#FFFFFF'; })[0];
  eq(cell.ratio, 21);
  eq(cell.normalAA, true);
  eq(cell.normalAAA, true);
});

test('marca correctamente lo que no pasa', function(){
  setSel([ palette() ]);
  send({ type:'extract-colors' });
  out = [];
  send({ type:'build-palette-matrix' });
  var m = got('palette-matrix');
  // #00CFFF sobre blanco no llega a 4.5:1
  var onWhite = m.matrix.filter(function(r){ return r.bg.hex === '#FFFFFF'; })[0];
  var bright = onWhite.cells.filter(function(c){ return c.fg.hex === '#00CFFF'; })[0];
  eq(bright.normalAA, false, 'bright sobre blanco no debería pasar: ');
});

test('la matriz sin paleta devuelve error', function(){
  send({ type:'set-ds-palette', palette:[] });
  out = [];
  send({ type:'build-palette-matrix' });
  assert(got('error'));
});

console.log('\n\x1b[1mBloqueo de anotaciones\x1b[0m');

test('set-artifacts-locked responde sin explotar', function(){
  send({ type:'set-artifacts-locked', locked:false });
  var r = got('artifacts-locked');
  assert(r, 'sin respuesta');
  eq(r.locked, false);
});

test('vuelve a bloquear', function(){
  send({ type:'set-artifacts-locked', locked:true });
  eq(got('artifacts-locked').locked, true);
});

console.log('\n\x1b[1mAuditoría completa\x1b[0m');

test('run-audit devuelve score y resultados por categoría', function(done){
  setSel([ scene() ]);
  send({ type:'run-audit' });
  // El pipeline es async; alcanza con verificar que no explotó
  assert(true);
});

console.log('\n' + (failed===0
  ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
  : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));

process.exit(failed===0?0:1);
