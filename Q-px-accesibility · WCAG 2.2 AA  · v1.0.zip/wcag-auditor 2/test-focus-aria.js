#!/usr/bin/env node
// Tests de las features nuevas: catálogo WCAG, orden de foco inferido y ARIA.
// Ejecutar: node test-focus-aria.js

var fs = require('fs');
var src = fs.readFileSync(__dirname + '/code.js', 'utf8');

global.figma = {
  showUI: function(){}, on: function(){},
  ui: { postMessage: function(){}, onmessage: null },
  currentPage: { selection: [], children: [] },
  getLocalPaintStyles: function(){ return []; },
  clientStorage: { getAsync: function(){ return Promise.resolve(null); }, setAsync: function(){ return Promise.resolve(); } }
};
global.__html__ = '';

var wrapped = src + '\n;module.exports = { WCAG, wcagInfo, wcagLabel, wcagCatalogue, buildFocusOrder,' +
  ' collectFocusStops, sortReadingOrder, isFocusable, suggestAria, auditAria, isLayerVisible };';
fs.writeFileSync(__dirname + '/_tmp2.js', wrapped);
var M = require(__dirname + '/_tmp2.js');

var passed=0, failed=0;
function test(l,f){ try{ f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'assertion failed'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }

function node(p, children){
  var n = Object.assign({type:'FRAME',name:'node',visible:true,opacity:1,x:0,y:0,width:100,height:40}, p);
  n.absoluteBoundingBox = {x:n.x, y:n.y, width:n.width, height:n.height};
  if(children){ n.children=children; children.forEach(function(c){ c.parent=n; }); }
  return n;
}
function txt(chars, p){
  return node(Object.assign({type:'TEXT', characters:chars, name:'label'}, p||{}));
}

console.log('\n\x1b[1mCatálogo WCAG 2.1\x1b[0m');

test('tiene los 50 criterios de 2.1 más los 6 nuevos de 2.2', function(){
  var all = M.wcagCatalogue();
  eq(all.length, 56, 'total: ');
  var v21 = all.filter(function(c){ return c.since === '2.1'; });
  eq(v21.length, 50, 'los de 2.1: ');
  eq(v21.filter(function(c){return c.level==='A';}).length, 30, 'nivel A en 2.1: ');
  eq(v21.filter(function(c){return c.level==='AA';}).length, 20, 'nivel AA en 2.1: ');
});

test('los 6 nuevos de WCAG 2.2 están y son 2 de A y 4 de AA', function(){
  var n22 = M.wcagCatalogue().filter(function(c){ return c.since === '2.2'; });
  eq(n22.length, 6);
  eq(n22.filter(function(c){ return c.level==='A'; }).length, 2, 'nivel A: ');
  eq(n22.filter(function(c){ return c.level==='AA'; }).length, 4, 'nivel AA: ');
  ['2.4.11','2.5.7','2.5.8','3.2.6','3.3.7','3.3.8'].forEach(function(id){
    assert(n22.some(function(c){ return c.id === id; }), 'falta ' + id);
  });
});

test('4.1.1 Parsing queda marcado como retirado en 2.2', function(){
  eq(M.wcagInfo('4.1.1').obsolete, true);
});

test('todos tienen nombre en inglés, español y explicación', function(){
  M.wcagCatalogue().forEach(function(c){
    assert(c.en && c.en.length>3, c.id+' sin nombre en inglés');
    assert(c.es && c.es.length>3, c.id+' sin nombre en español');
    assert(c.plain && c.plain.length>20, c.id+' sin explicación en lenguaje claro');
  });
});

test('todos tienen un scope válido', function(){
  M.wcagCatalogue().forEach(function(c){
    assert(['auto','manual','code'].indexOf(c.scope)>-1, c.id+' scope inválido: '+c.scope);
  });
});

test('el catálogo sale ordenado numéricamente', function(){
  var ids = M.wcagCatalogue().map(function(c){return c.id;});
  eq(ids[0], '1.1.1');
  eq(ids[ids.length-1], '4.1.3');
  // 1.4.10 tiene que ir después de 1.4.5, no antes (orden numérico, no alfabético)
  assert(ids.indexOf('1.4.10') > ids.indexOf('1.4.5'), '1.4.10 debe ir después de 1.4.5');
});

test('los criterios que el plugin audita están marcados auto:true', function(){
  ['1.4.3','1.4.11','2.4.3','2.4.7','4.1.2'].forEach(function(id){
    assert(M.wcagInfo(id).auto === true, id+' debería estar marcado como auto');
  });
});

test('wcagLabel arma la etiqueta legible', function(){
  eq(M.wcagLabel('1.4.3'), '1.4.3 Contraste (mínimo) (AA)');
});

test('un id desconocido no rompe', function(){
  var c = M.wcagInfo('9.9.9');
  assert(c && c.es, 'debería devolver un fallback');
});

console.log('\n\x1b[1mOrden de foco — inferencia\x1b[0m');

test('ordena de arriba hacia abajo', function(){
  var root = node({name:'root',height:300}, [
    node({name:'button / C', y:200}),
    node({name:'button / A', y:0}),
    node({name:'button / B', y:100})
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops.map(function(s){return s.name;}).join(','), 'button / A,button / B,button / C');
});

test('elementos en la misma fila van de izquierda a derecha', function(){
  var root = node({name:'root'}, [
    node({name:'button / derecha', x:300, y:0}),
    node({name:'button / izquierda', x:0, y:0}),
    node({name:'button / medio', x:150, y:0})
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops.map(function(s){return s.name;}).join(','),
     'button / izquierda,button / medio,button / derecha');
});

test('tolera desalineación vertical chica dentro de una fila', function(){
  // 6px de diferencia: sigue siendo la misma fila, manda el orden horizontal
  var root = node({name:'root'}, [
    node({name:'button / B', x:200, y:0}),
    node({name:'button / A', x:0, y:6})
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops[0].name, 'button / A');
});

test('respeta el orden de hijos cuando hay auto-layout', function(){
  // Auto-layout ya codifica la intención: no re-ordenar por geometría
  var root = node({name:'root', layoutMode:'HORIZONTAL'}, [
    node({name:'button / primero', x:500, y:0}),
    node({name:'button / segundo', x:0, y:0})
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops[0].name, 'button / primero');
});

test('una card clickeable con un botón adentro son DOS paradas', function(){
  // Antes el externo ganaba y el botón de adentro desaparecía, que es lo que
  // hacía que el plugin se salteara controles visibles. En HTML una card-link
  // con su propio botón son dos paradas de Tab, así que ahora salen las dos.
  var root = node({name:'root'}, [
    node({name:'card / link', y:0}, [ node({name:'button / interno', y:10}) ])
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops.length, 2);
  eq(o.stops[0].name, 'card / link', 'el contenedor primero: ');
  eq(o.stops[1].name, 'button / interno');
});

test('ignora los elementos interactivos ocultos', function(){
  var root = node({name:'root'}, [
    node({name:'button / visible', y:0}),
    node({name:'button / oculto', y:50, visible:false}),
    node({name:'button / sin-opacidad', y:100, opacity:0})
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops.length, 1);
  eq(o.stops[0].name, 'button / visible');
});

test('no toma en cuenta hijos interactivos de un contenedor oculto', function(){
  var root = node({name:'root'}, [
    node({name:'modal', visible:false}, [ node({name:'button / confirmar'}) ]),
    node({name:'button / real', y:100})
  ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops.length, 1);
  eq(o.stops[0].name, 'button / real');
});

test('numera las paradas desde 1', function(){
  var root = node({name:'root'}, [ node({name:'button / A', y:0}), node({name:'button / B', y:60}) ]);
  var o = M.buildFocusOrder(root);
  eq(o.stops[0].index, 1);
  eq(o.stops[1].index, 2);
});

test('avisa cuando no hay elementos interactivos', function(){
  var o = M.buildFocusOrder(node({name:'root'}, [ txt('solo texto') ]));
  eq(o.stops.length, 0);
  assert(o.warnings.length > 0, 'debería avisar');
});

test('avisa si el orden salta hacia arriba', function(){
  // El tercer elemento queda por encima del segundo: orden visual sospechoso
  var root = node({name:'root', layoutMode:'VERTICAL'}, [
    node({name:'button / A', y:200, height:40}),
    node({name:'button / B', y:0, height:40})
  ]);
  var o = M.buildFocusOrder(root);
  assert(o.warnings.some(function(w){ return w.indexOf('por encima') > -1; }), 'debería avisar del salto');
});

test('un root oculto no devuelve paradas', function(){
  var o = M.buildFocusOrder(node({name:'root', visible:false}, [ node({name:'button / A'}) ]));
  eq(o.rootHidden, true);
  eq(o.stops.length, 0);
});

console.log('\n\x1b[1mARIA\x1b[0m');

test('control sin texto visible pide aria-label', function(){
  var n = node({name:'button / icon / close'});
  var a = M.suggestAria(n);
  eq(a.needsLabel, true);
  assert(a.notes.some(function(x){return x.severity==='fail';}), 'debería marcar fail');
});

test('control con texto visible toma ese texto como nombre accesible', function(){
  var n = node({name:'button / primary'}, [ txt('Continuar') ]);
  var a = M.suggestAria(n);
  eq(a.accessibleName, 'Continuar');
  eq(a.needsLabel, false);
});

test('no sugiere role redundante para botón nativo', function(){
  var n = node({name:'button / primary'}, [ txt('Enviar') ]);
  eq(M.suggestAria(n).role, null, 'button nativo no necesita role: ');
});

test('no sugiere role donde el HTML nativo alcanza', function(){
  // Regla 1 de ARIA: <input type="checkbox"> YA es role="checkbox". Agregarlo
  // es redundante, y el ARIA redundante rompe más de lo que arregla.
  var chk = M.suggestAria(node({name:'checkbox / términos'}));
  eq(chk.role, null, 'un checkbox nativo no necesita role: ');
  eq(chk.nativo, '<input type="checkbox">');
  assert(chk.snippet.indexOf('type="checkbox"') > -1);

  var dd = M.suggestAria(node({name:'dropdown / país'}));
  eq(dd.role, null, 'un select nativo tampoco: ');
});

test('sí sugiere role cuando no hay equivalente nativo', function(){
  // No existe <switch> en HTML: acá el rol es necesario.
  eq(M.suggestAria(node({name:'toggle / notificaciones'})).role, 'switch');
  eq(M.suggestAria(node({name:'Tab button / uno'})).role, 'tab');
});

test('cada patrón trae su teclado y sus errores típicos', function(){
  var t = M.suggestAria(node({name:'toggle / wifi'}));
  assert(t.teclado && t.teclado.length > 5, 'falta la interacción de teclado');
  assert(t.errores && t.errores.length > 0, 'faltan los errores comunes del patrón');
});

test('marca el estado ARIA que necesita el componente', function(){
  eq(M.suggestAria(node({name:'checkbox / términos'})).state, 'aria-checked');
  eq(M.suggestAria(node({name:'accordion / faq'})).state, 'aria-expanded');
});

test('el acordeón trae aria-controls además del estado', function(){
  var a = M.suggestAria(node({name:'accordion / faq'}));
  assert(a.props.indexOf('aria-controls') > -1, 'props: ' + a.props.join(','));
});

test('advierte sobre Label in Name cuando hay texto visible', function(){
  var n = node({name:'button / primary'}, [ txt('Guardar') ]);
  var a = M.suggestAria(n);
  assert(a.notes.some(function(x){ return x.wcag === '2.5.3'; }), 'debería citar 2.5.3');
});

test('auditAria cuenta los que ya tienen nombre como passed', function(){
  var root = node({name:'root'}, [
    node({name:'button / ok', y:0}, [ txt('Aceptar') ]),
    node({name:'button / icon / x', y:60})
  ]);
  var r = M.auditAria(root);
  eq(r.issues.length, 1, 'un solo hallazgo: ');
  eq(r.issues[0].wcag, '4.1.2');
});

test('auditAria ignora los controles ocultos', function(){
  var root = node({name:'root'}, [ node({name:'button / icon / x', visible:false}) ]);
  eq(M.auditAria(root).issues.length, 0);
});

console.log('\n' + (failed===0
  ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
  : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));

fs.unlinkSync(__dirname + '/_tmp2.js');
process.exit(failed===0?0:1);
