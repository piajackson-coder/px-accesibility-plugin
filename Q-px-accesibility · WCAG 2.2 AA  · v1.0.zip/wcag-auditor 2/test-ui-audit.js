#!/usr/bin/env node
// Auditoría del propio plugin: clases CSS que el JS usa pero nadie definió,
// emojis sueltos, y contraste de la propia paleta de la UI.
// Este archivo existe porque al rehacer el CSS se perdieron ocho clases en
// silencio y nadie se dio cuenta hasta verlo en pantalla.

var fs = require('fs');
var src = fs.readFileSync(__dirname + '/ui.html', 'utf8');
var css = src.split('</style>')[0];
var js  = src.split('<script>')[1].split('</script>')[0];

var passed = 0, failed = 0;
function test(l, f){ try{ f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'falló'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }

console.log('\n\x1b[1mCSS\x1b[0m');

// Clases realmente definidas en la hoja
var defined = {};
(css.match(/\.[A-Za-z][A-Za-z0-9_-]*/g) || []).forEach(function(m){ defined[m.slice(1)] = true; });

// Clases que el JS escribe en atributos class="..."
function usedClasses(){
  var out = {};
  var re = /class="([^"]*)"/g, m;
  while ((m = re.exec(js))) {
    // Ignorar los tramos interpolados: '"+expr+"'
    m[1].split(/\s+/).forEach(function(c){
      c = c.trim();
      if (!c) return;
      if (c.indexOf("'") > -1 || c.indexOf('+') > -1 || c.indexOf('(') > -1) return;
      out[c] = true;
    });
  }
  return Object.keys(out);
}

// Las del reporte HTML descargable llevan su propio <style> embebido
var REPORTE = ['issue','ih','fix','sw','tag','bad','warn','ok','meta','score','totals','sub',
                'pv','pv-c','pv-l','pv-b','pv-ar','pv-shape','pv-box','hint','mk','p1','p2',
                'cov','covg','covbar','covn','chk','chki','gdesc','afec'];

test('todas las clases que usa el JS existen en el CSS', function(){
  var faltan = usedClasses().filter(function(c){
    return !defined[c] && REPORTE.indexOf(c) === -1;
  });
  assert(faltan.length === 0,
    'sin definir: ' + faltan.join(', '));
});

test('no quedan reglas CSS con color hardcodeado fuera de la paleta', function(){
  // Los hex permitidos son los de la marca más los neutros de la escala
  var permitidos = ['#000000','#2547E7','#FFB800','#EF4E44','#FF63C3','#8C31E8','#35D2C0',
                    '#FFFFFF','#0D0D0F','#151518','#9A9AA2','#6B6B75','#fff','#000',
                    '#111114','#E4E4E8','#1C39C4','#28BFAE','#26262C','#94A8FF','#FF8A82',
                    '#FFD36B','#B6B6BE','#9F9FA8','#DEDEE4','#C9A9FF','#8DE6DA','#93939C',
                    '#4A4A54','#FF9A93',
                    // Colores de los marcadores del canvas: el panel los repite
                    // para que el numero rojo de la pantalla sea el rojo del panel.
                    '#FF453A','#FF9500',
                    // Modo claro: los mismos tokens con valores legibles sobre blanco
                    '#F6F6F8','#EDEDF1','#5E5E68','#72727C','#3F3F46','#8A5A00',
                    '#B3261E','#0A7B6B','#6B23B8','#C9C9D0','#C2187E'];
  var hexes = (css.match(/#[0-9A-Fa-f]{3,8}\b/g) || []);
  var raros = hexes.filter(function(h){
    return permitidos.indexOf(h) === -1 && permitidos.indexOf(h.toUpperCase()) === -1;
  });
  assert(raros.length === 0, 'colores fuera de paleta: ' + raros.join(', '));
});

console.log('\n\x1b[1mIconografía\x1b[0m');

test('no hay emojis en la interfaz', function(){
  // Rangos de emoji y pictogramas; se permiten flechas y guiones tipográficos
  var permitidos = '\u2190\u2192\u2193\u2265\u2264\u2500\u2019\u00a0\u2022\u25CF\u2833';
  var malos = [];
  for (var i = 0; i < js.length; i++) {
    var c = js.charCodeAt(i);
    if (c >= 0x1F000 || (c >= 0x2600 && c <= 0x27BF) || (c >= 0xFE00 && c <= 0xFE0F)) {
      if (permitidos.indexOf(js[i]) === -1) malos.push(js[i]);
    }
  }
  assert(malos.length === 0, 'emojis encontrados: ' + malos.join(' '));
});

test('los iconos se declaran una sola vez y se reutilizan', function(){
  assert(js.indexOf('var I = {') > -1, 'falta el set de iconos');
  var svgSueltos = (js.match(/<svg /g) || []).length;
  var enSet = (js.match(/svg\('/g) || []).length;
  assert(enSet >= 10, 'el set tiene ' + enSet + ' iconos, esperaba al menos 10');
});

console.log('\n\x1b[1mAccesibilidad del propio plugin\x1b[0m');

function toLinear(c){ var s=c/255; return s<=0.03928 ? s/12.92 : Math.pow((s+0.055)/1.055,2.4); }
function lum(h){
  var r=parseInt(h.slice(1,3),16), g=parseInt(h.slice(3,5),16), b=parseInt(h.slice(5,7),16);
  return 0.2126*toLinear(r)+0.7152*toLinear(g)+0.0722*toLinear(b);
}
function ratio(a,b){ var l1=lum(a), l2=lum(b);
  return (Math.max(l1,l2)+0.05)/(Math.min(l1,l2)+0.05); }

test('el texto principal pasa AA sobre el fondo', function(){
  var r = ratio('#FFFFFF', '#000000');
  assert(r >= 4.5, 'ratio ' + r.toFixed(2));
});

test('el texto atenuado pasa AA sobre el fondo', function(){
  var r = ratio('#9A9AA2', '#000000');
  assert(r >= 4.5, '--muted sobre negro da ' + r.toFixed(2) + ':1, necesita 4.5');
});

test('el texto tenue pasa al menos 3:1 (solo se usa en textos chicos de apoyo)', function(){
  var r = ratio('#6B6B75', '#000000');
  assert(r >= 3, '--dim sobre negro da ' + r.toFixed(2) + ':1');
});

test('los acentos semánticos se distinguen del fondo', function(){
  [['#35D2C0','pass'], ['#EF4E44','fail'], ['#FFB800','warn']].forEach(function(p){
    var r = ratio(p[0], '#000000');
    assert(r >= 3, p[1] + ' da ' + r.toFixed(2) + ':1 sobre negro');
  });
});

test('el azul de foco contrasta con el turquesa de lectura', function(){
  // Tienen que ser distinguibles entre sí, no solo contra el fondo
  var r = ratio('#2547E7', '#35D2C0');
  assert(r >= 3, 'foco vs lectura da ' + r.toFixed(2) + ':1 — se confundirían');
});

test('hay indicador de foco visible definido', function(){
  assert(css.indexOf(':focus-visible') > -1, 'falta :focus-visible');
});

console.log('\n\x1b[1mMarca\x1b[0m');

test('usa Be Vietnam Pro', function(){
  assert(css.indexOf('Be Vietnam Pro') > -1);
});

test('hay un fallback de fuente por si no carga', function(){
  var m = css.match(/--font:[^;]+;/);
  assert(m && m[0].indexOf('sans-serif') > -1, 'la variable --font necesita fallback');
});

console.log('\n' + (failed===0
  ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
  : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));
process.exit(failed===0?0:1);
