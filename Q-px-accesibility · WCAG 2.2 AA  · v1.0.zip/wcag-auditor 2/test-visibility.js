#!/usr/bin/env node
// Tests para las funciones nuevas: poda por visibilidad, resolveBackground
// con opacidad, y sugerencia de color accesible.
// Ejecutar: node test-visibility.js

var fs = require('fs');
var src = fs.readFileSync(__dirname + '/code.js', 'utf8');

// Stub del entorno de Figma para poder evaluar code.js fuera del sandbox
global.figma = {
  showUI: function() {},
  on: function() {},
  ui: { postMessage: function() {}, onmessage: null },
  currentPage: { selection: [], children: [] },
  getLocalPaintStyles: function() { return []; },
  clientStorage: {
    getAsync: function() { return Promise.resolve(null); },
    setAsync: function() { return Promise.resolve(); }
  }
};
global.__html__ = '';

// Exponemos las funciones internas para testear
var sandbox = {};
var wrapped = src + '\n;module.exports = { isLayerVisible, getAllNodes, resolveBackground, suggestAccessibleColor, contrastRatio, relativeLuminance, setDesignSystemPalette, topSolidFill, auditTargetSize, hexFromRGB };';
fs.writeFileSync(__dirname + '/_tmp_module.js', wrapped);
var M = require(__dirname + '/_tmp_module.js');

var passed = 0, failed = 0;
function test(label, fn) {
  try { fn(); console.log('  \x1b[32m✓\x1b[0m ' + label); passed++; }
  catch (e) { console.log('  \x1b[31m✕\x1b[0m ' + label + '\n    \x1b[33m→ ' + e.message + '\x1b[0m'); failed++; }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(a, b, msg) { if (a !== b) throw new Error((msg || '') + ' esperado ' + b + ', obtenido ' + a); }

// ─── Helpers para construir nodos falsos ──────────────────────────────────────
function node(props, children) {
  var n = Object.assign({ type: 'FRAME', name: 'node', visible: true, opacity: 1, width: 100, height: 100 }, props);
  if (children) {
    n.children = children;
    children.forEach(function(c) { c.parent = n; });
  }
  return n;
}
function solidFill(hex, opacity) {
  var r = parseInt(hex.slice(1,3),16)/255, g = parseInt(hex.slice(3,5),16)/255, b = parseInt(hex.slice(5,7),16)/255;
  var f = { type: 'SOLID', color: { r:r, g:g, b:b }, visible: true };
  if (opacity !== undefined) f.opacity = opacity;
  return f;
}

console.log('\n\x1b[1mVisibilidad — poda de capas\x1b[0m');

test('capa con visible:false se considera oculta', function() {
  eq(M.isLayerVisible(node({ visible: false })), false);
});

test('capa con opacity 0 se considera oculta', function() {
  eq(M.isLayerVisible(node({ opacity: 0 })), false);
});

test('capa normal es visible', function() {
  eq(M.isLayerVisible(node({})), true);
});

test('no recorre hijos de un frame oculto', function() {
  var hidden = node({ name: 'oculto', visible: false }, [ node({ name: 'texto-adentro', type: 'TEXT' }) ]);
  var root = node({ name: 'root' }, [ hidden, node({ name: 'visible-sib', type: 'TEXT' }) ]);
  var names = M.getAllNodes(root).map(function(n) { return n.name; });
  assert(names.indexOf('oculto') === -1, 'el frame oculto no debería estar');
  assert(names.indexOf('texto-adentro') === -1, 'el hijo del frame oculto no debería estar');
  assert(names.indexOf('visible-sib') !== -1, 'el hermano visible sí debería estar');
});

test('un hijo visible dentro de un padre oculto NO se audita', function() {
  var child = node({ name: 'hijo', type: 'TEXT', visible: true });
  var root = node({ name: 'root' }, [ node({ name: 'padre', visible: false }, [ child ]) ]);
  eq(M.getAllNodes(root).length, 1, 'solo el root: ');
});

test('el root siempre se incluye aunque esté oculto (selección explícita)', function() {
  var root = node({ name: 'root', visible: false }, [ node({ name: 'hijo', type: 'TEXT' }) ]);
  var names = M.getAllNodes(root).map(function(n) { return n.name; });
  eq(names.length, 1);
  eq(names[0], 'root');
});

test('includeHidden:true desactiva la poda', function() {
  var root = node({ name: 'root' }, [ node({ name: 'oculto', visible: false }, [ node({ name: 'nieto', type: 'TEXT' }) ]) ]);
  eq(M.getAllNodes(root, { includeHidden: true }).length, 3);
});

console.log('\n\x1b[1mresolveBackground\x1b[0m');

test('toma el fill del ancestro más cercano', function() {
  var text = node({ type: 'TEXT', name: 't' });
  node({ name: 'card', fills: [ solidFill('#0033AA') ] }, [ text ]);
  eq(M.resolveBackground(text).hex, '#0033AA');
});

test('ignora el fill de un ancestro oculto y sigue subiendo', function() {
  var text = node({ type: 'TEXT', name: 't' });
  var card = node({ name: 'card-oculta', visible: false, fills: [ solidFill('#FFFFFF') ] }, [ text ]);
  node({ name: 'page-bg', fills: [ solidFill('#111111') ] }, [ card ]);
  eq(M.resolveBackground(text).hex, '#111111');
});

test('ignora fills con opacity 0', function() {
  var text = node({ type: 'TEXT', name: 't' });
  var card = node({ name: 'card', fills: [ solidFill('#FFFFFF', 0) ] }, [ text ]);
  node({ name: 'bg', fills: [ solidFill('#000000') ] }, [ card ]);
  eq(M.resolveBackground(text).hex, '#000000');
});

test('compone un fondo semitransparente sobre el que está detrás', function() {
  var text = node({ type: 'TEXT', name: 't' });
  var overlay = node({ name: 'overlay', fills: [ solidFill('#000000', 0.5) ] }, [ text ]);
  node({ name: 'bg', fills: [ solidFill('#FFFFFF') ] }, [ overlay ]);
  var bg = M.resolveBackground(text);
  eq(bg.hex, '#808080', 'negro 50% sobre blanco: ');
  eq(bg.approximate, true, 'debe marcarse como aproximado: ');
});

test('sin ningún ancestro con fill cae a blanco y lo marca como default', function() {
  var text = node({ type: 'TEXT', name: 't' });
  node({ name: 'sin-fill' }, [ text ]);
  var bg = M.resolveBackground(text);
  eq(bg.hex, '#FFFFFF');
  eq(bg.isDefault, true);
});

console.log('\n\x1b[1mSugerencia de color accesible\x1b[0m');

function rgb(hex) {
  return { r: parseInt(hex.slice(1,3),16), g: parseInt(hex.slice(3,5),16), b: parseInt(hex.slice(5,7),16) };
}
function ratioOf(fgHex, bgHex) {
  var f = rgb(fgHex), b = rgb(bgHex);
  return M.contrastRatio(M.relativeLuminance(f.r,f.g,f.b), M.relativeLuminance(b.r,b.g,b.b));
}

test('sin paleta: sugiere un hex del mismo tono que sí pasa 4.5:1', function() {
  M.setDesignSystemPalette([]);
  var s = M.suggestAccessibleColor(rgb('#7BA7E0'), rgb('#FFFFFF'), 4.5);
  assert(s, 'debería devolver una sugerencia');
  assert(ratioOf(s.hex, '#FFFFFF') >= 4.5, 'la sugerencia ' + s.hex + ' da ' + ratioOf(s.hex,'#FFFFFF').toFixed(2));
});

test('con paleta: prefiere el token más cercano que pasa', function() {
  M.setDesignSystemPalette([
    { name: 'blue/300', hex: '#7BA7E0', r: 123, g: 167, b: 224 },
    { name: 'blue/700', hex: '#1B4F9C', r: 27,  g: 79,  b: 156 },
    { name: 'gray/900', hex: '#111111', r: 17,  g: 17,  b: 17  }
  ]);
  var s = M.suggestAccessibleColor(rgb('#7BA7E0'), rgb('#FFFFFF'), 4.5);
  assert(s, 'debería devolver una sugerencia');
  eq(s.token, 'blue/700', 'debe elegir el azul cercano, no el gris: ');
  assert(s.ratio >= 4.5);
});

test('devuelve null cuando ningún tono alcanza el ratio', function() {
  M.setDesignSystemPalette([]);
  // amarillo puro sobre blanco no llega a 7:1 (AAA) por más que se oscurezca sin cambiar tono? sí llega.
  // Caso real imposible: exigir 21:1 contra un fondo gris medio.
  var s = M.suggestAccessibleColor(rgb('#808080'), rgb('#808080'), 21);
  eq(s, null);
});

test('modo explorar ignora los tokens y propone un hex nuevo', function() {
  M.setDesignSystemPalette([
    { name: 'blue/700', hex: '#1B4F9C', r: 27, g: 79, b: 156 }
  ]);
  var s = M.suggestAccessibleColor(rgb('#7BA7E0'), rgb('#FFFFFF'), 4.5, 'explorar');
  assert(s, 'debería sugerir algo');
  eq(s.token, null, 'en explorar no se usa el token: ');
  eq(s.modo, 'explorar');
});

test('modo sistema no inventa un hex si ningún token pasa', function() {
  M.setDesignSystemPalette([
    { name: 'blue/200', hex: '#C7DAF5', r: 199, g: 218, b: 245 },
    { name: 'blue/300', hex: '#7BA7E0', r: 123, g: 167, b: 224 }
  ]);
  eq(M.suggestAccessibleColor(rgb('#7BA7E0'), rgb('#FFFFFF'), 4.5, 'sistema'), null);
});

test('sin ningún token, modo sistema cae al hex y lo marca fuera del sistema', function() {
  M.setDesignSystemPalette([]);
  var s = M.suggestAccessibleColor(rgb('#7BA7E0'), rgb('#FFFFFF'), 4.5, 'sistema');
  assert(s && s.hex, 'debería sugerir un hex');
  eq(s.fueraDelSistema, true);
});

test('el origen forzado define la familia aunque el color mezclado no coincida', function() {
  // Un texto blue/300 al 80% ya no tiene el hex del token: sin el origen, el
  // plugin no sabría de qué escala viene y elegiría por cercanía.
  M.setDesignSystemPalette([
    { name: 'blue/300', hex: '#7BA7E0', r: 123, g: 167, b: 224 },
    { name: 'blue/700', hex: '#1B4F9C', r: 27,  g: 79,  b: 156 },
    { name: 'teal/700', hex: '#136A63', r: 19,  g: 106, b: 99  }
  ]);
  var origen = { name: 'blue/300', hex: '#7BA7E0', r: 123, g: 167, b: 224 };
  var s = M.suggestAccessibleColor(rgb('#95B8E6'), rgb('#FFFFFF'), 4.5, 'sistema', origen);
  eq(s.token, 'blue/700');
  eq(s.mismaFamilia, true);
});

console.log('\n\x1b[1mÁrea de toque\x1b[0m');

test('botón de 16x16 falla AA (24px)', function() {
  var btn = node({ name: 'button / icon', width: 16, height: 16, type: 'FRAME' });
  var root = node({ name: 'root' }, [ btn ]);
  var res = M.auditTargetSize(root);
  eq(res.issues.length, 1);
  eq(res.issues[0].severity, 'fail');
});

test('botón de 32x32 pasa AA pero avisa por AAA (44px)', function() {
  var btn = node({ name: 'button / icon', width: 32, height: 32, type: 'FRAME' });
  var res = M.auditTargetSize(node({ name: 'root' }, [ btn ]));
  eq(res.issues.length, 1);
  eq(res.issues[0].severity, 'warning');
});

test('botón de 48x48 pasa limpio', function() {
  var btn = node({ name: 'button / primary', width: 48, height: 48, type: 'FRAME' });
  var res = M.auditTargetSize(node({ name: 'root' }, [ btn ]));
  eq(res.issues.length, 0);
  eq(res.passed, 1);
});

test('un botón oculto no genera hallazgo de área', function() {
  var btn = node({ name: 'button / icon', width: 12, height: 12, visible: false, type: 'FRAME' });
  var res = M.auditTargetSize(node({ name: 'root' }, [ btn ]));
  eq(res.issues.length, 0);
});

console.log('\n' + (failed === 0
  ? '\x1b[32m' + passed + ' tests OK\x1b[0m\n'
  : '\x1b[31m' + failed + ' fallaron\x1b[0m, ' + passed + ' OK\n'));

fs.unlinkSync(__dirname + '/_tmp_module.js');
process.exit(failed === 0 ? 0 : 1);
