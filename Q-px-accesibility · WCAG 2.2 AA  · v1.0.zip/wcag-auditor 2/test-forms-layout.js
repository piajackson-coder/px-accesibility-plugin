#!/usr/bin/env node
// Tipografía y layout, formularios, interacción y calidad del reporte.

var M = require('./_ctx_boot.js');

var passed=0, failed=0;
function test(l,f){ try{ f(); console.log('  \x1b[32m✓\x1b[0m '+l); passed++; }
  catch(e){ console.log('  \x1b[31m✕\x1b[0m '+l+'\n    \x1b[33m→ '+e.message+'\x1b[0m'); failed++; } }
function assert(c,m){ if(!c) throw new Error(m||'falló'); }
function eq(a,b,m){ if(a!==b) throw new Error((m||'')+' esperado '+JSON.stringify(b)+', obtenido '+JSON.stringify(a)); }

var idc = 0;
function node(p, children){
  var n = Object.assign({ type:'FRAME', name:'capa', visible:true, opacity:1,
    x:0, y:0, width:120, height:40, id:'n'+(++idc) }, p);
  n.absoluteBoundingBox = { x:n.x, y:n.y, width:n.width, height:n.height };
  if (children){ n.children = children; children.forEach(function(c){ c.parent = n; }); }
  return n;
}
function fill(hex){
  return { type:'SOLID', visible:true, color:{
    r:parseInt(hex.slice(1,3),16)/255, g:parseInt(hex.slice(3,5),16)/255, b:parseInt(hex.slice(5,7),16)/255 } };
}
function txt(chars, hex, size, p){
  return node(Object.assign({ type:'TEXT', characters:chars, fontSize:size||14, name:chars,
    fills:[fill(hex||'#000000')], fontName:{family:'Inter',style:'Regular'},
    textAutoResize:'HEIGHT' }, p||{}));
}

console.log('\n\x1b[1m1.4.12 Espaciado del texto\x1b[0m');

test('interlineado corto en contenedor de alto fijo es un fallo', function(){
  // La norma exige soportar 1.5×. Con alto fijo, el texto se recorta.
  var t = txt('Un párrafo de ejemplo', '#000', 16,
    { height:19, textAutoResize:'NONE' });
  t.lineHeight = { unit:'PIXELS', value:19 };
  var root = node({ name:'Card', fills:[fill('#FFF')] }, [ t ]);
  var r = M.auditTextSpacing(root);
  var f = r.issues.filter(function(i){ return i.severity === 'fail'; })[0];
  assert(f, 'debería fallar: ' + JSON.stringify(r.issues));
  eq(f.wcag, '1.4.12');
  eq(f.detail.lineHeightRequerido, 24, '16px × 1.5 = 24px: ');
});

test('interlineado corto con alto automático es solo aviso', function(){
  var t = txt('Un párrafo de ejemplo', '#000', 16, { height:19 });
  t.lineHeight = { unit:'PIXELS', value:19 };
  var root = node({ name:'Card', fills:[fill('#FFF')] }, [ t ]);
  var r = M.auditTextSpacing(root);
  assert(r.issues.every(function(i){ return i.severity === 'warning'; }),
    'si puede crecer, no es un fallo');
});

test('interlineado de 1.5x o más pasa', function(){
  var t = txt('Un párrafo', '#000', 16, { height:24 });
  t.lineHeight = { unit:'PIXELS', value:24 };
  var root = node({ name:'Card', fills:[fill('#FFF')] }, [ t ]);
  var r = M.auditTextSpacing(root);
  eq(r.issues.filter(function(i){ return i.wcag === '1.4.12' &&
       i.detail.lineHeightRequerido; }).length, 0);
  assert(r.passed > 0);
});

test('acepta interlineado en porcentaje', function(){
  var t = txt('Texto', '#000', 20, { height:22, textAutoResize:'NONE' });
  t.lineHeight = { unit:'PERCENT', value:110 };
  var r = M.auditTextSpacing(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  assert(r.issues.length > 0, '110% de 20px = 22px, por debajo de 30px');
});

console.log('\n\x1b[1m1.4.10 Reflow y 1.4.4 Zoom\x1b[0m');

test('detecta anchos fijos que no pueden encoger', function(){
  var rigido = node({ name:'Tabla de precios', width:900, height:300, fills:[fill('#FFF')],
                      constraints:{ horizontal:'LEFT', vertical:'TOP' } });
  var root = node({ name:'Pantalla', width:1280, height:800, fills:[fill('#FFF')] }, [ rigido ]);
  var r = M.auditReflow(root);
  var i = r.issues.filter(function(x){ return x.wcag === '1.4.10'; })[0];
  assert(i, 'debería detectar el ancho rígido');
  assert(i.message.indexOf('900px') > -1);
});

test('un hijo con constraint izquierda-derecha sí encoge', function(){
  var flexible = node({ name:'Contenido', width:900, height:300, fills:[fill('#FFF')],
                        constraints:{ horizontal:'LEFT_RIGHT', vertical:'TOP' } });
  var root = node({ name:'Pantalla', width:1280, height:800, fills:[fill('#FFF')] }, [ flexible ]);
  var r = M.auditReflow(root);
  eq(r.issues.filter(function(x){ return x.wcag === '1.4.10'; }).length, 0);
});

test('un frame que ya mide 320px no se evalúa', function(){
  var root = node({ name:'Mobile', width:320, height:640, fills:[fill('#FFF')] });
  eq(M.auditReflow(root).issues.length, 0);
});

test('detecta texto sin lugar para crecer al 200%', function(){
  var t = txt('Título', '#000', 20, { height:22, textAutoResize:'NONE' });
  var root = node({ name:'Pantalla', width:1280, height:800, fills:[fill('#FFF')] }, [ t ]);
  var r = M.auditReflow(root);
  assert(r.issues.some(function(i){ return i.wcag === '1.4.4'; }),
    '20px necesita 48px de alto al 200%, tiene 22');
});

console.log('\n\x1b[1mLegibilidad\x1b[0m');

test('marca líneas de más de 80 caracteres', function(){
  var largo = new Array(300).join('a ');
  var t = txt(largo, '#000', 16, { width:1200 });
  var r = M.auditLegibilidad(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  var i = r.issues.filter(function(x){ return x.message.indexOf('caracteres por línea') > -1; })[0];
  assert(i, 'debería marcar la línea larga');
  assert(i.detail.caracteresPorLinea > 80);
});

test('una medida cómoda pasa', function(){
  var t = txt('Un párrafo de largo razonable para leer', '#000', 16, { width:560 });
  var r = M.auditLegibilidad(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  eq(r.issues.filter(function(x){ return x.detail.caracteresPorLinea; }).length, 0);
});

test('marca mayúsculas sostenidas largas', function(){
  var t = txt('ESTE ES UN TEXTO LARGO EN MAYUSCULAS SOSTENIDAS', '#000', 14, { width:400 });
  var r = M.auditLegibilidad(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  assert(r.issues.some(function(i){ return i.message.indexOf('mayúsculas') > -1; }));
});

test('una etiqueta corta en mayúsculas no se marca', function(){
  var t = txt('NUEVO', '#000', 11, { width:60 });
  var r = M.auditLegibilidad(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  eq(r.issues.filter(function(i){ return i.message.indexOf('mayúsculas') > -1; }).length, 0);
});

test('detecta mayúsculas por textCase, no solo por el contenido', function(){
  var t = txt('este texto se ve en mayusculas por estilo', '#000', 14, { width:400 });
  t.textCase = 'UPPER';
  var r = M.auditLegibilidad(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  var i = r.issues.filter(function(x){ return x.message.indexOf('mayúsculas') > -1; })[0];
  assert(i, 'debería detectarlo por textCase');
  eq(i.detail.viaTextCase, true);
});

test('marca el texto justificado', function(){
  var t = txt('Un párrafo suficientemente largo como para que el justificado importe de verdad',
              '#000', 14, { width:400 });
  t.textAlignHorizontal = 'JUSTIFIED';
  var r = M.auditLegibilidad(node({ name:'C', fills:[fill('#FFF')] }, [ t ]));
  assert(r.issues.some(function(i){ return i.message.indexOf('justificado') > -1; }));
});

console.log('\n\x1b[1mPlaceholder usado como etiqueta\x1b[0m');

test('un campo sin label y con placeholder gris es un fallo', function(){
  var ph = txt('nombre@dominio.com', '#B0B0B0', 14, { name:'Placeholder' });
  var campo = node({ name:'Input / email', width:300, height:44, fills:[fill('#FFFFFF')] }, [ ph ]);
  node({ name:'Formulario', fills:[fill('#FFFFFF')] }, [ campo ]);
  var r = M.auditPlaceholder(campo);
  eq(r.issues.length, 1);
  eq(r.issues[0].wcag, '3.3.2');
});

test('con etiqueta arriba, el placeholder está bien', function(){
  var label = txt('Email', '#111111', 12, { name:'Label', y:0, height:16 });
  var ph = txt('nombre@dominio.com', '#B0B0B0', 14, { name:'Placeholder', y:24 });
  var campo = node({ name:'Input / email', y:22, width:300, height:44, fills:[fill('#FFFFFF')] }, [ ph ]);
  node({ name:'Formulario', fills:[fill('#FFFFFF')] }, [ label, campo ]);
  eq(M.auditPlaceholder(campo).issues.length, 0);
});

console.log('\n\x1b[1mFormularios\x1b[0m');

function campoCon(nombre, labelTexto){
  var hijos = [];
  if (labelTexto) hijos.push(txt(labelTexto, '#111', 12, { name:'Label' }));
  var campo = node({ name:nombre, width:300, height:44, fills:[fill('#FFFFFF')] }, hijos);
  node({ name:'Formulario', fills:[fill('#FFFFFF')] }, [ campo ]);
  return campo;
}

test('sugiere autocomplete y type para un campo de email', function(){
  var r = M.auditFormularios(campoCon('Input / email', 'Email'));
  var i = r.issues.filter(function(x){ return x.wcag === '1.3.5'; })[0];
  assert(i, 'debería sugerir el token');
  eq(i.detail.autocomplete, 'email');
  eq(i.detail.tipo, 'email');
});

test('sugiere teclado numérico para código postal', function(){
  var r = M.auditFormularios(campoCon('Input / codigo postal', 'Código postal'));
  var i = r.issues.filter(function(x){ return x.wcag === '1.3.5'; })[0];
  eq(i.detail.autocomplete, 'postal-code');
  eq(i.detail.inputmode, 'numeric');
});

test('la frase más larga gana: "nueva contraseña" no es "contraseña"', function(){
  var r = M.auditFormularios(campoCon('Input / password', 'Nueva contraseña'));
  var i = r.issues.filter(function(x){ return x.wcag === '1.3.5'; })[0];
  eq(i.detail.autocomplete, 'new-password');
});

test('tarjeta de crédito sugiere cc-number', function(){
  var r = M.auditFormularios(campoCon('Input / tarjeta', 'Número de tarjeta'));
  var i = r.issues.filter(function(x){ return x.wcag === '1.3.5'; })[0];
  eq(i.detail.autocomplete, 'cc-number');
});

test('un campo sin etiqueta es un fallo', function(){
  var r = M.auditFormularios(campoCon('Input / email', null));
  var i = r.issues.filter(function(x){ return x.detail.sinLabel; })[0];
  assert(i);
  eq(i.severity, 'fail');
});

test('marca la etiqueta demasiado lejos del campo', function(){
  var label = txt('Email', '#111', 12, { name:'Label', y:0, height:16 });
  var campo = node({ name:'Input / email', y:60, width:300, height:44, fills:[fill('#FFFFFF')] });
  node({ name:'Formulario', fills:[fill('#FFFFFF')] }, [ label, campo ]);
  var r = M.auditFormularios(campo);
  assert(r.issues.some(function(i){ return i.message.indexOf('px del campo') > -1; }),
    'a 44px la asociación visual se pierde');
});

test('el asterisco solo, sin la palabra, es un aviso', function(){
  var r = M.auditFormularios(campoCon('Input / email', 'Email *'));
  assert(r.issues.some(function(i){ return i.detail.asteriscoSolo; }));
});

test('con la palabra "requerido" no se marca', function(){
  var r = M.auditFormularios(campoCon('Input / email', 'Email * (requerido)'));
  eq(r.issues.filter(function(i){ return i.detail.asteriscoSolo; }).length, 0);
});

test('marca el mensaje de error lejos del campo', function(){
  var campo = node({ name:'Input / email', y:0, width:300, height:44, fills:[fill('#FFF')] },
    [ txt('Email', '#111', 12, { name:'Label' }) ]);
  var err = txt('Email inválido', '#B00', 12, { name:'Error message', y:100, height:16 });
  node({ name:'Formulario', fills:[fill('#FFF')] }, [ campo, err ]);
  var r = M.auditFormularios(campo);
  assert(r.issues.some(function(i){ return i.wcag === '3.3.1'; }));
});

console.log('\n\x1b[1m2.5.8 Espaciado entre objetivos\x1b[0m');

test('un objetivo chico con 24px de separación cumple por excepción', function(){
  // La excepción que el plugin ignoraba: no es solo el tamaño.
  var a = node({ name:'Button / a', x:0,  y:0, width:16, height:16 });
  var b = node({ name:'Button / b', x:40, y:0, width:16, height:16 });
  var root = node({ name:'Barra', width:200, height:40 }, [ a, b ]);
  var r = M.auditTargetSpacing(root);
  var i = r.issues.filter(function(x){ return x.nodeName === 'Button / a'; })[0];
  assert(i, 'debería reportarlo');
  eq(i.severity, 'warning', 'cumple por excepción, no es fallo: ');
  eq(i.detail.porExcepcion, true);
});

test('un objetivo chico y pegado a otro sí falla', function(){
  var a = node({ name:'Button / a', x:0,  y:0, width:16, height:16 });
  var b = node({ name:'Button / b', x:18, y:0, width:16, height:16 });
  var root = node({ name:'Barra', width:200, height:40 }, [ a, b ]);
  var r = M.auditTargetSpacing(root);
  var i = r.issues.filter(function(x){ return x.severity === 'fail'; })[0];
  assert(i, 'a 18px de separación no alcanza');
});

test('detecta objetivos superpuestos', function(){
  var a = node({ name:'Button / a', x:0,  y:0, width:60, height:40 });
  var b = node({ name:'Button / b', x:40, y:0, width:60, height:40 });
  var root = node({ name:'Barra', width:200, height:60 }, [ a, b ]);
  var r = M.auditTargetSpacing(root);
  assert(r.issues.some(function(i){ return i.message.indexOf('se superponen') > -1; }));
});

test('un botón adentro de otro no cuenta como superposición', function(){
  var interno = node({ name:'Button / interno', x:10, y:5, width:40, height:30 });
  var externo = node({ name:'Button / externo', x:0, y:0, width:200, height:44 }, [ interno ]);
  var root = node({ name:'Card', width:220, height:60 }, [ externo ]);
  var r = M.auditTargetSpacing(root);
  eq(r.issues.filter(function(i){ return i.message.indexOf('se superponen') > -1; }).length, 0,
     'el anidamiento es legítimo: ');
});

console.log('\n\x1b[1m2.4.11 Apariencia del indicador de foco\x1b[0m');

function setConFoco(strokeHex, grosor, defaultStrokeHex){
  var focus = node({ type:'COMPONENT', name:'State=Focus', width:120, height:44,
    fills:[fill('#FFFFFF')], strokeWeight:grosor,
    strokes:[{ type:'SOLID', visible:true, color:fill(strokeHex).color }] },
    [ txt('Acción', '#111', 15) ]);
  var def = node({ type:'COMPONENT', name:'State=Default', width:120, height:44,
    fills:[fill('#FFFFFF')], strokeWeight:1,
    strokes: defaultStrokeHex ? [{ type:'SOLID', visible:true, color:fill(defaultStrokeHex).color }] : [] },
    [ txt('Acción', '#111', 15) ]);
  var set = node({ type:'COMPONENT_SET', name:'Button' }, [ def, focus ]);
  node({ name:'Librería', fills:[fill('#FFFFFF')] }, [ set ]);
  return set;
}

test('un anillo de foco sin contraste es un fallo', function(){
  var set = setConFoco('#EEEEEE', 2);
  var r = M.auditFocusAppearance(set);
  var i = r.issues.filter(function(x){ return x.detail.ratio !== undefined; })[0];
  assert(i, 'debería medir el contraste del anillo');
  eq(i.severity, 'fail');
  assert(i.detail.ratio < 3);
});

test('un anillo de 1px es un aviso por grosor', function(){
  var set = setConFoco('#1B4F9C', 1);
  var r = M.auditFocusAppearance(set);
  assert(r.issues.some(function(i){ return i.detail.grosor === 1; }));
});

test('un anillo de 2px con buen contraste pasa', function(){
  var set = setConFoco('#1B4F9C', 2);
  var r = M.auditFocusAppearance(set);
  eq(r.issues.filter(function(i){ return i.severity === 'fail'; }).length, 0);
  assert(r.passed > 0);
});

test('avisa si el anillo es igual al borde normal', function(){
  var set = setConFoco('#1B4F9C', 1, '#1B4F9C');
  var r = M.auditFocusAppearance(set);
  assert(r.issues.some(function(i){ return i.message.indexOf('mismo color') > -1; }),
    'mismo color y mismo grosor: el cambio no se percibe');
});

test('la variante de foco sin trazo es un fallo', function(){
  var focus = node({ type:'COMPONENT', name:'State=Focus', width:120, height:44,
                     fills:[fill('#F0F0F0')], strokes:[] }, [ txt('Acción', '#111', 15) ]);
  var def = node({ type:'COMPONENT', name:'State=Default', width:120, height:44,
                   fills:[fill('#FFFFFF')], strokes:[] }, [ txt('Acción', '#111', 15) ]);
  var set = node({ type:'COMPONENT_SET', name:'Button' }, [ def, focus ]);
  node({ name:'Librería', fills:[fill('#FFF')] }, [ set ]);
  var r = M.auditFocusAppearance(set);
  assert(r.issues.some(function(i){ return i.detail.sinTrazo; }));
});

console.log('\n\x1b[1mSeveridad por impacto\x1b[0m');

test('un control sin nombre es bloqueante', function(){
  eq(M.impactoDe({ type:'aria', severity:'fail', detail:{} }), 'bloqueante');
});

test('el contraste se gradúa por la distancia al umbral', function(){
  // 4.4 sobre 4.5 y 1.5 sobre 4.5 son los dos "AA" y no se parecen en nada
  eq(M.impactoDe({ type:'contrast', severity:'fail', detail:{ ratio:4.4, required:4.5 } }), 'moderado');
  eq(M.impactoDe({ type:'contrast', severity:'fail', detail:{ ratio:3.5, required:4.5 } }), 'serio');
  eq(M.impactoDe({ type:'contrast', severity:'fail', detail:{ ratio:1.5, required:4.5 } }), 'bloqueante');
});

test('un campo sin etiqueta es bloqueante', function(){
  eq(M.impactoDe({ type:'placeholder', severity:'fail', detail:{} }), 'bloqueante');
  eq(M.impactoDe({ type:'form', severity:'fail', detail:{} }), 'bloqueante');
});

test('la legibilidad es menor, no bloquea nada', function(){
  eq(M.impactoDe({ type:'legibilidad', severity:'warning', detail:{} }), 'menor');
});

test('anotarImpacto escribe el impacto y su orden', function(){
  var issues = [
    { type:'legibilidad', severity:'warning', detail:{} },
    { type:'aria', severity:'fail', detail:{} }
  ];
  M.anotarImpacto(issues);
  eq(issues[1].impacto, 'bloqueante');
  assert(issues[1].impactoOrden < issues[0].impactoOrden, 'lo bloqueante ordena primero');
});

test('las cuatro escalas de impacto están definidas', function(){
  ['bloqueante','serio','moderado','menor'].forEach(function(k){
    assert(M.IMPACTO[k] && M.IMPACTO[k].definicion, 'falta ' + k);
  });
});

console.log('\n\x1b[1mCobertura y checklist manual\x1b[0m');

test('la cobertura cuenta capas y criterios', function(){
  var root = node({ name:'Pantalla', width:390, height:600, fills:[fill('#FFF')] }, [
    txt('Título', '#000', 24),
    node({ name:'Button / ok', width:100, height:44 }, [ txt('OK', '#FFF', 14) ])
  ]);
  var c = M.calcularCobertura(root, {});
  assert(c.capasVisibles > 0);
  eq(c.criteriosTotales, 55, 'WCAG 2.2 A/AA tiene 55 criterios: ');
  assert(c.porcentajeAutomatico > 0 && c.porcentajeAutomatico < 100,
    'ningún plugin cubre el 100%: ' + c.porcentajeAutomatico);
  assert(c.nota.indexOf('revisión humana') > -1);
});

test('la cobertura reporta las capas ocultas aparte', function(){
  var root = node({ name:'Pantalla', fills:[fill('#FFF')] }, [
    txt('Visible', '#000', 14),
    node({ name:'Oculto', visible:false }, [ txt('No', '#000', 14) ])
  ]);
  var c = M.calcularCobertura(root, {});
  assert(c.capasOcultas >= 2, 'ocultas: ' + c.capasOcultas);
});

test('el checklist solo trae tareas que aplican', function(){
  // Una pantalla sin formularios no debería pedir revisar errores de formulario
  var root = node({ name:'Landing', width:1280, height:800, fills:[fill('#FFF')] }, [
    txt('Bienvenido', '#000', 32) ]);
  var ch = M.checklistManual(root, false);
  var ids = ch.tareas.map(function(t){ return t.id; });
  assert(ids.indexOf('3.3.3') === -1, 'no hay formularios: no debería pedir 3.3.3');
  assert(ids.indexOf('1.4.1') > -1, '1.4.1 aplica siempre');
});

test('con formularios sí aparecen sus tareas', function(){
  var campo = node({ name:'Input / email', width:300, height:44 });
  var root = node({ name:'Registro', width:1280, height:800, fills:[fill('#FFF')] }, [ campo ]);
  var ids = M.checklistManual(root, false).tareas.map(function(t){ return t.id; });
  assert(ids.indexOf('3.3.3') > -1 && ids.indexOf('3.3.4') > -1);
});

test('con modales aparece la tarea de trampa de foco', function(){
  var root = node({ name:'Modal / confirmar', width:400, height:300, fills:[fill('#FFF')] },
    [ txt('¿Seguro?', '#000', 18) ]);
  var ids = M.checklistManual(root, false).tareas.map(function(t){ return t.id; });
  assert(ids.indexOf('2.1.2') > -1);
});

test('en móvil aparecen orientación y gestos', function(){
  var root = node({ name:'App', width:390, height:844, fills:[fill('#FFF')] },
    [ txt('Hola', '#000', 16) ]);
  var ids = M.checklistManual(root, false).tareas.map(function(t){ return t.id; });
  assert(ids.indexOf('1.3.4') > -1 && ids.indexOf('2.5.1') > -1);
});

test('cada tarea dice qué mirar y cómo verificarlo', function(){
  var root = node({ name:'App', width:390, height:844, fills:[fill('#FFF')] },
    [ txt('Hola', '#000', 16) ]);
  M.checklistManual(root, false).tareas.forEach(function(t){
    assert(t.que && t.que.length > 3, t.id + ' sin "qué"');
    assert(t.como && t.como.length > 30, t.id + ' sin instrucción concreta de cómo verificarlo');
    assert(t.nivel === 'A' || t.nivel === 'AA', t.id + ' sin nivel');
  });
});

test('las tareas salen ordenadas por número de criterio', function(){
  var root = node({ name:'App', width:390, height:844, fills:[fill('#FFF')] },
    [ txt('Hola', '#000', 16) ]);
  var ids = M.checklistManual(root, false).tareas.map(function(t){ return t.id; });
  var ordenado = ids.slice().sort(function(a,b){
    var pa=a.split('.').map(Number), pb=b.split('.').map(Number);
    return pa[0]-pb[0]||pa[1]-pb[1]||pa[2]-pb[2];
  });
  eq(ids.join(','), ordenado.join(','));
});

console.log('\n\x1b[1m2.5.5 es AAA: no ensucia un reporte de AA\x1b[0m');

test('los controles entre 24 y 44px no son un hallazgo por cabeza', function(){
  var root = node({ name:'Barra', width:400, height:60 }, [
    node({ name:'Button / a', x:0,   width:32, height:32 }),
    node({ name:'Button / b', x:60,  width:32, height:32 }),
    node({ name:'Button / c', x:120, width:32, height:32 }),
    node({ name:'Button / d', x:180, width:32, height:32 })
  ]);
  var r = M.auditTargetSize(root);
  var deAAA = r.issues.filter(function(i){ return i.wcag === '2.5.5'; });
  eq(deAAA.length, 1, 'cuatro controles, una sola nota: ');
  eq(deAAA[0].detail.cantidad, 4);
  eq(deAAA[0].detail.soloRecomendacion, true);
  assert(deAAA[0].fix.indexOf('No es un incumplimiento de AA') > -1,
    'tiene que aclarar que no es AA');
});

test('los cuatro cuentan como que pasan', function(){
  var root = node({ name:'Barra', width:400, height:60 }, [
    node({ name:'Button / a', x:0,  width:32, height:32 }),
    node({ name:'Button / b', x:60, width:32, height:32 })
  ]);
  eq(M.auditTargetSize(root).passed, 2);
});

test('por debajo de 24px sí es un fallo de AA, uno por control', function(){
  var root = node({ name:'Barra', width:400, height:60 }, [
    node({ name:'Button / a', x:0,  width:16, height:16 }),
    node({ name:'Button / b', x:60, width:16, height:16 })
  ]);
  var r = M.auditTargetSize(root);
  eq(r.issues.filter(function(i){ return i.severity === 'fail'; }).length, 2);
});

console.log('\n\x1b[1mMedición de texto en los documentos de canvas\x1b[0m');

test('la estimación cuenta las líneas que ocupa el texto', function(){
  var D = M.Doc;
  // 200 caracteres a 12px en 300px de ancho no entran en una línea
  var largo = new Array(201).join('a');
  var unaLinea = D.estimarAlto('hola', 300, 12);
  var varias  = D.estimarAlto(largo, 300, 12);
  assert(varias > unaLinea * 2,
    'un texto largo tiene que ocupar varias líneas: ' + varias + ' vs ' + unaLinea);
});

test('respeta los saltos de línea explícitos', function(){
  var D = M.Doc;
  var uno = D.estimarAlto('hola', 400, 14);
  var tres = D.estimarAlto('hola\nchau\nadios', 400, 14);
  assert(tres >= uno * 3, 'tres párrafos: ' + tres + ' vs ' + uno);
});

test('el interlineado declarado manda sobre la estimación', function(){
  var D = M.Doc;
  eq(D.estimarAlto('hola', 400, 34, 40), 40);
});

test('el cursor avanza por el alto REAL aunque la API mienta', function(){
  // Este era el bug: Figma puede reportar el alto de una sola línea aunque el
  // texto ocupe varias. Si el código confía en eso, los bloques se pisan.
  var D = M.Doc;
  var creados = [];
  var frameFalso = {
    children: creados,
    appendChild: function(c){ creados.push(c); c.parent = this; },
    resize: function(w,h){ this.width = w; this.height = h; }
  };
  var textosCreados = [];
  var figmaPrevio = global.figma.createText;
  global.figma.createText = function(){
    var t = { type:'TEXT', characters:'', fills:[], x:0, y:0, width:100, height:16,
      // La API miente: siempre reporta una línea
      resize:function(w,h){ this.width = w; this.height = Math.round((this.fontSize||14)*1.2); },
      set textAutoResize(v){}, get textAutoResize(){ return 'HEIGHT'; },
      set layoutAlign(v){}, set layoutGrow(v){} };
    textosCreados.push(t); return t;
  };

  var d = new D(frameFalso, 0, 400);
  var largo = new Array(301).join('b');
  d.texto(largo, 12, false, null, {});
  var yTrasLargo = d.y;
  d.texto('siguiente', 12, false, null, {});

  global.figma.createText = figmaPrevio;

  var necesita = D.estimarAlto(largo, 400, 12);
  assert(yTrasLargo >= necesita,
    'el cursor avanzó ' + yTrasLargo + ' pero el texto ocupa ' + necesita);
  assert(textosCreados[1].y >= necesita,
    'el segundo texto arranca en ' + textosCreados[1].y + ', encima del primero');
});

console.log('\n\x1b[1mWCAG 2.2: criterios nuevos\x1b[0m');

test('el catálogo cuenta 55 criterios de 2.2 A/AA', function(){
  // 2.1 tiene 50; 2.2 suma 6 y retira 4.1.1
  var c = M.wcagCatalogue().filter(function(x){ return !x.obsolete; });
  eq(c.length, 55);
  ['2.4.11','2.5.7','2.5.8','3.2.6','3.3.7','3.3.8'].forEach(function(id){
    assert(c.some(function(x){ return x.id === id; }), 'falta ' + id);
  });
  assert(!c.some(function(x){ return x.id === '4.1.1'; }), '4.1.1 se retiró en 2.2');
});

test('2.4.11 detecta una barra fija que puede tapar el foco', function(){
  var header = node({ name:'Header sticky', x:0, y:0, width:390, height:64,
                      fills:[fill('#FFFFFF')] });
  var boton  = node({ name:'Button / ok', x:20, y:300, width:200, height:44,
                      reactions:[{trigger:{type:'ON_CLICK'}}] });
  var p = node({ name:'Pantalla', width:390, height:700, fills:[fill('#FFF')] }, [ header, boton ]);
  var r = M.auditFocusObscured(p);
  var i = r.issues.filter(function(x){ return x.wcag === '2.4.11'; })[0];
  assert(i, 'debería avisar por el header fijo');
  eq(i.detail.anclado, 'arriba');
});

test('sin barras flotantes no hay hallazgo de 2.4.11', function(){
  var p = node({ name:'Pantalla', width:390, height:700, fills:[fill('#FFF')] }, [
    node({ name:'Contenido', y:100, width:390, height:400 }) ]);
  eq(M.auditFocusObscured(p).issues.length, 0);
});

test('2.5.7 marca un slider sin alternativa de un toque', function(){
  var s = node({ name:'Slider / precio', width:300, height:32 });
  node({ name:'Filtros', fills:[fill('#FFF')] }, [ s ]);
  var r = M.auditDragging(s);
  eq(r.issues.length, 1);
  eq(r.issues[0].wcag, '2.5.7');
});

test('un slider con campo numérico al lado pasa', function(){
  var s = node({ name:'Slider / precio', width:300, height:32 });
  var campo = node({ name:'Input / precio', x:310, width:80, height:32 });
  node({ name:'Filtros', fills:[fill('#FFF')] }, [ s, campo ]);
  eq(M.auditDragging(s).issues.length, 0);
});

test('un carrusel con flechas adentro pasa', function(){
  var flecha = node({ name:'Arrow / next', width:32, height:32 });
  var c = node({ name:'Carousel / destacados', width:600, height:300 }, [ flecha ]);
  node({ name:'Home', fills:[fill('#FFF')] }, [ c ]);
  eq(M.auditDragging(c).issues.length, 0);
});

test('3.3.8 marca el CAPTCHA como fallo', function(){
  var cap = node({ name:'Captcha', width:300, height:80 });
  var p = node({ name:'Login', width:390, height:600, fills:[fill('#FFF')] }, [ cap ]);
  var r = M.auditAuth(p);
  var i = r.issues.filter(function(x){ return x.detail.tipo === 'captcha'; })[0];
  assert(i);
  eq(i.severity, 'fail');
  eq(i.wcag, '3.3.8');
});

test('3.3.8 avisa sobre el campo de código de verificación', function(){
  var otp = node({ name:'Input / OTP', width:300, height:44 });
  var p = node({ name:'Verificación', width:390, height:600, fills:[fill('#FFF')] }, [
    node({ name:'Login form' }, [ otp ]) ]);
  var r = M.auditAuth(p);
  assert(r.issues.some(function(x){ return x.detail.tipo === 'otp'; }),
    'debería pedir que se pueda pegar el código');
});

test('una pantalla que no es de login no dispara 3.3.8', function(){
  var p = node({ name:'Catálogo', width:390, height:600, fills:[fill('#FFF')] }, [
    node({ name:'Card / clase', width:300, height:200 }) ]);
  eq(M.auditAuth(p).issues.length, 0);
});

test('3.2.6 marca la ayuda que cambia de lugar entre pantallas', function(){
  var a = node({ name:'P1', width:400, height:800, fills:[fill('#FFF')] }, [
    node({ name:'Button / ayuda', x:340, y:20, width:40, height:40,
           reactions:[{trigger:{type:'ON_CLICK'}}] }) ]);
  var b = node({ name:'P2', width:400, height:800, fills:[fill('#FFF')] }, [
    node({ name:'Button / ayuda', x:20, y:720, width:40, height:40,
           reactions:[{trigger:{type:'ON_CLICK'}}] }) ]);
  var r = M.auditAyudaCoherente([a, b]);
  eq(r.issues.length, 1);
  eq(r.issues[0].wcag, '3.2.6');
});

test('la ayuda en el mismo lugar no genera hallazgo', function(){
  var a = node({ name:'P1', width:400, height:800, fills:[fill('#FFF')] }, [
    node({ name:'Button / ayuda', x:340, y:20, width:40, height:40,
           reactions:[{trigger:{type:'ON_CLICK'}}] }) ]);
  var b = node({ name:'P2', width:400, height:800, fills:[fill('#FFF')] }, [
    node({ name:'Button / ayuda', x:340, y:20, width:40, height:40,
           reactions:[{trigger:{type:'ON_CLICK'}}] }) ]);
  eq(M.auditAyudaCoherente([a, b]).issues.length, 0);
});

test('el anillo de foco se reporta bajo 2.4.7, no 2.4.11', function(){
  // 2.4.11 en WCAG 2.2 es "Foco no oscurecido": otro criterio. La apariencia
  // del anillo es 2.4.7 (AA) y su refinamiento 2.4.13 (AAA).
  var focus = node({ type:'COMPONENT', name:'State=Focus', width:120, height:44,
    fills:[fill('#FFFFFF')], strokeWeight:2,
    strokes:[{ type:'SOLID', visible:true, color:fill('#EEEEEE').color }] },
    [ txt('Acción','#111',15) ]);
  var def = node({ type:'COMPONENT', name:'State=Default', width:120, height:44,
    fills:[fill('#FFFFFF')], strokeWeight:1, strokes:[] }, [ txt('Acción','#111',15) ]);
  var set = node({ type:'COMPONENT_SET', name:'Button / primary' }, [ def, focus ]);
  node({ name:'Librería', fills:[fill('#FFFFFF')] }, [ set ]);
  var r = M.auditFocusAppearance(set);
  assert(r.issues.length > 0,
    'un anillo #EEEEEE sobre blanco no llega a 3:1: debería reportarse');
  r.issues.forEach(function(i){
    eq(i.wcag, '2.4.7', 'la apariencia del anillo no es 2.4.11: ');
  });
});

console.log('\n\x1b[1mEl documento no se cae por un valor inesperado\x1b[0m');

test('la estimación soporta ancho o tamaño inválidos', function(){
  var D = M.Doc;
  // Un NaN acá se propagaba al alto del frame y hacía que resize tirara
  // excepción, dejando el documento a medias sin ninguna explicación.
  [undefined, null, NaN, 0, -5].forEach(function(malo){
    var r1 = D.estimarAlto('hola', malo, 14);
    var r2 = D.estimarAlto('hola', 400, malo);
    assert(isFinite(r1) && r1 > 0, 'ancho ' + malo + ' dio ' + r1);
    assert(isFinite(r2) && r2 > 0, 'tamaño ' + malo + ' dio ' + r2);
  });
});

test('el cursor nunca queda en NaN', function(){
  var D = M.Doc;
  var creados = [];
  var frameFalso = {
    children: creados,
    appendChild: function(c){ creados.push(c); c.parent = this; },
    resize: function(w,h){ this.width = w; this.height = h; }
  };
  var previo = global.figma.createText;
  global.figma.createText = function(){
    return { type:'TEXT', characters:'', fills:[], x:0, y:0,
      // La API devuelve basura
      height: NaN, width: NaN,
      resize:function(){}, set textAutoResize(v){}, set layoutAlign(v){}, set layoutGrow(v){} };
  };
  var d = new D(frameFalso, 44, 620);
  d.texto('un texto cualquiera', 14, false, null, {});
  d.texto('otro', 12, false, null, { gap: NaN });
  global.figma.createText = previo;
  assert(isFinite(d.y), 'el cursor quedó en ' + d.y);
  assert(d.y > 0, 'el cursor no avanzó');
});

test('cerrar una sección vacía no produce un alto inválido', function(){
  var D = M.Doc;
  var alturas = [];
  var frameFalso = {
    children: [], appendChild: function(c){ this.children.push(c); },
    resize: function(w,h){ alturas.push(h); this.width = w; this.height = h; }
  };
  var d = new D(frameFalso, 44, 620);
  d.y = NaN;
  d.cerrar();
  assert(alturas.every(function(h){ return isFinite(h) && h >= 1; }),
    'alturas: ' + alturas.join(','));
});

console.log('\n\x1b[1mAgrupación de hallazgos repetidos\x1b[0m');

test('24 filas con el mismo problema son UN hallazgo', function(){
  // 24 hallazgos idénticos no son información: son la misma información 24
  // veces, y ahogan a los únicos que sí merecen atención.
  var issues = [];
  for (var i = 0; i < 24; i++) {
    issues.push({ type:'contrast', wcag:'1.4.3', severity:'fail', impacto:'serio',
      nodeId:'n'+i, nodeName:'Row title ' + i, marker: i < 25 ? i+1 : null,
      message:'Texto #8A94A6 sobre #FFFFFF da 3.06:1. Como es de 11px, necesita 4.5:1.',
      detail:{ fg:'#8A94A6', bg:'#FFFFFF', ratio:3.06, required:4.5 } });
  }
  var g = M.agruparHallazgos(issues);
  eq(g.length, 1, 'debería ser un solo grupo: ');
  eq(g[0].cantidad, 24);
  eq(g[0].afectados.length, 24);
});

test('un par de colores distinto es otro grupo', function(){
  var base = { type:'contrast', wcag:'1.4.3', severity:'fail', impacto:'serio',
    message:'Texto sobre fondo da N:1.', };
  var issues = [
    Object.assign({ nodeId:'a', nodeName:'A', detail:{ fg:'#8A94A6', bg:'#FFFFFF', required:4.5 } }, base),
    Object.assign({ nodeId:'b', nodeName:'B', detail:{ fg:'#CCCCCC', bg:'#FFFFFF', required:4.5 } }, base)
  ];
  eq(M.agruparHallazgos(issues).length, 2, 'colores distintos, arreglos distintos: ');
});

test('criterios distintos no se mezclan', function(){
  var issues = [
    { type:'contrast', wcag:'1.4.3', impacto:'serio', nodeId:'a', nodeName:'A',
      message:'x', detail:{} },
    { type:'aria', wcag:'4.1.2', impacto:'bloqueante', nodeId:'a', nodeName:'A',
      message:'x', detail:{} }
  ];
  eq(M.agruparHallazgos(issues).length, 2);
});

test('el grupo toma el peor impacto de sus integrantes', function(){
  var issues = [
    { type:'contrast', wcag:'1.4.3', impacto:'moderado', nodeId:'a', nodeName:'A',
      message:'Texto · sobre · da N:1.', detail:{ fg:'#AAA', bg:'#FFF', required:4.5 } },
    { type:'contrast', wcag:'1.4.3', impacto:'bloqueante', nodeId:'b', nodeName:'B',
      message:'Texto · sobre · da N:1.', detail:{ fg:'#AAA', bg:'#FFF', required:4.5 } }
  ];
  var g = M.agruparHallazgos(issues);
  eq(g.length, 1);
  eq(g[0].impacto, 'bloqueante', 'el grupo se ordena por el peor caso: ');
});

test('el grupo junta los marcadores de todos sus elementos', function(){
  var issues = [
    { type:'form', wcag:'3.3.2', impacto:'serio', nodeId:'a', nodeName:'A', marker:3,
      message:'sin label', detail:{ sinLabel:true } },
    { type:'form', wcag:'3.3.2', impacto:'serio', nodeId:'b', nodeName:'B', marker:7,
      message:'sin label', detail:{ sinLabel:true } }
  ];
  var g = M.agruparHallazgos(issues);
  eq(g[0].marcadores.join(','), '3,7');
});

test('sobre una pantalla real la reducción es drástica', function(){
  // Reconstruye el caso que motivó esto: sidebar, lista larga, tabs, acordeones
  var hijos = [];
  for (var i = 0; i < 12; i++) {
    hijos.push(node({ name:'Nav item / seccion'+i, y:i*48, width:56, height:48 },
      [ node({ name:'Icon / ico'+i, type:'VECTOR', width:20, height:20, fills:[fill('#5A6472')] }) ]));
  }
  for (var j = 0; j < 24; j++) {
    hijos.push(node({ name:'List row / REL'+j, x:60, y:j*36, width:220, height:36,
                      fills:[fill('#FFFFFF')] }, [
      txt('REL'+j, '#111111', 13, { name:'Row title' }),
      txt('Subtexto', '#8A94A6', 11, { name:'Row sub' }) ]));
  }
  var p = node({ name:'Dashboard', width:1920, height:1080, fills:[fill('#FFFFFF')] }, hijos);
  var a = M.runAudit(p);

  var sueltos = 0;
  Object.keys(a.results).forEach(function(k){ sueltos += (a.results[k].issues||[]).length; });

  assert(sueltos > 40, 'la pantalla debería producir muchos hallazgos, dio ' + sueltos);
  assert(a.grupos.length < sueltos / 4,
    'agrupado tendría que reducir mucho: ' + a.grupos.length + ' grupos de ' + sueltos);
  assert(a.cobertura.capasVisibles === a.cobertura.capasTotales,
    'la auditoría tiene que recorrer el frame entero');
});

console.log('\n\x1b[1mInventario: qué se miró de cada elemento\x1b[0m');

test('cada capa visible queda clasificada', function(){
  var p = node({ name:'Pantalla', width:390, height:700, fills:[fill('#FFFFFF')] }, [
    txt('Título', '#111', 24, { y:0 }),
    node({ name:'Foto', y:40, width:300, height:160, fills:[{type:'IMAGE',visible:true}] }),
    node({ name:'Button / ok', y:220, width:200, height:44,
           reactions:[{trigger:{type:'ON_CLICK'}}] }, [ txt('OK','#FFF',15) ]),
    node({ name:'Frame 9', y:300, width:320, height:44, fills:[fill('#FFFFFF')],
           strokes:[{ type:'SOLID', visible:true, color:fill('#DDD').color }] },
      [ txt('valor', '#999', 14, { x:12 }) ])
  ]);
  var inv = M.inventarioElementos(p);
  assert(inv.texto >= 3, 'textos: ' + inv.texto);
  eq(inv.imagen, 1);
  assert(inv.control >= 1, 'controles: ' + inv.control);
  eq(inv.campo, 1, 'el "Frame 9" con borde y un texto es un campo: ');
  eq(inv.total, inv.texto + inv.imagen + inv.control + inv.campo + inv.icono +
     inv.contenedor + inv.decorativo + inv.sinClasificar,
     'la suma tiene que dar el total: ');
});

test('el inventario declara cuántas evaluaciones se corrieron', function(){
  var p = node({ name:'Pantalla', width:390, height:700, fills:[fill('#FFFFFF')] }, [
    txt('Uno', '#111', 16, { y:0 }), txt('Dos', '#111', 16, { y:30 })
  ]);
  var inv = M.inventarioElementos(p);
  var esperado = inv.texto * inv.criteriosPorTipo.texto.length;
  assert(inv.evaluaciones >= esperado,
    'evaluaciones: ' + inv.evaluaciones + ', esperaba al menos ' + esperado);
});

test('lo que no se puede clasificar se dice, no se saltea', function(){
  var raro = node({ name:'Frame 99', y:0, width:40, height:40 });   // sin relleno ni hijos
  var p = node({ name:'Pantalla', width:390, height:700, fills:[fill('#FFFFFF')] }, [ raro ]);
  var inv = M.inventarioElementos(p);
  eq(inv.sinClasificar, 1);
  assert(inv.sinClasificarEjemplos.indexOf('Frame 99') > -1,
    'tiene que nombrar cuáles: ' + inv.sinClasificarEjemplos.join(','));
});

test('la cobertura del reporte incluye el detalle del inventario', function(){
  var p = node({ name:'Pantalla', width:390, height:700, fills:[fill('#FFFFFF')] }, [
    txt('Título', '#111', 24, { y:0 }) ]);
  var c = M.calcularCobertura(p, {});
  assert(c.inventario, 'falta el inventario');
  assert(c.detalleInventario.indexOf('elementos clasificados') > -1,
    'detalle: ' + c.detalleInventario);
  assert(c.detalleInventario.indexOf('evaluaciones de criterio') > -1);
});

console.log('\n\x1b[1mLongitud de línea: la que se lee, no la caja\x1b[0m');

test('un título de ancho automático no genera hallazgo', function(){
  // El bug: medía la capacidad del contenedor. Un título de ancho automático
  // daba "192 caracteres por línea" con ocho palabras en una sola línea.
  var t = txt('Preparation Package', '#111', 16, { width:1600 });
  t.textAutoResize = 'WIDTH_AND_HEIGHT';
  node({ name:'P', fills:[fill('#FFF')] }, [ t ]);
  eq(M.auditLegibilidad(t).issues.filter(function(i){
    return i.detail.caracteresPorLinea; }).length, 0);
});

test('un párrafo ancho que sí envuelve se marca', function(){
  var t = txt(new Array(40).join('palabra '), '#111', 14, { width:1200 });
  t.textAutoResize = 'HEIGHT';
  node({ name:'P', fills:[fill('#FFF')] }, [ t ]);
  var i = M.auditLegibilidad(t).issues.filter(function(x){
    return x.detail.caracteresPorLinea; })[0];
  assert(i, 'un párrafo de 1200px sí es difícil de leer');
  assert(i.detail.lineas >= 2, 'tiene que reportar cuántas líneas: ' + i.detail.lineas);
});

test('un párrafo de medida cómoda pasa', function(){
  var t = txt('Un párrafo de largo razonable que entra cómodo en su caja y se lee bien.',
              '#111', 16, { width:520 });
  t.textAutoResize = 'HEIGHT';
  node({ name:'P', fills:[fill('#FFF')] }, [ t ]);
  eq(M.auditLegibilidad(t).issues.filter(function(i){
    return i.detail.caracteresPorLinea; }).length, 0);
});

test('un texto de una sola línea nunca se marca', function(){
  // Sin salto de renglón no hay dónde perderse
  var t = txt('Corto', '#111', 14, { width:900 });
  t.textAutoResize = 'HEIGHT';
  node({ name:'P', fills:[fill('#FFF')] }, [ t ]);
  eq(M.auditLegibilidad(t).issues.filter(function(i){
    return i.detail.caracteresPorLinea; }).length, 0);
});

console.log('\n\x1b[1mQué cuenta como imagen\x1b[0m');

test('detecta rellenos de imagen aunque visible venga sin declarar', function(){
  var n1 = node({ name:'Hero', width:800, height:400, fills:[{ type:'IMAGE' }] });
  node({ name:'P', fills:[fill('#FFF')] }, [ n1 ]);
  eq(M.inventarioImagenes(n1).length, 1);
});

test('una ilustración vectorial también es una imagen', function(){
  // Para WCAG "imagen" es contenido no textual que comunica algo, no un tipo
  // de relleno. Detectar solo IMAGE dejaba afuera media pantalla.
  var ilu = node({ name:'Estado vacío', width:200, height:200 }, [
    node({ name:'Vector 1', type:'VECTOR', width:100, height:100, fills:[fill('#DDD')] }),
    node({ name:'Vector 2', type:'VECTOR', width:80,  height:80,  fills:[fill('#CCC')] })
  ]);
  node({ name:'P', fills:[fill('#FFF')] }, [ ilu ]);
  var r = M.inventarioImagenes(ilu);
  assert(r.length >= 1, 'debería detectarla');
  eq(r[0].clase, 'ilustración');
});

test('un ícono chico NO cuenta como ilustración', function(){
  var ico = node({ name:'Icon / check', width:16, height:16 }, [
    node({ name:'Vector 1', type:'VECTOR', width:10, height:10, fills:[fill('#DDD')] }),
    node({ name:'Vector 2', type:'VECTOR', width:8,  height:8,  fills:[fill('#CCC')] })
  ]);
  node({ name:'P', fills:[fill('#FFF')] }, [ ico ]);
  eq(M.inventarioImagenes(ico).filter(function(i){ return i.clase === 'ilustración'; }).length, 0);
});

test('un marco llamado "photo" cuenta como placeholder', function(){
  var ph = node({ name:'Photo placeholder', width:240, height:160, fills:[fill('#EEE')] });
  node({ name:'P', fills:[fill('#FFF')] }, [ ph ]);
  var r = M.inventarioImagenes(ph);
  eq(r.length, 1);
  eq(r[0].clase, 'placeholder');
});

console.log('\n\x1b[1mSugerencia de alt: sale del contexto\x1b[0m');

test('usa el título que está al lado', function(){
  var img = node({ name:'Image', width:300, height:170, fills:[{ type:'IMAGE', visible:true }] });
  node({ name:'Class card', width:300, height:260, fills:[fill('#FFF')] }, [
    img, txt('Chair Yoga for Seniors', '#111', 20, { y:180 }) ]);
  var r = M.inventarioImagenes(img)[0];
  eq(r.sugerido, 'Chair Yoga for Seniors');
  assert(r.decorativa, 'si el texto ya lo dice, la imagen es decorativa');
});

test('una imagen dentro de un control va decorativa', function(){
  var av = node({ name:'Avatar', type:'ELLIPSE', width:36, height:36,
                  fills:[{ type:'IMAGE', visible:true }] });
  node({ name:'Button / perfil', width:44, height:44,
         reactions:[{ trigger:{type:'ON_CLICK'} }] }, [ av ]);
  var r = M.inventarioImagenes(av)[0];
  assert(r.decorativa, 'el nombre lo lleva el control');
  assert(r.motivo.indexOf('dos veces') > -1);
});

test('un gráfico pide el dato, no la forma', function(){
  var ch = node({ name:'Sales chart', width:500, height:300,
                  fills:[{ type:'IMAGE', visible:true }] });
  node({ name:'Métricas', width:600, height:360 }, [
    txt('Ventas del trimestre', '#111', 22), ch ]);
  var r = M.inventarioImagenes(ch)[0];
  assert(r.sugerido.indexOf('Ventas del trimestre') > -1, 'sugerido: ' + r.sugerido);
  assert(r.motivo.indexOf('DATO') > -1, 'tiene que explicar que un gráfico necesita el dato');
  assert(!r.decorativa, 'un gráfico casi nunca es decorativo');
});

test('un logo se describe por lo que es', function(){
  var lg = node({ name:'Logo Qubika', width:120, height:40,
                  fills:[{ type:'IMAGE', visible:true }] });
  node({ name:'Header', fills:[fill('#FFF')] }, [ lg ]);
  var r = M.inventarioImagenes(lg)[0];
  assert(r.sugerido.indexOf('Logo') > -1, 'sugerido: ' + r.sugerido);
});

test('sin contexto lo dice, en vez de inventar', function(){
  var x = node({ name:'Rectangle 12', width:300, height:200,
                 fills:[{ type:'IMAGE', visible:true }] });
  node({ name:'Frame 1', fills:[fill('#FFF')] }, [ x ]);
  var r = M.inventarioImagenes(x)[0];
  assert(r.motivo.indexOf('Sin contexto') > -1 || !r.sugerido,
    'no puede inventar un alt de la nada: ' + r.sugerido);
});

console.log('\n\x1b[1mEtiquetas de alt sobre la imagen\x1b[0m');

// Stub controlado: hace falta poder ver DÓNDE quedó cada pieza.
function conCanvas(fn){
  var creados = [];
  var previo = {
    createFrame: global.figma.createFrame,
    createText: global.figma.createText,
    createPolygon: global.figma.createPolygon,
    getNodeById: global.figma.getNodeById
  };
  function mkFrame(){
    var f = { type:'FRAME', name:'', children:[], fills:[], x:0, y:0, width:0, height:0,
      resize:function(w,h){ this.width=w; this.height=h; },
      appendChild:function(c){ this.children.push(c); c.parent=this; },
      insertChild:function(i,c){ this.children.splice(i,0,c); c.parent=this; },
      remove:function(){ this.removed=true; },
      setPluginData:function(){}, getPluginData:function(){ return ''; } };
    creados.push(f); return f;
  }
  global.figma.createFrame = mkFrame;
  global.figma.createText = function(){
    var t = { type:'TEXT', characters:'', fills:[], x:0, y:0, width:80, height:16,
      resize:function(w,h){ this.width=w; this.height=h; },
      set textAutoResize(v){ this._ar=v; }, get textAutoResize(){ return this._ar; },
      set layoutAlign(v){}, set layoutGrow(v){} };
    creados.push(t); return t;
  };
  global.figma.createPolygon = function(){
    var p = { type:'POLYGON', fills:[], x:0, y:0, width:0, height:0, pointCount:3, rotation:0,
      resize:function(w,h){ this.width=w; this.height=h; } };
    creados.push(p); return p;
  };
  var reg = {};
  global.figma.getNodeById = function(id){ return reg[id] || null; };

  try { return fn(creados, reg); }
  finally {
    global.figma.createFrame = previo.createFrame;
    global.figma.createText = previo.createText;
    global.figma.createPolygon = previo.createPolygon;
    global.figma.getNodeById = previo.getNodeById;
  }
}

test('la etiqueta queda APOYADA sobre la imagen, no flotando arriba', function(){
  // Estaba 34px por encima del borde: en una grilla caía sobre la imagen de la
  // fila de arriba y se veía desfasada.
  conCanvas(function(creados, reg){
    var img = { id:'img1', name:'Foto', absoluteBoundingBox:{ x:100, y:200, width:400, height:300 } };
    reg['img1'] = img;
    M.etiquetasSobreImagenes([{ nodeId:'img1', name:'Foto', alt:'Una persona sonriendo' }]);
    var pill = creados.filter(function(c){ return c.name && c.name.indexOf('Alt · ') === 0; })[0];
    assert(pill, 'no se creó la etiqueta');
    assert(pill.y >= 200 && pill.y <= 500,
      'la etiqueta tiene que caer dentro del alto de la imagen (200..500), está en ' + pill.y);
  });
});

test('la etiqueta lleva su cola', function(){
  conCanvas(function(creados, reg){
    reg['img1'] = { id:'img1', name:'Foto',
                    absoluteBoundingBox:{ x:0, y:0, width:400, height:300 } };
    M.etiquetasSobreImagenes([{ nodeId:'img1', name:'Foto', alt:'Algo' }]);
    var colas = creados.filter(function(c){ return c.type === 'POLYGON'; });
    eq(colas.length, 1);
    eq(colas[0].pointCount, 3, 'es un triángulo: ');
  });
});

test('una imagen decorativa se etiqueta con alt vacío', function(){
  conCanvas(function(creados, reg){
    reg['img1'] = { id:'img1', name:'Adorno',
                    absoluteBoundingBox:{ x:0, y:0, width:200, height:200 } };
    M.etiquetasSobreImagenes([{ nodeId:'img1', name:'Adorno', alt:'[decorativa]' }]);
    var t = creados.filter(function(c){ return c.type === 'TEXT'; })[0];
    assert(t, 'sin texto');
    eq(t.characters, 'Alt= ""', 'el desarrollador tiene que ver que va vacío: ');
  });
});

test('con alt escrito, la etiqueta lo muestra', function(){
  conCanvas(function(creados, reg){
    reg['img1'] = { id:'img1', name:'Foto',
                    absoluteBoundingBox:{ x:0, y:0, width:600, height:400 } };
    M.etiquetasSobreImagenes([{ nodeId:'img1', name:'Foto',
      alt:'Fachada del Bar Facal en el centro de Montevideo' }]);
    var t = creados.filter(function(c){ return c.type === 'TEXT'; })[0];
    assert(t.characters.indexOf('Bar Facal') > -1, 'texto: ' + t.characters);
    assert(t.characters.indexOf('Alt=') === 0, 'tiene que empezar por Alt=');
  });
});

test('la etiqueta no se pasa del ancho de la imagen', function(){
  conCanvas(function(creados, reg){
    reg['img1'] = { id:'img1', name:'Chica',
                    absoluteBoundingBox:{ x:0, y:0, width:180, height:120 } };
    M.etiquetasSobreImagenes([{ nodeId:'img1', name:'Chica',
      alt:'Un texto alternativo bastante largo que no debería desbordar la imagen chica' }]);
    var pill = creados.filter(function(c){ return c.name && c.name.indexOf('Alt · ') === 0; })[0];
    assert(pill.width <= 420, 'ancho: ' + pill.width);
  });
});

console.log('\n\x1b[1mSugerencias desde la escala del sistema\x1b[0m');

function conPaleta(fn){
  M.setDesignSystemPalette([
    { name:'Primitives/blue/300',  hex:'#7BC4E0', r:123, g:196, b:224 },
    { name:'Primitives/blue/400',  hex:'#4A9FD4', r:74,  g:159, b:212 },
    { name:'Primitives/blue/600',  hex:'#1B4F9C', r:27,  g:79,  b:156 },
    { name:'Primitives/green/600', hex:'#0A7B4B', r:10,  g:123, b:75  },
    { name:'Primitives/red/700',   hex:'#8A1F17', r:138, g:31,  b:23  }
  ]);
  try { return fn(); } finally { M.setDesignSystemPalette([]); }
}

test('propone un escalón de la MISMA familia, no un hex random', function(){
  // Pedido de la revisión: si el color flojo es blue/300, lo que corresponde es
  // otro azul de la escala, no un verde que casualmente esté cerca en RGB.
  conPaleta(function(){
    var s = M.suggestAccessibleColor({ r:123, g:196, b:224 }, { r:255, g:255, b:255 }, 4.5);
    assert(s, 'debería encontrar un token');
    assert(s.mismaFamilia, 'tiene que quedarse en la familia: ' + s.token);
    assert(s.token.indexOf('blue') > -1, 'token: ' + s.token);
  });
});

test('dice de qué token salió el color original', function(){
  conPaleta(function(){
    var s = M.suggestAccessibleColor({ r:123, g:196, b:224 }, { r:255, g:255, b:255 }, 4.5);
    assert(s.desde && s.desde.indexOf('blue/300') > -1, 'desde: ' + s.desde);
  });
});

test('un gris sin grises en la librería no salta a un azul: propone un gris nuevo', function(){
  // Pedido de la revisión: proponía colores "nada que ver" (un violeta para un gris)
  conPaleta(function(){
    var s = M.suggestAccessibleColor({ r:200, g:200, b:200 }, { r:255, g:255, b:255 }, 4.5);
    assert(s && !s.token, 'no debería proponer un token de otro color: ' + (s && s.token));
    assert(s.sinParecido, 'tiene que avisar que la librería no tiene uno parecido');
    var r = parseInt(s.hex.slice(1,3),16), g = parseInt(s.hex.slice(3,5),16), b = parseInt(s.hex.slice(5,7),16);
    assert(Math.max(r,g,b) - Math.min(r,g,b) < 12, 'sigue siendo gris: ' + s.hex);
  });
});

test('si la librería tiene un color parecido, lo usa aunque no sea de la misma familia', function(){
  M.setDesignSystemPalette([
    { name:'badge/violet/bg',  hex:'#806994', r:128, g:105, b:148 },
    { name:'text/secondary',   hex:'#5E5E68', r:94,  g:94,  b:104 },
    { name:'Primitives/blue/600', hex:'#1B4F9C', r:27, g:79, b:156 }
  ]);
  try {
    var s = M.suggestAccessibleColor({ r:150, g:150, b:150 }, { r:255, g:255, b:255 }, 4.5);
    assert(s && s.token === 'text/secondary', 'un gris va a un gris, no al violeta: ' + (s && s.token));
  } finally { M.setDesignSystemPalette([]); }
});

test('un color con tono busca uno del mismo tono, no el más cercano en RGB', function(){
  conPaleta(function(){
    // Un verde claro sobre blanco: el único verde que pasa es green/600
    var s = M.suggestAccessibleColor({ r:90, g:190, b:130 }, { r:255, g:255, b:255 }, 4.5);
    assert(s && s.token === 'Primitives/green/600', 'token: ' + (s && s.token));
  });
});

test('sin paleta cargada, avisa que el hex no está en el sistema', function(){
  M.setDesignSystemPalette([]);
  var s = M.suggestAccessibleColor({ r:123, g:196, b:224 }, { r:255, g:255, b:255 }, 4.5);
  assert(s && !s.token, 'sin sistema no hay token que proponer');
});

test('la familia se extrae del nombre del token', function(){
  eq(M.familiaDeToken('Primitives/blue/400'), 'blue');
  eq(M.familiaDeToken('Semantic/text/primary'), 'primary');
  eq(M.familiaDeToken('brand/Verde/base'), 'verde');
});

console.log('\n\x1b[1mCuentagotas: el color que se VE\x1b[0m');

test('un negro al 40% sobre blanco da el gris resultante', function(){
  // Lo pedido en la revisión: tomar el color compuesto, no el hex crudo.
  var t = node({ name:'Texto tenue', width:200, height:30,
                 fills:[{ type:'SOLID', visible:true, opacity:0.4,
                          color:{ r:0, g:0, b:0 } }] });
  node({ name:'Card', fills:[fill('#FFFFFF')] }, [ t ]);
  var c = M.colorDeCapa(t);
  assert(c.compuesto, 'tiene que marcar que es compuesto');
  eq(c.crudo, '#000000', 'el crudo se conserva para poder explicarlo: ');
  assert(c.fill !== '#000000', 'el resultante no puede ser el negro puro: ' + c.fill);
  eq(c.opacidad, 0.4);
});

test('sin transparencia devuelve el color tal cual', function(){
  var t = node({ name:'Texto', width:200, height:30, fills:[fill('#1B4F9C')] });
  node({ name:'Card', fills:[fill('#FFFFFF')] }, [ t ]);
  var c = M.colorDeCapa(t);
  eq(c.fill, '#1B4F9C');
  assert(!c.compuesto);
});

test('la opacidad de la capa también cuenta', function(){
  var t = node({ name:'Texto', width:200, height:30, opacity:0.5,
                 fills:[fill('#000000')] });
  node({ name:'Card', fills:[fill('#FFFFFF')] }, [ t ]);
  var c = M.colorDeCapa(t);
  assert(c.compuesto, 'la opacidad del nodo, no solo la del relleno');
});

console.log('\n' + (failed===0
  ? '\x1b[32m'+passed+' tests OK\x1b[0m\n'
  : '\x1b[31m'+failed+' fallaron\x1b[0m, '+passed+' OK\n'));
process.exit(failed===0?0:1);
